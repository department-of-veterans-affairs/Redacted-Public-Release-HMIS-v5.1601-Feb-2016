<?php

include('init.php');
include('hmis/libs/functions.php');


$e_token = trim(scrub_white_list($_POST['e_token'], 'ALPHANUMERICONLY'));
$s_e_token = $_SESSION['e_token'];

//echo "e_token-> " . $e_token;
//echo "<BR>s_e_token -> " . $s_e_token;

if ((ISSET($e_token)) && ($e_token===$s_e_token)){
	if (checklogin($userID, "menu.php") && $status == 2) {

	if (isset($_REQUEST['p'])) { 
	$pid = scrub_sql(scrub_white_list($_REQUEST['p'], 'NUMBERONLY'), 8);

	$sql = "UPDATE HMIS_Files SET status='INACTIVE' WHERE program_id=$pid";
	$rs = $db->Execute($sql);

	$sql = "UPDATE tb_SSVF_program SET status=1 WHERE program_id=$pid";
	$rs = $db->Execute($sql);

	$message = 'Admin reset program data upload status';
	audit_log($userID, $message, 16, 0, $pid);


	$sql = "SELECT program_name from tb_SSVF_program WHERE program_id=$pid";
	$rs = $db->Execute($sql);

	while (!$rs->EOF)
	{
		$pname_disp = $rs->fields('program_name');

	$rs->MoveNext();
	}

	print_header();

	print("
		<table width=800 align=center>
		<tr><td>
		<HR>
		<H1 align=center>Program Upload Status Reset</H1>
		<BR>
		<HR>
		<center><b> $pname_disp </b><br>
		<h3 align=center>The data associated with this program has been de-activated. The program has been set to 'Not Started.'</h3>
		<BR>
		<center><A HREF='manage_programs.php?s=0'>Click here to continue</A></CENTER>
		<HR>
		</td></tr></table>
	");

	print_footer();

	} // end has uid

	} // end is logged in
}
else{ //etoken check: false
	$message = "Error: Invalid session!";
	print_header();
		print "<br><hr><h1 align=center>$message</h1><hr><h3 align=center>Please press the Back button to return to previous page.</h3>";
		print_footer();

}
?>