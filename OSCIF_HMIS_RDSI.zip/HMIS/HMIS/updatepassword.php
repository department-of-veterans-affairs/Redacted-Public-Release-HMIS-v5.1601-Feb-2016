<?php

include('init.php');
include('hmis/libs/functions.php');


$e_token = trim(scrub_white_list($_POST['e_token'], 'ALPHANUMERICONLY'));
$s_e_token = $_SESSION['e_token'];

//echo $e_token . "<BR>";
//echo $s_e_token;

if ((ISSET($e_token)) && ($e_token===$s_e_token)){

	if (checklogin($userID, "menu.php")) {
		$password = trim($_POST['password']);
		$currentpassword = trim($_POST['currentpassword']);

		$errors = 0;


			if ($password <> "" && strlen($password) > 7 && strlen($password) < 21 && check_password($password)) {

				$currentpasswordenc = hash('sha256', "just4uAlanna".$currentpassword);	//md5("just4uAlanna".$currentpassword);
				$sql = "SELECT count(user_id) AS cnt FROM tb_user WHERE user_id=$userID AND password='$currentpasswordenc' ";
				$rs = $db->Execute($sql);
				$cnt = $rs->fields('cnt');
				if ($cnt != 1) {
					$errors = 1;
					$message = "Incorrect current password";
				}
				else {
					if ($status == 7) {
						$status=1;
					}	
					else if ($status == 8) {
						$status=2;
					}
				
					$_SESSION['status'] = $status;
					$password = hash('sha256', "just4uAlanna".$password);	//md5("just4uAlanna".$password);
					$sql = "UPDATE tb_user SET password='$password', status=$status WHERE user_id=$userID";
					$rs = $db->Execute($sql);
					$sql = "UPDATE tb_password_update SET last_password_change=getdate() WHERE user_id=$userID";
					$rs = $db->Execute($sql);

					//$sql = "INSERT INTO tb_audit (user_id, event, event_date) VALUES ($userID, 'User changed password', getdate())";
					//$rs = $db->Execute($sql);

					$message = 'User changed password';
					audit_log($userID, $message, 51);
				}

		}
		else {
			$errors = 1;
			$message = "Invalid password";
		}


		// display error message
		if ($errors == 1) {
		print_header();
		print "<br><hr><h1 align=center>$message</h1><hr><h3 align=center>Please press the Back button to return to previous page</h3>";

		print_footer();
		}

		else {

		print_header();

		print ("

		<table width=800 align=center>
		<tr><td>
		<BR>
		<HR>
		<H1 align=center>Thank You!</H1>
		<BR>
		<HR>
		<H3 align=center>Your account has been updated. <A HREF=menu.php>Click here to continue</A></H3>
		<BR>
		<HR>
		</td></tr></table>
		");

		print_footer();

		}


		} // end check login
}
else{ //etoken check: false
	$message = "Error: Invalid session!";
	print_header();
		print "<br><hr><h1 align=center>$message</h1><hr><h3 align=center>Please press the Back button to return to previous page.</h3>";
		print_footer();

}

?>