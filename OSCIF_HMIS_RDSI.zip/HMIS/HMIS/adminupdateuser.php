<?php

include('init.php');
include('hmis/libs/functions.php');


$e_token = trim(scrub_white_list($_POST['e_token'], 'ALPHANUMERICONLY'));
$s_e_token = $_SESSION['e_token'];
if ((ISSET($e_token)) && ($e_token===$s_e_token)){

	if (checklogin($userID, "menu.php") && $status == 2) {


	$uid = scrub_sql(scrub_white_list($_POST['uid'], 'NUMBERONLY'), 8);
	$fname = scrub_sql(scrub_white_list(trim($_POST['fname']),'ALPHAONLY'), 20);
	$lname = scrub_sql(scrub_white_list(trim($_POST['lname']),'ALPHAONLY'), 30);
	$email = scrub_sql(scrub_white_list(trim($_POST['email']),'USER'), 150);
	$phone = scrub_sql(scrub_white_list(trim($_POST['phone']),'NUMBERONLY'), 20);
	$organization = scrub_sql(scrub_white_list(trim($_POST['organization']), 'USER'), 70);
	$level = scrub_sql(scrub_white_list(trim($_POST['level']), 'NUMBERONLY'), 2);
	//$user_coc = scrub_sql(scrub_white_list(trim($_POST['dd_coc_hid']), 'USER'), 5);
	$squares_only = scrub_sql(scrub_white_list(trim($_POST['sq_only']), 'NUMBERONLY'), 1);

	$programs = $_POST['selProgs'];
	$progSize = sizeof($programs);
	$PWDQ = "";



	$PWDQ = "";

	$password = trim($_POST['password']);

	$errors=0;

	if ($errors == 0) {
	$sql = "select count(user_id) as cnt from tb_user where user_id=$uid";
	$rs = $db->Execute($sql);
	$cnt = $rs->fields('cnt');

		if ($squares_only == "1"){
			$sql = "UPDATE tb_user SET fname='$fname', lname='$lname', email='$email', phone='$phone', organization='$organization', squares_user='$squares_only', status=$level $PWDQ WHERE user_id=$uid";

			//echo "<BR><BR>".$sql."<BR>".$user_coc."<BR>";
			$rs = $db->Execute($sql);	
		}
		else{
			$sql = "UPDATE tb_user SET fname='$fname', lname='$lname', email='$email', phone='$phone', organization='$organization', squares_user='0', status=$level $PWDQ WHERE user_id=$uid";
			//echo "<BR><BR>".$sql."<BR>".$user_coc."<BR>";
			$rs = $db->Execute($sql);
		}

		if (isset($_POST['dd_coc']) && $_POST['dd_coc'] > 0) {
			$user_coc = scrub_white_list($_POST['dd_coc'], 'NUMBERONLY');

			$sqlDel = "DELETE from tb_user_CoC where user_id=$uid";
			$rs = $db->Execute($sqlDel);

			$sql = "INSERT INTO tb_user_CoC VALUES ($uid, $user_coc, getdate())";
			//print(" 1 $sql");
			$rs = $db->Execute($sql);
		}


	if ($password <> "" && strlen($password) > 7 && strlen($password) < 21 && check_password($password))  {
		$password = hash('sha256', "just4uAlanna".$password);	//md5("just4uAlanna".$password);
		$currentpassword = trim($_POST['password2']);
		$currentpasswordenc = hash('sha256', "just4uAlanna".$currentpassword);	//md5("just4uAlanna".$currentpassword);

			$PWDQ = ", password='$password'";

			$sql = "UPDATE tb_user SET password='$password' WHERE user_id=$uid";
			$rs = $db->Execute($sql);

			$sql = "UPDATE tb_password_update SET last_password_change=getdate() WHERE user_id=$uid";
			$rs = $db->Execute($sql);

			//Increment 3 - Force user to reset password at next login
			$sql = "UPDATE tb_user SET status=7 WHERE user_id=$uid";
			$rs = $db->Execute($sql);

			$eventmsg = 'Admin reset user password';
			audit_log($userID, $eventmsg, 19, $uid);

		}

		if(isset($_POST['selProgs']))
			if ($progSize < 1 || $progSize > 7) {
			$message = "You have selected too few (less than 1) or too many (more than 7) programs.";
		}
		else{
			$sql = "DELETE FROM tb_user_programs WHERE user_id=$uid";
			$rs = $db->Execute($sql);

			foreach($programs as $value){
				$sql = "INSERT INTO tb_user_programs VALUES ($uid, $value)";
				$rs = $db->Execute($sql);
				//echo $sql;
			}
		}

		if (isset($_POST['program_id1']) && $_POST['program_id1'] > 0) {
		$sql = "DELETE FROM tb_user_programs WHERE user_id=$uid";
		$rs = $db->Execute($sql);
		
		$program_id = scrub_white_list($_POST['program_id1'], 'NUMBERONLY');
		$sql = "INSERT INTO tb_user_programs VALUES ($uid, $program_id, getdate())";
		$rs = $db->Execute($sql);
		}
		
		if (isset($_POST['program_id2']) && $_POST['program_id2'] > 0) {
		$program_id = scrub_white_list($_POST['program_id2'], 'NUMBERONLY');
		$sql = "INSERT INTO tb_user_programs VALUES ($uid, $program_id, getdate())";
		$rs = $db->Execute($sql);
		}

		if (isset($_POST['program_id3']) && $_POST['program_id3'] > 0) {
		$program_id = scrub_white_list($_POST['program_id3'], 'NUMBERONLY');
		$sql = "INSERT INTO tb_user_programs VALUES ($uid, $program_id, getdate())";
		$rs = $db->Execute($sql);
		}
			
		if (isset($_POST['program_id4']) && $_POST['program_id4'] > 0) {
		$program_id = scrub_white_list($_POST['program_id4'], 'NUMBERONLY');
		$sql = "INSERT INTO tb_user_programs VALUES ($uid, $program_id, getdate())";
		$rs = $db->Execute($sql);
		}

		if (isset($_POST['program_id5']) && $_POST['program_id5'] > 0) {
		$program_id = scrub_white_list($_POST['program_id5'], 'NUMBERONLY');
		$sql = "INSERT INTO tb_user_programs VALUES ($uid, $program_id, getdate())";
		$rs = $db->Execute($sql);
		}

		if (isset($_POST['program_id6']) && $_POST['program_id6'] > 0) {
		$program_id = scrub_white_list($_POST['program_id6'], 'NUMBERONLY');
		$sql = "INSERT INTO tb_user_programs VALUES ($uid, $program_id, getdate())";
		$rs = $db->Execute($sql);
		}

		if (isset($_POST['program_id7']) && $_POST['program_id7'] > 0) {
		$program_id = scrub_white_list($_POST['program_id7'], 'NUMBERONLY');
		$sql = "INSERT INTO tb_user_programs VALUES ($uid, $program_id, getdate())";
		$rs = $db->Execute($sql);
		} 

		if (isset($_POST['program_id8']) && $_POST['program_id8'] > 0) {
		$program_id = scrub_white_list($_POST['program_id8'], 'NUMBERONLY');
		$sql = "INSERT INTO tb_user_programs VALUES ($uid, $program_id, getdate())";
		$rs = $db->Execute($sql);
		}

		if (isset($_POST['program_id9']) && $_POST['program_id9'] > 0) {
		$program_id = scrub_white_list($_POST['program_id9'], 'NUMBERONLY');
		$sql = "INSERT INTO tb_user_programs VALUES ($uid, $program_id, getdate())";
		$rs = $db->Execute($sql);
		}

		if (isset($_POST['program_id10']) && $_POST['program_id10'] > 0) {
		$program_id = scrub_white_list($_POST['program_id10'], 'NUMBERONLY');
		$sql = "INSERT INTO tb_user_programs VALUES ($uid, $program_id, getdate())";
		$rs = $db->Execute($sql);
		}

		if (isset($_POST['program_id11']) && $_POST['program_id11'] > 0) {
		$program_id = scrub_white_list($_POST['program_id11'], 'NUMBERONLY');
		$sql = "INSERT INTO tb_user_programs VALUES ($uid, $program_id, getdate())";
		$rs = $db->Execute($sql);
		}

		if (isset($_POST['program_id12']) && $_POST['program_id12'] > 0) {
		$program_id = scrub_white_list($_POST['program_id12'], 'NUMBERONLY');
		$sql = "INSERT INTO tb_user_programs VALUES ($uid, $program_id, getdate())";
		$rs = $db->Execute($sql);
		}

		if (isset($_POST['program_id13']) && $_POST['program_id13'] > 0) {
		$program_id = scrub_white_list($_POST['program_id13'], 'NUMBERONLY');
		$sql = "INSERT INTO tb_user_programs VALUES ($uid, $program_id, getdate())";
		$rs = $db->Execute($sql);
		}

		if (isset($_POST['program_id14']) && $_POST['program_id14'] > 0) {
		$program_id = scrub_white_list($_POST['program_id14'], 'NUMBERONLY');
		$sql = "INSERT INTO tb_user_programs VALUES ($uid, $program_id, getdate())";
		$rs = $db->Execute($sql);
		} 

		if (isset($_POST['program_id15']) && $_POST['program_id15'] > 0) {
		$program_id = scrub_white_list($_POST['program_id15'], 'NUMBERONLY');
		$sql = "INSERT INTO tb_user_programs VALUES ($uid, $program_id, getdate())";
		$rs = $db->Execute($sql);
		} 

		if (isset($_POST['program_id16']) && $_POST['program_id16'] > 0) {
		$program_id = scrub_white_list($_POST['program_id16'], 'NUMBERONLY');
		$sql = "INSERT INTO tb_user_programs VALUES ($uid, $program_id, getdate())";
		$rs = $db->Execute($sql);
		} 

		if (isset($_POST['program_id17']) && $_POST['program_id17'] > 0) {
		$program_id = scrub_white_list($_POST['program_id17'], 'NUMBERONLY');
		$sql = "INSERT INTO tb_user_programs VALUES ($uid, $program_id, getdate())";
		$rs = $db->Execute($sql);
		} 

		if (isset($_POST['program_id18']) && $_POST['program_id18'] > 0) {
		$program_id = scrub_white_list($_POST['program_id18'], 'NUMBERONLY');
		$sql = "INSERT INTO tb_user_programs VALUES ($uid, $program_id, getdate())";
		$rs = $db->Execute($sql);
		} 

		if (isset($_POST['program_id19']) && $_POST['program_id19'] > 0) {
		$program_id = scrub_white_list($_POST['program_id19'], 'NUMBERONLY');
		$sql = "INSERT INTO tb_user_programs VALUES ($uid, $program_id, getdate())";
		$rs = $db->Execute($sql);
		} 

		if (isset($_POST['program_id20']) && $_POST['program_id20'] > 0) {
		$program_id = scrub_white_list($_POST['program_id20'], 'NUMBERONLY');
		$sql = "INSERT INTO tb_user_programs VALUES ($uid, $program_id, getdate())";
		$rs = $db->Execute($sql);
		} 


	//$sql = "INSERT INTO tb_audit (user_id, event, event_date) VALUES ($userID, 'Admin updated profile for user $uid', getdate())";
	//$rs = $db->Execute($sql);

		$eventmsg = 'Admin updated user account information';
		audit_log($userID, $eventmsg, 10, $uid);


		if (isset($_SESSION['return_page'])) {
			$url = $_SESSION['return_page'];
		}
		else {
			$url = "manage_users.php";
		}

		print_header();

		$sqlUTE = "select username from tb_user where user_id=$uid";
		$rs = $db->Execute($sqlUTE);
		$UTEdisp = $rs->fields('username');
		
		print ("
			<table width=800 align=center>
			<tr><td>
			<BR>
			<HR>
			<H1 align=center>Thank You!</H1>
			<BR>
			<HR>
			<H3 align=center>The account <i>$UTEdisp</i> has been updated. <A HREF=\"$url\"><br>Click here to continue.</A></H3>
			<BR>
			<HR>
			</td></tr></table>
		");
		
		print_footer();
			
	} // end if no errors


	// display error message
	else {
		print_header();
		print "<br><hr><h1 align=center>$message</h1><hr><h3 align=center>Please press the Back button to return to previous page.</h3>";
		print_footer();
		}
	} // end check login
}
else{ //etoken check: false
	$message = "Error: Invalid session!";
	print_header();
		print "<br><hr><h1 align=center>$message</h1><hr><h3 align=center>Please press the Back button to return to previous page.</h3>";
		print_footer();

}
?>