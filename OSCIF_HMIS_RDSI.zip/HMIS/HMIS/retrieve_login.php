<?php

include('init.php');
include('hmis/libs/functions.php');


print_header();


$e_token = trim(scrub_white_list($_POST['e_token'], 'ALPHANUMERICONLY'));
$s_e_token = $_SESSION['e_token'];

if ((ISSET($e_token)) && ($e_token===$s_e_token)){
	if (isset($_POST['uorp']) && isset($_POST['email']) ) {
		$uorp = scrub_white_list($_POST['uorp'],'NUMBERONLY');
		$email = scrub_sql(scrub_white_list($_POST['email'],'USER'),150);

		$sql = "SELECT user_id, username, fname, status FROM tb_user WHERE email='$email' AND (status=1 OR status=2)";
		$rs = $db->Execute($sql);

		$record_count = $rs->RecordCount();
		//echo $record_count . "<Br>";

		if ($record_count > 0) {
			
			//echo "here1";
			$user_id = $rs->fields('user_id');
			$user = $rs->fields('username');
			$status = $rs->fields('status');
			$fname = $rs->fields('fname');
			
			if ($uorp == 1) {
				//$sql = "INSERT INTO tb_audit (user_id, event, event_date) VALUES ($user_id, 'Username for this user was emailed to $email via forgot username function', getdate())";
				//$rs = $db->Execute($sql);

				$eventmsg = 'Username was emailed to ' . $email . ' via Forgot Username function';
				audit_log($user_id, $eventmsg, 56);

				$message = ("
					<HTML>
					<BODY>


					$fname,
					<BR><BR>
					We have recieved your request to retrieve your account username. <br><br> The information associated with this email address is:<br><br>
					<center><table border='2'><tr><td style='padding-left: 15px; padding-right: 15px;' bgcolor='#CCCCCC'><b>Username:</b></td><td align='center' style='padding-left: 10px; padding-right: 10px;'>$user</td></tr></table></center>
					<BR><BR>
					If you did not request this information, or you are still experiencing issues accessing this account, please visit the <a href='http://ip_redacted/support.php'>HMIS Repository Support</a> page.</center>
					<br><br>
					Thank you,
					<BR>
					HMIS Repository Administrator
					<BR><HR><BR>
					</BODY></HTML>

					
				");
			}
			else {
				$newpass = createRandom(7);
				$encnewpass = hash('sha256', "just4uAlanna".$newpass);	//md5("just4uAlanna".$newpass);

				if (($status == 1) OR ($status == 7)){
					$newstatus = 7;
				}
				else if ($status == 2) {
					$newstatus = 8;
				}

				$sql = "UPDATE tb_user SET password='$encnewpass', status=$newstatus WHERE user_id=$user_id";
				$rs = $db->Execute($sql);

				//$sql = "INSERT INTO tb_audit (user_id, event, event_date) VALUES ($user_id, 'Password for this user was reset via forgot password function.', getdate())";
				//$rs = $db->Execute($sql);

				$eventmsg = 'Password for this user was reset via Forgot Password function';
				audit_log($userID, $eventmsg, 50);


				$message = ("

					<HTML>
					<BODY>


					$fname,
					<BR><BR>
					Your HMIS Repository password has been temporarily reset to the following: <br><br>
					
					<center><table border='2'><tr><td style='padding-left: 15px; padding-right: 15px;' bgcolor='#CCCCCC'><b>New password:</b></td><td align='center' style='padding-left: 10px; padding-right: 10px;'>$newpass</td></tr></table></center><br>
					<br>Please log in to the HMIS Repository to reset your password.
					<BR><BR>
					If you did not request this information, or you are still experiencing issues accessing this account, please visit the <a href='http://ip_redacted/support.php'>HMIS Repository Support</a> page.</center>
					<br><br>
					Thank you,
					<BR>
					HMIS Repository Administrator
					<BR><HR><BR>
					</BODY></HTML>

				");


			}

			$headers = "To: $fname $lname <$email>\n" . "From: HMIS Repository Admin <noreply@domain>\n" . "MIME-Version: 1.0\n" . "Content-type: text/html; charset=iso-8859-1";

			mail( $email, "HMIS Repository Lost Login",
			$message, $headers );



			print "<H1 align=center>Lost Username/Password Sent</H1><BR><HR><CENTER>The requested information has been sent to <b>$email</b>. <br><br>
			<a href='index.php'>Back to Login</a>
			</CENTER>";

		}
		else {
			//echo "here12";
			print "<H1 align=center>Error!</h1><br><h3 align='center'>The information provided did not match our records, or your account is not active (pending approval or locked).</h3><br><br>
				<center><a href='index.php'>Back to Login</a> | <a href='support.php'>HMIS Repository Support</a></center>";
		}


	}
	else {
	print "<H1 align=center>Error. Incomplete form.</H1><br>
	<center><a href='index.php'>Back to Login</a></center>";
	}
}


else{ //etoken check: false
	$message = "Error: Invalid session!";
	//print_header();
		print "<br><hr><h1 align=center>$message</h1><hr><br><A HREF='menu.php'>Click here to continue</A>";
		//print_footer();

}

?>




<?php

print_footer();


?>