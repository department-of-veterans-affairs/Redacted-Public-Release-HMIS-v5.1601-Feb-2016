<?php

include('init.php');
include('hmis/libs/functions.php');
$e_token = trim(scrub_white_list($_GET['t'], 'ALPHANUMERICONLY'));
$s_e_token = $_SESSION['e_token'];

//echo "e_token-> " . $e_token;
//echo "<BR>s_e_token -> " . $s_e_token;

if ((ISSET($e_token)) && ($e_token===$s_e_token)){
	$p=trim(scrub_white_list($_GET['p'], 'ALPHANUMERICONLY'));

	if($p==''){
		return "";
	}


	else{
		
		if ($p==0){
			$sql = "SELECT DISTINCT Top (50) ta.event_id, ta.user_id, tu.username, tu.status, ta.event_type, ta.event, hur.error_id, ta.event_date, ta.event_var, ta.event_var2, sp.program_name, ROW_NUMBER() OVER(ORDER BY ta.event_date desc) [rowNumber]
				FROM tb_audit ta, tb_user tu, HMIS_Upload_Reports hur, tb_ssvf_program sp
				where ta.user_id = tu.user_id 
					and hur.file_id = ta.event_var 
					and event_type in (58,59,60,61) 
					and event_var2 in (SELECT program_id
						FROM tb_user_programs
						WHERE user_id = $userID)
					and sp.program_id = ta.event_var2
				ORDER BY ta.event_date desc
				";
		}

		else if (($p<>0) AND ($p<>'showAll')){
			
			$user_sql = "user_id = $userID AND ";
			if ($status == 2) {
				$user_sql = "";	
			}
	
			$sql = "SELECT  DISTINCT Top (50) ta.event_id, ta.user_id, tu.username, tu.status, ta.event_type, ta.event, hur.error_id, ta.event_date, ta.event_var, ta.event_var2, sp.program_name, ROW_NUMBER() OVER(ORDER BY ta.event_date desc) [rowNumber]
				FROM tb_audit ta, tb_user tu, HMIS_Upload_Reports hur, tb_ssvf_program sp
				where ta.user_id = tu.user_id 
					and hur.file_id = ta.event_var 
					and event_type in (58,59,60,61) 
					and sp.program_id = ta.event_var2
					and event_var2 in (SELECT program_id
						FROM tb_user_programs
						WHERE $user_sql $p = program_id)
				ORDER BY ta.event_date desc
				";
		}

		else if ($p=='showAll'){
		$sql = "SELECT DISTINCT ta.event_id, ta.user_id, tu.username, tu.status, ta.event_type, ta.event, hur.error_id, ta.event_date, ta.event_var, ta.event_var2, ROW_NUMBER() OVER(ORDER BY ta.event_date desc) [rowNumber]
				FROM tb_audit ta, tb_user tu, HMIS_Upload_Reports hur
				where hur.file_id = ta.event_var and event_type in (58,59,60,61) 
				ORDER BY ta.event_date desc
				";
		} else {
			$sql = "SELECT DISTINCT ta.event_id, ta.user_id, tu.username, tu.status, ta.event_type, ta.event, hur.error_id, ta.event_date, ta.event_var, ta.event_var2, ROW_NUMBER() OVER(ORDER BY ta.event_date desc) [rowNumber]
				FROM tb_audit ta, tb_user tu, HMIS_Upload_Reports hur
				where hur.file_id = ta.event_var and event_type in (58,59,60,61) 
				ORDER BY ta.event_date desc
				";
		}

		$rs = $db->Execute($sql);
		$data = "";

	//if (isset($_GET['pg'])) {
	//	$pg = scrub_white_list($_GET['pg'], 'NUMBERONLY');
	//}
	//else {
	//	$pg = 1;
	//}
	//$results = 0;
	//$start = 1+($pg-1)*40;
	//$finish = $start+39;




	if ($rs->EOF){
		$data = $data . "<table align='center' name='table_blank' id='table_blank' style='width: 100%; float: left; border-style:solid; border-width:2px;'>
		<THEAD>
		<TR style=' background-color: #000031;color:white;'>
		<TH>Date / Time (EST)</TH>
		<TH>Username</TH>
		<TH>Status</TH>
		<TH>Action</TH>

			<tr>
				<td align='center' colspan=4 id='event_date' width='200' style='background-color:whitesmoke;'><b>No activity found.</b></td>
			</tr>
			</table>";

	}
	else
	{


	$data = $data .  "<TABLE ALIGN='CENTER' NAME='tableOne' id='tableOne' cellspacing='0' class='display' style='width: 100%'; border=1>
		<THEAD>
		<TR>
		<TH>Date / Time (EST)</TH>
		<TH>Username</TH>
		<TH>Status</TH>";


	if (checklogin($userID, 'menu.php') && $status == 2) {
		$data = $data . "<TH class='action'>Action</TH>";
	}


		$data = $data . "</TR></THEAD><TBODY>";
		while (!$rs->EOF) { 	
			$user_id = $rs->fields('user_id');
			$user_name = $rs->fields('username');
			$uStatus = $rs->fields('status');
			
			$file_id = $rs->fields('event_var');
			$program_id = $rs->fields('event_var2');
			$pName = $rs->fields('program_name');
			$event_type = $rs->fields('event_type');
			$event_date = $rs->fields('event_date');
			$event_date = date("n/j/y g:i:s A", strtotime($event_date));
		
			$eid = $rs->fields('error_id');
		
			//$sql2 = "select program_name from tb_ssvf_program where program_id=$program_id";
			//$rs = $db->Execute($sql);
		
		
			$data = $data . "<tr><td align='center' id='event_date' width='200'>$event_date</td>";
		
			if ($uStatus==2){
				$data = $data . "<td id='uname'>Repository Admin <br><font size=1><i>($pName)</i></font></td>";
			}
			else{
				$data = $data . "<td id='uname'>$user_name <br><font size=1><i>($pName)</i></font></td>";
			}
			
			//if (($event_type==58) OR ($event_type==59)){
			if (($event_type==58)){
				$data = $data . "<td  id='fStatus'>Unsuccessful</td>";
			}
			else if (($event_type==59) or ($event_type==60)){
				$data = $data . "<td  id='fStatus'>Validation successful</td>";
			}
			else if ($event_type==61){
				$data = $data . "<td id='fStatus'>Upload successful</td>";
			}
			else{
				$data = $data . "<td id='fStatus'>No status found</td>";
			}
							
			if (checklogin($userID, 'menu.php') && $status == 2) {
				$data = $data . "<td id='action'><a href='view_vreport.php?e=$eid'  target='_blank'>View Results</a></td>";
			}
		
			$results = $results + 1;    
			$rs->MoveNext();
		  }

			
		$data = $data . "
			</TBODY></table>";
		}
	}
}
else{ 
		$data = "<TABLE ALIGN='CENTER' border=1 NAME='table_blank' id='table_blank' border=1 cellspacing='0' style='width: 100%; float: left'> 
			<TR>
			<TD align=center><b>You do not have permission to run this report. (Invalid Session)</b></td>
			</TR>
			</table>
			";
}
echo $data;
?>