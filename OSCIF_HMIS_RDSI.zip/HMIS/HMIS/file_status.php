<?php

include('init.php');
include('hmis/libs/functions.php');

if (checklogin($userID, "menu.php") && $status == 2) {

	if (isset($_REQUEST['data_id'])) { 
		$data_id = scrub_sql(scrub_white_list($_REQUEST['data_id'], 'ALPHANUMERICONLY'), 15);
		
		$req = scrub_sql(scrub_white_list($_REQUEST['req'], 'ALPHAONLY'), 32);
	
		if ('inactivate' == $req) {
			$result = inactivate_hmis_data($data_id);
			$message = 'Admin inactivated data id: ' . $data_id;
			audit_log($userID, $message);
			
		} else if ('activate' == $req) {
			$result = activate_hmis_data($data_id);
			$message = 'Admin activated data id: ' . $data_id;
			audit_log($userID, $message);
			
		} else {
			$message = 'Invalid Request.';
		}
	
		print_header();

?>
<table width=800 align=center>
	<tr>
		<td>
			<BR><HR><H1 align=center>File Status Update</H1>
			<BR><HR><H3 align=center><?=$message?></H3>
			<BR><CENTER><A HREF=upload_history.php>Click here to continue</A></CENTER>
			<HR>
		</td>
	</tr>
</table>

<?

print_footer();

	} // end has uid

} // end is logged in
?>