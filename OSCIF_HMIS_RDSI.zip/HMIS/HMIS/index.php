
<?php

include('init.php');
include('hmis/libs/functions.php');


//code to generate random session token
$charset='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
$str = '';
$count = strlen($charset);
$length=8;
while ($length--) {
        $str .= $charset[mt_rand(0, $count-1)];
		

}
//echo strtoupper($str);
$_SESSION['e_token'] = strtoupper($str);
//echo $_SESSION['e_token'];
//end code to generate random session token

if (isset($_REQUEST['target'])) {
	$target = scrub_white_list(trim($_REQUEST['target']), 'INTERNALLINK');
	if(!is_readable($target)) {
		$target = "menu.php";
	}
	
	if ('hmis' == $target) {
		$target = '/hmis/';	
	} else {
		$target = "menu.php";
	}
}
else {$target = "menu.php";}

if ($userID > 0) {
header("Location: $target");
}

$loggedin = 0;
$message = "";
$debug = "";

if (isset($_POST['user']) && isset($_POST['password'])) {

$user = scrub_white_list($_POST['user'], 'USER');
$password = $_POST['password'];

$encpassword = hash('sha256', "just4uAlanna".$password);	//md5("just4uAlanna".$password);

$sql = "SELECT value FROM HMIS_Config WHERE name = 'user_login_switch'";
$rs = $db->Execute($sql);
$switch = $rs->fields('value');
$sql_admin_only = '';

$_SESSION['hmis_switch'] = $switch;

if ('off' == $switch) {
	$sql_admin_only = '';	//' AND u.status = \'2\' ';	
}

$status = 0;

$sql = "SELECT u.user_id, u.status, u.squares_user, DATEDIFF ( DAY , c.last_password_change, GETDATE() ) AS d FROM tb_user u, tb_password_update c WHERE u.user_id=c.user_id $sql_admin_only AND u.username='$user' AND u.password='$encpassword' ";
$debug = $sql;
$rs = $db->Execute($sql);


$record_count = $rs->RecordCount();

if ($record_count == 1) {
$user_id = $rs->fields('user_id');
$status = $rs->fields('status');
$days = $rs->fields('d');
$squares_user = $rs->fields('squares_user');
$_SESSION['squares_user'] = $squares_user;

if ($days > 90) {
if ($status == 1) {
$sql = "UPDATE tb_user SET status=7 WHERE user_id=$user_id";
$rs = $db->Execute($sql);
$status=7;
}
else if ($status == 2) {
$sql = "UPDATE tb_user SET status=8 WHERE user_id=$user_id";
$rs = $db->Execute($sql);
$status=8;
}

}

// normal active user
if ($status == 1) {
$_SESSION['userID'] = $user_id;
$userID = $user_id;
$_SESSION['username'] = $user;
$_SESSION['status'] = $status;
$loggedin = 1;

//$sql = "INSERT INTO tb_audit (user_id, event, event_date) VALUES ($user_id, 'User successfully logged in', getdate())";
//$rs = $db->Execute($sql);

$message = 'User successfully logged in';
audit_log($user_id, $message, 54);


header("Location: $target"); 
}
// admin user
else if ($status == 2) {
$_SESSION['userID'] = $user_id;
$userID = $user_id;
$_SESSION['username'] = $user;
$_SESSION['status'] = $status;
$loggedin = 1;
//$sql = "INSERT INTO tb_audit (user_id, event, event_date) VALUES ($user_id, 'Admin successfully logged in', getdate())";
//$rs = $db->Execute($sql);


$message = 'Admin successfully logged in';
audit_log($user_id, $message, 7);

header("Location: $target");



}

// hrc user
else if ($status == 4) {
$_SESSION['userID'] = $user_id;
$userID = $user_id;
$_SESSION['username'] = $user;
$_SESSION['status'] = $status;
$loggedin = 1;
$sql = "INSERT INTO tb_audit (user_id, event, event_date) VALUES ($user_id, 'HRC user successfully logged in', getdate())";
$rs = $db->Execute($sql);
header("Location: $target");

}
else if ($status == 0) {$message = "<BR><CENTER><FONT COLOR=FF0000>You must confirm your email address before logging in</FONT></CENTER><BR>";}
else if ($status == 9) {$message = "<BR><CENTER><FONT COLOR=FF0000>Your account is under review. You will not be able to log in until your account is approved.</FONT></CENTER><BR>";}
// password expired
else if ($status == 7 || $status == 8) {
$_SESSION['userID'] = $user_id;
$userID = $user_id;
$_SESSION['username'] = $user;
$_SESSION['status'] = $status;
$loggedin = 1;

//$sql = "INSERT INTO tb_audit (user_id, event, event_date) VALUES ($user_id, 'User successfully logged in', getdate())";
//$rs = $db->Execute($sql);

$message = 'User successfully logged in';
audit_log($user_id, $message, 54);

header("Location: change_password.php");
}
else if ($status == 6) {$message = "<BR><CENTER><FONT COLOR=FF0000>Your account is locked. Please contact the administrator.</FONT></CENTER><BR>";}

}
	else {
		/*
		if ('off' == $switch) {
			$message = "<BR><CENTER><FONT COLOR=FF0000>The HMIS Repository is currently closed<BR>(If you are an admin, please use valid admin userid/password)</FONT></CENTER><BR>";	
		} else {
			$message = "<BR><CENTER><FONT COLOR=FF0000>You have entered an invalid Username or Password.</FONT></CENTER><BR>";
		}
		*/
		$message = "<BR><CENTER><FONT COLOR=FF0000>You have entered an invalid Username or Password.</FONT></CENTER><BR>";
	}
}

if ($loggedin <> 1) {

print_header('OnLoad="login_form.user.focus()"');
echo $message;

?>
<script language="javascript" type="text/javascript">

window.onload = function() {

	document.getElementById("btn_login").disabled=true;	

	document.getElementById('login_form').onsubmit = function(){
		var msg = "";

		if (!document.getElementById('accept').checked) {
			msg += "Please check the box indicating that you have read and accept the Terms and Conditions.";

			if (msg != ""){
				alert(msg);
				return false;
			}
			else{
				document.getElementById("login_form").action="login.asp";
				return true;
			}
		}

	}
}



function disable_login() {
	var u_text = document.getElementById("user").value;
	var p_text = document.getElementById("password").value;


	if ((u_text == '') || (p_text == '')){
		document.getElementById("btn_login").disabled=true;		
	}
	else {
		document.getElementById("btn_login").disabled=false;
		}
}


</script>

<body onload="page_load();">
<BR>
<H1 align="center">Welcome to the HMIS Repository and <br>the Veteran Status Query and Response Exchange System (SQUARES)</H1>
<BR>

	<?


$sql = "SELECT html FROM tb_content WHERE page_id=1";
$rs = $db->Execute($sql);
$record_count = $rs->RecordCount();
if ($record_count == 1) {
	$html = scrub_white_list($rs->fields('html'), 'HTMLNOSCRIPT');
echo "<div id='welcome_text' style='margin-left:150px ;'>" . $html . "</div><hr><br>";
}


else {print "no content";}

?>

<div style="width:600px;height:400px;border:1px navy solid;text-align:left;background-color:#ffffff;overflow: auto; margin-left: auto; margin-right: auto;">


<H3 align=center><u>Veterans Status Query and Response Exchange System (SQUARES) - Terms and Conditions of Use</u></H3>


<p>This secure Web site enables authorized SQUARES users to identify clients who have served in the United States (U.S.) military through a real time query of  a client’s personal identifying information (PII) to the VA Department of Defense Identity Repository (VADIR). The result will not contain PII about the client. To use the site, you will provide the following information on the individuals whose history of military service you wish to inquire about: 

Note: * denotes a required field
</p>
<ol type="1">
<li>First Name
<li>Middle Name
<li>Last Name *
<li>Social Security Number *
<li>Date of Birth *
<li>Gender
<li>Zip Code of last permanent address

</ol>

<p>
VA will use the information you provide to identify individuals for whom it has a record of military service.
</p>

<p>
VA makes the following assurances about its use and handling of such data: 
</p>

<ol>
<li>Data Protection and System Security:  VA will protect PII on the VRSS in accordance with all applicable federal laws and regulations, VA policies and procedures, and National Institute of Standards and Technology (NIST) requirements and guidelines, including, but not limited to, the Privacy Act (5 U.S.C. § 552a), the Federal Information Security Management Act of 2002 (FISMA, 44 U.S.C. §§ 3541-49), 38 U.S.C. § 5701, and VA Directive and Handbook 6500.
<li>Breach Notification.  VA complies with federal statutes and regulations in reporting data breach and loss of PII, in particular 38 U.S.C. §§ 5721-27.
<li>Administrative Safeguards.  VA will restrict access to the data transmitted to it via this Web site to only those authorized employees and officials who need it to perform their official duties in connection with the uses of the information described above.
<li>Limited Use.  VA will use data transmitted to it via this Web site to identify individuals for whom it has a record of military service, and for no other purpose.  VA will not use the information in any determination of benefits nor will the PII be added to a Privacy Act system of records.
<li>Disposition of Data.  VA may retain data pertaining to your use of the HMIS and SQUARES applications for lawful purposes, such as to perform tests and to conduct and facilitate audits of the use of the HMIS and SQUARES applications.
<li>Data disposal. For cases where a match was found, the system shall only store an identifier linking the Veteran back to a record in the database used for the match. The system shall immediately purge all personally identifying information for Veterans and non-Veterans and any other data included in the query and not included in the audit trail after the response is provided. VA will dispose of PII and data pertaining to your use of the SQUARES application in accordance with NARA approved records control schedules.


</ol>

</div>
<BR>
<center><input type="checkbox" id="accept" name="accept" ><label for="accept" onchange="disable_login();"> 
I have read and accept the Terms and Conditions of Use</label></center>
<BR>
<div id="login" style="border:none; margin-left: auto; margin-right: auto; width: 700px; padding: 25px 25px 25px">

<FORM NAME="login" id="login_form" METHOD="POST" autocomplete="off">
	<input type="hidden" name="target" value="<?echo $target;?>">
	<table width="400" align="center" cellpadding="3" cellspacing="3">
	<tr>
	<td>
	<label for="user">Username</label>
	</td>
	<td>
	<input type="text" name="user" id="user" maxlength="16" class="largetext" onkeyup="disable_login();"/>
	</td>
	</tr>
	<tr>
	<td>
	<label for="password">Password</label>
	</td>
	<td>
	<input type="password" name="password" id="password" maxlength="16" class="largetext" onkeyup="disable_login();"/>
	</td>
	</tr>
	</table>

	<BR>
	<p align=center><input type="submit" name="btn_login" id="btn_login" value=" -- Login -- " /></p>

	<center>
	<b><a href="register_sq.php">Register a new SQUARES account</a> | <a href="register.php">Register a new Repository account</a> | <a href="forgotpassword.php">I forgot my password</a></b>
	</center>
</div>

<INPUT TYPE=hidden id="e_token" name="e_token" VALUE="<?php echo $_SESSION['e_token']; ?>">
</FORM>
</body>

<?php

print_footer();
}

?>
