<?php
include('init.php');
include('hmis/libs/functions.php');

 
	$email = scrub_sql(scrub_white_list(trim($_GET['email']),'USER'), 150);
	
	if($email=="")
		echo "";

	else
		$sql = "SELECT count(email) AS cnt FROM tb_user WHERE email='" . $email . "'";
		$rs = $db->Execute($sql);
		$cnt = $rs->fields('cnt');
	
	echo $cnt;
?>
