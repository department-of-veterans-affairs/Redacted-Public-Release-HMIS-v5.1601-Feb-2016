<?php

include('init.php');
include('hmis/libs/functions.php');

if ($user_id > 0) {
$sql = "INSERT INTO tb_audit (user_id, event, event_date) VALUES ($user_id, 'User logged out', getdate())";
$rs = $db->Execute($sql);
}

$_SESSION['userID'] = 0;
$_SESSION['username'] = "Guest";




header("Location: /");


?>