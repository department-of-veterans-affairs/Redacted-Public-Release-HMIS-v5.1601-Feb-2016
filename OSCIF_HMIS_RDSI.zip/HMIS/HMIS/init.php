<?

header("Set-Cookie: hidden=value; httpOnly");
//require_once('hmis/libs/config.php');
require_once('/var/hmis_libs/config.php');

if (isset($_SESSION['userID'])) {
$userID = $_SESSION['userID'];
$username = $_SESSION['username'];
$status = $_SESSION['status'];
$squares_user = $_SESSION['squares_user'];
}


else {
$userID = 0;
$username = "Guest";
$status = 0;
}

?>