<?

include('init.php');
include('hmis/libs/functions.php');

if (checklogin($userID, "menu.php") && $status == 2) {

$_SESSION['return_page']= $_SERVER['REQUEST_URI'];
print_header();

$sql = "SELECT value FROM HMIS_Config WHERE name = 'user_login_switch'";
$rs = $db->Execute($sql);
$switch = $rs->fields('value');
$on = '';
$off = '';
if ('off' == $switch) {
	$off = 'CHECKED';	
} else {
	$on = 'CHECKED';
}

?>

<style type="text/css">
#manage {
	width:755px;
	border-width: 1px;
	border-spacing: ;
	border-style: outset;
	border-color: gray;
	border-collapse: separate;
	background-color: white;
}
#manage th {
	border-width: 1px;
	padding: 1px;
	border-style: inset;
	border-color: gray;
	background-color: white;
	-moz-border-radius: ;
}
#manage td {
	border-width: 1px;
	padding: 1px;
	border-style: inset;
	border-color: gray;
	background-color: white;
	-moz-border-radius: ;
}
</style>



<H1 align=center>Manage Repository Configuration</H1>
<CENTER><A HREF="menu.php">Repository Home</A></CENTER>
<HR>
<br><br>
<TABLE ALIGN="CENTER" WIDTH="500">
<FORM ACTION='update_config.php' METHOD=POST>
<TR>
	<TD valign="top" align="left">1. <fieldset><legend>Turn Repository on & off:</legend></TD>
	<TD valign="top" align="left">
			<input type="radio" name="onoff" id='on' value="on" <?=$on?> /> <label for='on'>On</label>  
		&nbsp;  <input type="radio" name="onoff" id='off' value="off" <?=$off?> /> <label for='off'>Off</label> </fieldset>
		</TD>
</TR>



<TR>	
	<TD valign="top" align="left">
		&nbsp;
	</TD>
	<TD valign="top" align="left">
		<input type="submit" value="  Update  " />
	</TD>
</TR>
<INPUT TYPE=hidden id="e_token" name="e_token" VALUE="<?php echo $_SESSION['e_token']; ?>">

</FORM>

</TABLE>

<!---
<TABLE ALIGN="CENTER" NAME="manage" id="manage" WIDTH="755">
<TR>
<TH>Username</TH><TH>User Information</TH><TH>Actions</TH>
</TR>
</TABLE>
--->
<?
	print_footer();
} // end check login

?>