<?php

include('init.php');
include('hmis/libs/functions.php');
$e_token = trim(scrub_white_list($_POST['e_token'], 'ALPHANUMERICONLY'));
$s_e_token = $_SESSION['e_token'];

//echo $e_token . "<BR>";
//echo $s_e_token;

if ((ISSET($e_token)) && ($e_token===$s_e_token)){
	$fname = scrub_sql(scrub_white_list(trim($_POST['fname']),'ALPHAONLY'), 20);
	$lname = scrub_sql(scrub_white_list(trim($_POST['lname']),'ALPHAONLY'), 30);
	$email = scrub_sql(scrub_white_list(trim($_POST['email']),'USER'), 150);
	$phone = scrub_sql(scrub_white_list(trim($_POST['phone']),'USER'), 20);
	$organization = scrub_sql(scrub_white_list(trim($_POST['organization']),'USER'), 70);

	$user = scrub_sql(scrub_white_list(trim($_POST['user']),'DATA'), 16);
	$password = trim($_POST['password']);


	$errors=0;

	if ($fname == "" || $lname == "" || $email == "" || $phone == "" || $user == "" || $password == "") {
		$errors = 1;
		$message = "Incomplete Form. Please fill out all required fields.";
	}
	else if (strlen($fname) < 1 || strlen($lname) < 1 || strlen($email) < 4 || strlen($phone) < 10 || strlen($user) < 4 || strlen($password) < 8 || strlen($fname) > 20 || strlen($lname) > 30 || strlen($email) > 120 || strlen($phone) > 20 || strlen($user) > 15 || strlen($password) > 20) {
		$errors = 1;
		$message = "One or more fields are incorrect length.";
	}
	else if (check_bad_char($user)) {
		$errors = 1;
		$message = "Username contains invalid characters.";
	}
	else if (!check_password($password)) {
		$errors = 1;
		$message = "Password does not meet requirements";
	}
	else if (check_bad_char($email)) {
		$errors = 1;
		$message = "Email contains invalid characters.";
	}


	// check if username exists
	if ($errors == 0) {
			$sql = "SELECT count(username) AS cnt FROM tb_user WHERE username='$user'";
			$rs = $db->Execute($sql);
			$cnt = $rs->fields('cnt');
		if ($cnt > 0) {
			$errors = 1;
			$message = "Username already exists.";
		}
	}

	// check if email exists
	if ($errors == 0) {
		$sql = "SELECT count(email) AS cnt FROM tb_user WHERE email='$email'";
		$rs = $db->Execute($sql);
		$cnt = $rs->fields('cnt');
		if ($cnt > 0) {
		$errors = 1;
		$message = "Email address already exists.";
		}
	}


	if ($errors == 0) {
		$password = hash('sha256', "just4uAlanna".$password);	//md5("just4uAlanna".$password);
		$sql = "INSERT INTO tb_user (username, password, fname, lname, email, phone, organization, register_date, status) VALUES ('$user', '$password', '$fname', '$lname', '$email', '$phone', '$organization', getdate(), 0)";
		$rs = $db->Execute($sql);

		$sql = "SELECT user_id FROM tb_user WHERE username='$user'";
		$rs = $db->Execute($sql);
		$user_id = $rs->fields('user_id');

		$code = createRandom(16);
		$sql = "INSERT INTO tb_email_confirmation VALUES ($user_id, '$code', 0)";
		$rs = $db->Execute($sql);

		$sql = "INSERT INTO tb_password_update VALUES ($user_id, getdate())";
		$rs = $db->Execute($sql);

		if (isset($_POST['program_id1']) && $_POST['program_id1'] > 0) {
		$program_id = scrub_white_list($_POST['program_id1'], 'NUMBERONLY');
		$sql = "INSERT INTO tb_user_programs VALUES ($user_id, $program_id, getdate())";
		//print(" 1 $sql");
		$rs = $db->Execute($sql);
		}

		if (isset($_POST['program_id2']) && $_POST['program_id2'] > 0) {
		$program_id = scrub_white_list($_POST['program_id2'], 'NUMBERONLY');
		$sql = "INSERT INTO tb_user_programs VALUES ($user_id, $program_id, getdate())";
		//print(" 2 $sql");
		$rs = $db->Execute($sql);
		}

		if (isset($_POST['program_id3']) && $_POST['program_id3'] > 0) {
		$program_id = scrub_white_list($_POST['program_id3'], 'NUMBERONLY');
		$sql = "INSERT INTO tb_user_programs VALUES ($user_id, $program_id, getdate())";
		//print(" 3 $sql");
		$rs = $db->Execute($sql);
		}

		if (isset($_POST['program_id4']) && $_POST['program_id4'] > 0) {
		$program_id = scrub_white_list($_POST['program_id4'], 'NUMBERONLY');
		$sql = "INSERT INTO tb_user_programs VALUES ($user_id, $program_id, getdate())";
		//print(" 4 $sql");
		$rs = $db->Execute($sql);
		}

		if (isset($_POST['program_id5']) && $_POST['program_id5'] > 0) {
		$program_id = scrub_white_list($_POST['program_id5'], 'NUMBERONLY');
		$sql = "INSERT INTO tb_user_programs VALUES ($user_id, $program_id, getdate())";
		//print(" 5 $sql");
		$rs = $db->Execute($sql);
		}


		//$sql = "INSERT INTO tb_audit (user_id, event, event_date) VALUES ($user_id, 'User self-registered', getdate())";
		//$rs = $db->Execute($sql);

		$eventmsg = 'User registered new account';
		audit_log($user_id, $eventmsg, 53);


		$sql = "SELECT user_id, fname, lname, email, username from tb_user where user_id=$user_id";
		$rs2 = $db->Execute($sql);
		$uNameDisp = $rs2->fields('username');
		$emailDisp = $rs2->fields('email');


		// ------------------EMAIL TO ADMIN FOR PENDING USER-------------------------------------
		$message = ("

		<HTML>
		<BODY>


		Dear HMIS Repository administrators,
		<BR><BR>

		A new user (<b>$uNameDisp</b>) has requested an account for the HMIS Repository.<br>
		<br>Please visit the <a href=http://ip_redacted/>HMIS Repository</a> <i>Manage Users</i> page to review this account and take appropriate action.
		<BR><BR>
		Thank you.
		<BR><HR><BR>
		</BODY></HTML>

		");

		$headers = "From: HMIS Repository <noreply@domain>\n" . "MIME-Version: 1.0\n" . "Content-type: text/html; charset=iso-8859-1";

		//PREPROD
		//mail("@domain;@domain;ugandhi@phaseonecg.com;jmarkowski@phaseonecg.com", "Notification of Repository Account Request", $message, $headers );

		//PROD
		//mail( "@domain;@domain;molly_mcevilley@abtassoc.com", "Notification of Repository Account Request", $message, $headers );

		//DEV
		mail( "@domain;@domain", "Notification of Repository Account Request", $message, $headers );

		// ------------------END EMAIL TO ADMIN FOR PENDING USER-------------------------------------

		// ------------------ EMAIL TO USER TO CONFIRM ACCOUNT -------------------------------------
		$message = ("

		<HTML>
		<BODY>


		Dear $fname,
		<BR><BR>

		We've recieved your request to create an account at <a href=http://ip_redacted>https://www.hmisrepository.domain</a>.<br> 
		<br>Please validate your email address by clicking the following link:<br><center>
		<A HREF=http://ip_redacted/confirm_account.php?c=$code>http://ip_redacted/confirm_account.php?c=$code</A></center>
		<BR><BR>
		With best wishes,
		<BR>
		Repository Administrators
		<BR><HR><BR>
		</BODY></HTML>

		");

		$headers = "From: HMIS Repository Admin <noreply@domain>\n" . "MIME-Version: 1.0\n" . "Content-type: text/html; charset=iso-8859-1";


		mail( $email, "Notification of Repository Account Request",
			$message, $headers );
		// ------------------ END EMAIL TO USER TO CONFIRM ACCOUNT -------------------------------------

		print_header();
		print (" 

		<table width=800 align=center>
		<tr><td
		<BR>
		<HR>
		<H1 align=center>Thank You!</H1>
		<HR>
		<H3 align=center>Your account registration has been submitted. You must next confirm your email address.<br>
		An email message has been sent to <i>$email</i>. Please check your email and click on the link to confirm your email address.</h3><br>
		<br>
		<center>
		<font size=1><u>If you can not recieve emails, or do not recieve the email within 15 minutes, please contact:</u><br><br> <b>VA Health Resource Center (HRC)</b> <br> 1-800-983-0935 <br> 7:00AM and 5:00PM (CST) Monday - Friday</font></center>
		<BR>
		<BR>
			<H3 align=center><a href='index.php' target='_self'>Back to Login Page</a></H3>
		<HR>
		</td></tr></table>
		");
		print_footer();
	} // end if no errors
	// display error message
	else {
		print_header();
		print "<br><hr><h1 align=center>$message</h1><hr><h3 align=center>Please press the Back button to return to previous page</h3>";
		print_footer();
	}
}
else { //etoken check: false
	$message = "Error: Invalid session!";
	print_header();
		print "<br><hr><h1 align=center>$message</h1><hr><h3 align=center>Please press the Back button to return to previous page.</h3>";
		print_footer();

}


?>
