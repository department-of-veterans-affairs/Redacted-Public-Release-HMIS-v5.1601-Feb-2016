<?php
include('init.php');
include('hmis/libs/functions.php');

$s_e_token = $_SESSION['e_token'];

if ((!ISSET($s_e_token)) OR (""==$s_e_token) or (is_null($s_e_token))){
	//code to generate random session token
	$charset='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
	$str = '';
	$count = strlen($charset);
	$length=8;
	while ($length--) {
	        $str .= $charset[mt_rand(0, $count-1)];
			

	}
	//echo strtoupper($str);
	$_SESSION['e_token'] = strtoupper($str);
	//echo $_SESSION['e_token'];
	//end code to generate random session token
}

$sql = "select program_id, program_name FROM tb_SSVF_program Order By program_name";
$rs = $db->Execute($sql);
$programs = "";
$javascript = "";
while (!$rs->EOF)
  { 
$program_id = $rs->fields('program_id');
$program_name = $rs->fields('program_name');

$programs = $programs . "<option value=\"$program_id\">$program_name</option>\n";

$rs->MoveNext();
  }


print_header();

?>




<script>

function stopRKey(evt) { 
  var evt = (evt) ? evt : ((event) ? event : null); 
  var node = (evt.target) ? evt.target : ((evt.srcElement) ? evt.srcElement : null); 
  if ((evt.keyCode == 13) && (node.type=="text"))  {return false;} 
} 

document.onkeypress = stopRKey; 

function pullAjax(){
        	var a;
	        try{
	          a=new XMLHttpRequest()
	        }
	        catch(b)
	        {
	          try
	          {
	            a=new ActiveXObject("Msxml2.XMLHTTP")
	          }catch(b)
	          {
	            try
	            {
	              a=new ActiveXObject("Microsoft.XMLHTTP")
	            }
	            catch(b)
	            {
	              alert("Browser error.");return false
	            }
	          }
	        }
	        return a;
	      }

 //this function does the ajax call, and checks if email already exists
      function email_check(x)
      {
        obj=pullAjax();
	 
        var uEmail = document.forms.registration.email.value;
        obj.onreadystatechange=function()
        {
          if(obj.readyState==4)
          {
            //returns email exists
            var tmp=obj.responseText;
	
		if (tmp > 0){
			document.getElementById("btnSubmit").disabled = true; 
			document.getElementById("emailError").innerHTML = "<b><font color='red'>Email address already exists.</font></b>"
			document.forms.registration.email.focus();
			return false;
			
			
		}
		else{
			document.getElementById("btnSubmit").disabled = false;
			document.getElementById("emailError").innerHTML = "";
 			
			username_check();
		}
          }
        };
	var email_URL = "check_email.php?email=" + uEmail + "&nocache=" + new Date().getTime();
        obj.open("GET",email_URL,true);
        obj.send(null);
      }

      function username_check(x)
      {
        obj=pullAjax();
	 
        var uName = document.forms.registration.user.value;
        obj.onreadystatechange=function()
        {
          if(obj.readyState==4)
          {
            //returns email exists
            var tmp=obj.responseText;
	
		if (tmp > 0){
			document.getElementById("unameError").innerHTML = "<b><font color='red'>Username already exists.</font></b>"
			document.getElementById("btnSubmit").disabled = true; 
			return false;

			
		}	
		else{
			document.getElementById("btnSubmit").disabled = false; 	
			document.getElementById("unameError").innerHTML = "";	

			email_check();
		}	
          }
        };
	var username_URL = "check_username.php?user=" + uName + "&nocache=" + new Date().getTime();
        obj.open("GET",username_URL,true);
        obj.send(null);
      }



function check_form() {
var errs=0;

var msg = "";

if (document.forms.registration.fname.value == "") {
	msg += "- Please enter your first name.\n";
}
if (document.forms.registration.lname.value == ""){
	msg += "- Please enter your last name.\n";
}


//-----------------------------email validation---------------------
var x = document.forms.registration.email.value;
var filter = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;
if (!filter.test(x)){ 
	msg += "- Please enter a valid email address.\n";
}

if (!document.forms.registration.email.value == ""){
	//email_check(document.forms.registration.email.value);
}

//----------------------------end email-----------------------------

if ((document.forms.registration.phone.value == "") || (document.forms.registration.phone.value.length < 10) || (document.forms.registration.phone.value.length > 10)){
	msg += "- Please enter a valid 10-digit phone number.\n";
}

if (document.forms.registration.organization.value.length > 70) {
	msg += "- Please enter an organization name shorter than 70 characters.\n";
}


//----------------------------- duplicate dropdown check--------------------------
//var ssvf1 = document.getElementById("program_id1").value;
//var ssvf2 = document.getElementById("program_id2").value;
//var ssvf3 = document.getElementById("program_id3").value;
//var ssvf4 = document.getElementById("program_id4").value;
//var ssvf5 = document.getElementById("program_id5").value;

var ssvf_array = [];

for (var i=1; i < 6; i++){
	if (document.getElementById('program_id' + [i]).value != 0){
		ssvf_array.push(document.getElementById('program_id' + [i]).value);
		//alert (document.getElementById('program_id' + [i]).value);
	}
}

var len=ssvf_array.length;

if (len > 1){
	ssvf_array.sort();
	var last=ssvf_array[0];
	var dupefound=0;
		for (var i=1; i<len; i++) {
   			if (ssvf_array[i] == last){
				dupefound=1;
			}
  			last = ssvf_array[i];
		}
	
	if (dupefound > 0){
		msg += "- Please ensure you do not select duplicate SSVF programs for enrollment.";
	}
}

//----------------------------- end duplicate dropdown check-----------------------

//-----------------------------username validation---------------------

if (document.forms.registration.user.value == ""){
	msg += "- Please enter a username.\n";
}
if (document.forms.registration.user.value.length < 4) {
	msg += "- Username must be at least 4 characters in length.\n";
}
if (document.forms.registration.user.value.length > 16) {
	msg += "- Your username is too long. Please enter a username less than 16 characters.\n";
}

if (!document.forms.registration.user.value == ""){
	//username_check(document.forms.registration.user.value);
}
//----------------------------end username-----------------------------


//--------------------------------password validation---------------------------

if (document.forms.registration.password.value == '') {
	msg+= "- Please enter a desired password.\n";
}
if (document.forms.registration.password.value != document.forms.registration.password2.value) {
	msg += "- Passwords do not match.\n";
}

var pwd1 = document.forms.registration.password.value;
var pwd2 = document.forms.registration.password2.value;



if ((document.forms.registration.password.value.length < 8) || (document.forms.registration.password2.value.length < 8)) {
        msg += "- Passwords must contain at least eight (8) characters, a number and upper and lower case letters.\n";
     }

if ((document.forms.registration.password.value.length > 20) || (document.forms.registration.password2.value.length > 20)) 
     {
        msg += "- Passwords must not contain more than twenty (20) characters.\n";
     }

     re = /[0-9]/;
     if ((!re.test(pwd1)) || (!re.test(pwd2))) 
     {
        msg += "- Password must contain at least one number (0-9).\n";
     }
     re = /[a-z]/;
     if ((!re.test(pwd1)) || (!re.test(pwd2))) 
     {
        msg+= "- Password must contain at least one lowercase letter (a-z).\n";
     }
     re = /[A-Z]/;
     if ((!re.test(pwd1)) || (!re.test(pwd2)))  
     {
        msg += "- Password must contain at least one uppercase letter (A-Z).\n";
     }

	// Create regular expression for password and login id
	var re = new RegExp("[^A-Za-z0-9 ]","i");

//-----------------------------end password validation----------------------------


if (msg != "") { 
	alert(msg);
	return false;
}

}

function checkMail()
{
}

function validPswrd(eSrc){
}


</script>


<p class="page-title"><!-- START: PAGE TITLE -->Repository New User Account Registration<!-- END: PAGE TITLE --></p>
        <!-- END: PAGE TITLE AREA -->
        
        <!-- START: PAGE CONTENT -->

<script type="text/javascript" src="password.js"></script>
<style>
#passwordStrength { height:10px; display:block; float:left; } .strength0 { width:250px; background:#cccccc; } .strength1 { width:50px; background:#ff0000; } .strength2 { width:100px; background:#ff5f5f; } .strength3 { width:150px; background:#56e500; } .strength4 { background:#4dcd00; width:200px; } .strength5 { background:#399800; width:250px; }
</style>


<form name="registration" action="newuser.php" method="post" onSubmit="return check_form();">

<table width=550>
<tr class="va-section-header" width="550">
<td colspan=5>Account Information</td>
</tr>
<tr>
<td width="500" colspan="5">
    Please complete the following fields to register for a Repository account.
<br>
Note: All fields are required.
    <br><br>
<tr>
<td width="200"><label for="fname">First Name</label></td>
<td width="400"><input type="text" id="fname" name="fname" size="30" maxlength="20" ></td>
</tr>

<tr>
<td width="200"><label for="lname">Last Name</label></td>
<td width="400"><input type="text" id="lname" name="lname" size="30" maxlength="20" ></td>
</tr>

<tr>
<td width="200"><label for="email">Email</label></td>
<td width="55%"><input type="text" id="email" name="email" size="30" maxlength="120" onchange="return email_check();" ></td>
<TD width="45%" id="emailError" name="emailError"></TD>
</tr>

<tr>
<td width="200"><label for="phone">Phone</label></td>
<td width="400"><input type="text" id="phone" name="phone" size="30" maxlength="20" ></td>
</tr>

<tr>
<td width="200"><label for="organization">Organization</label></td>
<td width="400"><input type="text" id="organization" name="organization" size="30" maxlength="70" ></td>
</tr>
</table>

<br /><br />


<table width=550>
<tr class="va-section-header" width="550">
<td colspan="3">SSVF Grant/Programs</td>
</tr>
<tr>
<td width="500" colspan="3">
    Select one or more SSVF Grant/Programs
<br>
Note: If you participate in more than 3 programs, please contact the Repository Administrator once you have completed your registration to have them added.

    <br><br>
<tr>
<td width="200"><label for="program_id1">1st SSVF Grant/Program</label></td>
<td>
<SELECT name="program_id1" id="program_id1" style="width:450px; display:block; " >
<OPTION VALUE="0">Select SSVF Program</OPTION>
<?echo $programs;?>
</SELECT>
</td>
</tr>



<tr>
<td width="200"><label for="program_id2">2nd SSVF Grant/Program</label></td>
<td>
<SELECT name="program_id2" id="program_id2" style="width:450px; display:block;" >
<OPTION VALUE="0">Select SSVF Program</OPTION>
<?echo $programs;?>
</SELECT>
</td>
</tr>

<tr>
<td width="200"><label for="program_id3">3rd SSVF Grant/Program</label></td>
<td>
<SELECT name="program_id3" id="program_id3" style="width:450px; display:block;" >
<OPTION VALUE="0">Select SSVF Program</OPTION>
<?echo $programs;?>
</SELECT>
</td>
</tr>

<tr>
<td width="200"><label for="program_id4">4th SSVF Grant/Program</label></td>
<td>
<SELECT name="program_id4" id="program_id4" style="width:450px; display:block;" >
<OPTION VALUE="0">Select SSVF Program</OPTION>
<?echo $programs;?>
</SELECT>
</td>
</tr>

<tr>
<td width="200"><label for="program_id5">5th SSVF Grant/Program</label></td>
<td>
<SELECT name="program_id5" id="program_id5" style="width:450px; display:block;" >
<OPTION VALUE="0">Select SSVF Program</OPTION>
<?echo $programs;?>
</SELECT>
</td>
</tr>

</table>

<br /><br />

<TABLE width=550>

<tr class="va-section-header" width="550">
<td colspan=2>Create a New Username</td>
</tr>

<tr>
<td width="500">
    Please create a username to log into your account.
<br>
Note: Usernames must be between 4 and 16 characters in length, and may not contain spaces or special characters.
    <br><br>
<TABLE>

<TR><TD><label for="user">Desired Username</label></TD>
<TD>
<input type="text" id="user" name="user" size="20" value="" onchange="return username_check();" >
</TD>
<TD width="200" id="unameError" name="unameError"></td>
</TR>
</TABLE>
<br /><br />
</td></tr>
<tr class="va-section-header" width="550">
<td colspan=2>Create a New Password</td>
</tr>

<tr>
<td width="500">
    
    Please create a new password to log into your account.
<br>
Note: Passwords must be between 8 and 20 characters in length and contain both uppercase and lowercase letters, and at least one number.
    <br />
    <br />
    <TABLE>
        
        <TR><TD><label for="password">Desired Password</label></TD>
<TD><input type="password" id="password" name="password" size="20" value="" onkeyup="passwordStrength(this.value)" >

</TD><TD>

                           </TD>
</TR>

<TR><TD></TD>
<TD><div id="passwordDescription">Password not entered</div> <div id="passwordStrength" class="strength0"></div><br /></TD></TR>

<TR><TD><label for="password2">Confirm Password</label></TD>
<TD><input type="password" id="password2" name="password2" size="20" value="" >
</TD><TD>
                           </TD>
</TR>


</TABLE>
<br />
</td></tr

<TR><TD colspan=3 align=center>
<HR>
<INPUT TYPE=SUBMIT VALUE="Create Account" id="btnSubmit" name="btnSubmit" > <INPUT TYPE=RESET VALUE=Cancel >
<HR>
</TD></TR>


</TABLE>
<INPUT TYPE=hidden id="e_token" name="e_token" VALUE="<?php echo $_SESSION['e_token']; ?>">
</form>

<td valign="top" align="left" width="168"><table bordercolor="#000066" cellspacing="0" cellpadding="0" width="320" border="1">

<tbody>
<tr>
<td width="320"><table cellspacing="0" cellpadding="0" width="320" border="0">
<tbody>

<tr>
<td width="320"><br /><ul>
<TABLE>
<TR><TD>
    
<B>Need Help?</B>
<BR><BR>
<A HREF=support.php>Click here for Support</A>
<BR><BR>

<b><u>VA Health Resource Center Help Desk</u></b>
<br><b>Phone:</b> 1-800-983-0935
<br><b>Hours:</b> 7 AM - 5 PM (CST), Monday - Friday

<BR>
<BR>
<table width="135" border="0" cellpadding="2" cellspacing="0" title="Click to Verify - This site chose VeriSign SSL for secure e-commerce and confidential communications.">
<tr>
<td align="center" valign="top"><img src="vcs_ss_v.png">
</td>
</tr>
</table>




</TD></TR>
</TABLE>



<br /></td>
</tr>

</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>

</tbody>
</table>








</td>
</tr>
</tbody>
</table>


			
<?php

print_footer();

?>
