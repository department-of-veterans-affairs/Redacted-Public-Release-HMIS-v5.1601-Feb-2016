<?
include('init.php');
include('hmis/libs/functions.php');

print_header();

$_SESSION['return_page']= $_SERVER['REQUEST_URI'];

$t = $_SESSION['e_token'];

	?>
	<head>
	<style type="text/css"> 
	   
	th {
			background-color: #DDDDDD;
	}
	th.headerSortDown {    
			background: url('/tablesorter/yui/desc.gif') no-repeat right 50%;    
			background-color: #AAAAAA;
			/* color: #FFFFFF; */
		} 
	th.headerSortUp {     
			background: url('/tablesorter/yui/asc.gif') no-repeat right 50%;   
			background-color: #AAAAAA;
			/* color: #FFFFFF; */
	} 

	</style>

	<SCRIPT LANGUAGE="JavaScript" SRC="/hmis/CalendarPopup.js"></SCRIPT>
	<script type="text/javascript" src="/tablesorter/jquery-1.2.6.min.js"></script>
	<script type="text/javascript" src="/tablesorter/jquery.tablesorter.pager.js"></script>
	<script type="text/javascript" src="/tablesorter/jquery.tablesorter.js"></script>
	<LINK rel="stylesheet" type="text/css" href="/tablesorter/yui/style.css"> 




	<script>

		//var pager = new Pager('ahistory', 25); 
		var cal = new CalendarPopup();
		// Declaring valid date character, minimum year and maximum year
		var dtCh= "/";
		var minYear=1900;
		var maxYear=2100;

		function reset_page(){
		   pager.init(); 
		   pager.showPageNav('pager', 'pageNavPosition'); 
		   pager.showPage(1);

		   
		}
		
		function isInteger(s){
			var i;
			for (i = 0; i < s.length; i++){   
			// Check that current character is number.
			var c = s.charAt(i);
			if (((c < "0") || (c > "9"))) return false;
			}
			// All characters are numbers.
			return true;
		}
		
		function stripCharsInBag(s, bag){
			var i;
			var returnString = "";
			// Search through string's characters one by one.
			// If character is not in bag, append to returnString.
			for (i = 0; i < s.length; i++){   
			var c = s.charAt(i);
			if (bag.indexOf(c) == -1) returnString += c;
			}
			return returnString;
		}
		
		function daysInFebruary (year){
			// February has 29 days in any year evenly divisible by four,
			// EXCEPT for centurial years which are not also divisible by 400.
			return (((year % 4 == 0) && ( (!(year % 100 == 0)) || (year % 400 == 0))) ? 29 : 28 );
		}
		function DaysArray(n) {
			for (var i = 1; i <= n; i++) {
				this[i] = 31
				if (i==4 || i==6 || i==9 || i==11) {this[i] = 30}
				if (i==2) {this[i] = 29}
		   } 
		   return this
		}
		
		function isDate(dtStr){
			var daysInMonth = DaysArray(12)
			var pos1=dtStr.indexOf(dtCh)
			var pos2=dtStr.indexOf(dtCh,pos1+1)
			var strMonth=dtStr.substring(0,pos1)
			var strDay=dtStr.substring(pos1+1,pos2)
			var strYear=dtStr.substring(pos2+1)
			strYr=strYear
			if (strDay.charAt(0)=="0" && strDay.length>1) strDay=strDay.substring(1)
			if (strMonth.charAt(0)=="0" && strMonth.length>1) strMonth=strMonth.substring(1)
			for (var i = 1; i <= 3; i++) {
				if (strYr.charAt(0)=="0" && strYr.length>1) strYr=strYr.substring(1)
			}
			month=parseInt(strMonth)
			day=parseInt(strDay)
			year=parseInt(strYr)
			if (pos1==-1 || pos2==-1){
				alert("The date format should be : mm/dd/yyyy")
				return false
			}
			if (strMonth.length<1 || month<1 || month>12){
				alert("Please enter a valid month")
				return false
			}
			if (strDay.length<1 || day<1 || day>31 || (month==2 && day>daysInFebruary(year)) || day > daysInMonth[month]){
				alert("Please enter a valid day")
				return false
			}
			if (strYear.length != 4 || year==0 || year<minYear || year>maxYear){
				alert("Please enter a valid 4 digit year between "+minYear+" and "+maxYear)
				return false
			}
			if (dtStr.indexOf(dtCh,pos2+1)!=-1 || isInteger(stripCharsInBag(dtStr, dtCh))==false){
				alert("Please enter a valid date")
				return false
			}
		return true
		}

	function pullAjax(){
				var a;
				try{
				  a=new XMLHttpRequest()
				}
				catch(b)
				{
				  try
				  {
					a=new ActiveXObject("Msxml2.XMLHTTP")
				  }catch(b)
				  {
					try
					{
					  a=new ActiveXObject("Microsoft.XMLHTTP")
					}
					catch(b)
					{
					  alert("Your browser broke!");return false
					}
				  }
				}
				return a;
			  }
	 //this function does the ajax call, and appends counties into the counties dropdown
		  function display_activity(x)
		  {
			obj=pullAjax();

			var startDate=document.getElementById('p_start_date').value;
		sdAJAX = new Date(startDate);
		sdAJAX = ((sdAJAX.getMonth() + 1) + '-' + sdAJAX.getDate() + '-' +  sdAJAX.getFullYear());
		//alert (sdAJAX);

		 var endDate=document.getElementById('p_end_date').value;
		edAJAX = new Date(endDate);
		edAJAX = ((edAJAX.getMonth() + 1) + '-' + edAJAX.getDate() + '-' + edAJAX.getFullYear());
		//alert (edAJAX);

			obj.onreadystatechange=function()
			{
			  if(obj.readyState==4)
			  {
				//returns comma separated list of counties after successful ajax request
				var tmp=obj.responseText;

				//split function returns program stuff
			   document.getElementById("dispResults").innerHTML=tmp;

		$("#tableOne").tablesorter({ debug: false, sortList: [[1, 0]], widgets: ['zebra'] })
			 .tablesorterPager({ container: $("#pagerOne"), positionFixed: false })
				.tablesorterFilter({ filterContainer: $("#filterBoxOne"),
					filterClearContainer: $("#filterClearOne"),
					filterColumns: [0, 1, 2, 3, 4, 5, 6],
					filterCaseSensitive: false 
			});
			   }
			  else
			{
			document.getElementById("dispResults").innerHTML = "<center><img src='378.gif' alt='Updating results...'></center>";
			}
			};
		var t = document.getElementById('e_token').value;
		
		var activity_URL = "show_prg_hist.php?sd=" + sdAJAX + "&ed=" + edAJAX + "&t=" + t + "&nocache=" + new Date().getTime();
			obj.open("GET",activity_URL,true);
			obj.send(null);
	}


	function check_form(){
		var msg = "";
		var startDate=document.getElementById('p_start_date').value;
		var endDate=document.getElementById('p_end_date').value;

		var sdTest = new Date(startDate);
		var edTest = new Date(endDate);

		sdTest = sdTest.getTime();
		edTest = edTest.getTime();


		if ((startDate=='') || (endDate=='')){
			msg += "- Please make sure both a start date and an end date are chosen.\n";
		}
		else{
			if (startDate != ''){
				var date_error=0;
				var daysInMonth = DaysArray(12)
				var pos1=startDate.indexOf(dtCh)
				var pos2=startDate.indexOf(dtCh,pos1+1)
				var strMonth=startDate.substring(0,pos1)
				var strDay=startDate.substring(pos1+1,pos2)
				var strYear=startDate.substring(pos2+1)
				strYr=strYear
				if (strDay.charAt(0)=="0" && strDay.length>1) strDay=strDay.substring(1)
					if (strMonth.charAt(0)=="0" && strMonth.length>1) strMonth=strMonth.substring(1)
						for (var i = 1; i <= 3; i++) {
							if (strYr.charAt(0)=="0" && strYr.length>1) strYr=strYr.substring(1)
						}	
				month=parseInt(strMonth)
				day=parseInt(strDay)
				year=parseInt(strYr)
			
				if (pos1==-1 || pos2==-1){
					date_error=1;
				}
				if (strMonth.length<1 || month<1 || month>12){
					date_error=1;
				}
				if (strDay.length<1 || day<1 || day>31 || (month==2 && day>daysInFebruary(year)) || day > daysInMonth[month]){
					date_error=1;
				}
				if (strYear.length != 4 || year==0 || year<minYear || year>maxYear){
					date_error=1;
				}
				if (startDate.indexOf(dtCh,pos2+1)!=-1 || isInteger(stripCharsInBag(startDate, dtCh))==false){
					date_error=1;
				}
					
				if (1==date_error){
						msg += "- Please enter a correct program start date. (MM/DD/YYYY)\n";
				}
			}
			
			if (endDate != ''){
				var date_error=0;
				var daysInMonth = DaysArray(12)
				var pos1=endDate.indexOf(dtCh)
				var pos2=endDate.indexOf(dtCh,pos1+1)
				var strMonth=endDate.substring(0,pos1)
				var strDay=endDate.substring(pos1+1,pos2)
				var strYear=endDate.substring(pos2+1)
				strYr=strYear
				if (strDay.charAt(0)=="0" && strDay.length>1) strDay=strDay.substring(1)
					if (strMonth.charAt(0)=="0" && strMonth.length>1) strMonth=strMonth.substring(1)
						for (var i = 1; i <= 3; i++) {
							if (strYr.charAt(0)=="0" && strYr.length>1) strYr=strYr.substring(1)
						}
					month=parseInt(strMonth)
					day=parseInt(strDay)
					year=parseInt(strYr)
				if (pos1==-1 || pos2==-1){
					date_error=1;
				}
				if (strMonth.length<1 || month<1 || month>12){
					date_error=1;
				}
				if (strDay.length<1 || day<1 || day>31 || (month==2 && day>daysInFebruary(year)) || day > daysInMonth[month]){
					date_error=1;
				}
				if (strYear.length != 4 || year==0 || year<minYear || year>maxYear){
					date_error=1;
				}
				if (endDate.indexOf(dtCh,pos2+1)!=-1 || isInteger(stripCharsInBag(endDate, dtCh))==false){
					date_error=1;
				}
			
				if (1==date_error){
					msg += "- Please enter a correct program end date. (MM/DD/YYYY)\n";
				}
			}
			
			
			if (0==date_error){
				if (sdTest > edTest){
					msg += "- Please make sure the chosen start date is before the chosen end date.\n";
				}
			}
		}

		if (msg != ""){
			alert(msg);
			return false;
		}
		else{
			display_activity();
		}

	}
	</script>
	</head>
	<?
	if (checklogin($userID, "menu.php") && ($status == 1 || $status == 2)) {
	?>

	<style type="text/css">
	.auto-style1 {
		
		border: 1px solid #999999;
		border-style: inset;
		border-color: gray;
		background-color: white;
		-moz-border-radius: ;
	}
	</style>

	<style type="text/css">
	#manage {
		width:755px;
		border-width: 1px;@pple1105513
		
		border-spacing: ;
		border-style: outset;
		border-color: gray;
		border-collapse: separate;
		background-color: white;
	}
	#manage th {
		border-width: 1px;
		padding: 1px;
		border-style: inset;
		border-color: gray;
		background-color: white;
		-moz-border-radius: ;
	}
	#manage td {
		border-width: 1px;
		padding: 1px;
		border-style: inset;
		border-color: gray;
		background-color: white;
		-moz-border-radius: ;
	}
	</style>

	<body>
	<H1 align=center>Program Activity Report</H1>
	<CENTER><A HREF="menu.php">Repository Home</A></CENTER>
	<HR>

	<form id="report_date" name="report_date">
	<TABLE ALIGN="CENTER">
	<tr>
	<td width="200" align=center><label for='p_start_date'>Start Date</label></td>
	<td>
	<input type="text" id="p_start_date" name="p_start_date" size="12" tabindex="1"> 
	<input type="button" value="Calendar" onclick="cal.select(document.forms.report_date.p_start_date,'anchor1','MM/dd/yyyy'); return false;" name="anchor1" id="anchor1" tabindex="2">
	</td>
	</tr>

	<tr>
	<td width="200" align=center><label for='p_end_date'>End Date</label></td>
	<td>
	<input type="text" id="p_end_date" name="p_end_date" size="12" tabindex="3"> 
	<input type="button" value="Calendar" onclick="cal.select(document.forms.report_date.p_end_date,'anchor2','MM/dd/yyyy'); return false;" name="anchor2" id="anchor2" tabindex="4">
	</td>
	</tr>

	<tr><td width="200" colspan=2 align='center'>
	<input type="button" value="Generate Report" name="btn_generate" id="btn_generate" tabindex="5" onclick="return check_form();">
	</td></tr>
	</SELECT>
	</TD></TR>
	</TABLE>
	<INPUT TYPE=hidden id="e_token" name="e_token" VALUE="<?php echo $_SESSION['e_token']; ?>">
	</form>
	<br>
	<hr>


	<div id="dispResults">
	<center><b>Please use the above calendar buttons to select a date range...<b></center>
	</div>

	<div id='pageNavPosition' align='center'></div>

	<hr>

	<?
		print '<center>';
		if ($p > 1) {
			$lastp=$p-1;
			print "<a href=activity_history.php?file_status=$file_status&p=$lastp><< Previous Page</a> ";
		}

		if (20 == $results) {
			$nextp=$p+1;
			print "<a href=activity_history.php.php?file_status=$file_status&p=$nextp> Next Page >></a>";
		}

		

	} else {
		echo 'You need admin permission to access this page.';
		print '<br><br><CENTER><A HREF="menu.php">Repository Home</A></CENTER>';
	}// end check login

	print_footer();
	?>

</body>