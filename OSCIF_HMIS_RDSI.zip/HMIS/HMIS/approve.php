<?php

include('init.php');
include('hmis/libs/functions.php');

$e_token = trim(scrub_white_list($_POST['e_token'], 'ALPHANUMERICONLY'));
$s_e_token = $_SESSION['e_token'];

//echo "e_token-> " . $e_token;
//echo "<BR>s_e_token -> " . $s_e_token;

if ((ISSET($e_token)) && ($e_token===$s_e_token)){

	if (checklogin($userID, "menu.php") && $status == 2) {

			if (isset($_POST['u'])) { 
		$uid = scrub_sql(scrub_white_list($_POST['u'], 'NUMBERONLY'), 8);
		$sql = "UPDATE tb_user SET status=1 WHERE user_id=$uid";
		$rs = $db->Execute($sql);

		//$sql = "INSERT INTO tb_audit (user_id, event, event_date) VALUES ($userID, 'Admin approved account $uid', getdate())";
		//$rs = $db->Execute($sql);


		$eventmsg = 'Admin approved account';
		audit_log($userID, $eventmsg, 4, $uid);


		$sql = "SELECT user_id, fname, lname, email, username, squares_user from tb_user where user_id=$uid";
		$rs2 = $db->Execute($sql);
		$uNameDisp = $rs2->fields('username');
		$email = $rs2->fields('email');
		$fname = $rs2->fields('fname');
		$squares = $rs2->fields('squares_user');
		
		if (1 == $squares) {
			$app_name = 'SQUARES';
		} else {
			$app_name = 'HMIS Repository';
		}
		
		$message = ("

		<HTML>
		<BODY>


		Dear $fname,
		<BR><BR>

		Your account request for the $app_name has been approved.<br><br>

		You may now log in with the username (<b>$uNameDisp</b>) and password that you selected at the time of your account registration.
		<br><br>Please visit <a href=http://ip_redacted>https://www.hmisrepository.domain</a> to use the $app_name.
		<BR><BR>
		With best wishes,
		<BR>
		Repository Administrators
		<BR><HR><BR>
		</BODY></HTML>

		");

		$headers = "From: HMIS Repository <noreply@domain>\n" . "MIME-Version: 1.0\n" . "Content-type: text/html; charset=iso-8859-1";


		//PREPROD
		//mail( "@domain;@domain;ahemenway@phaseonecg.com;bmunt@phaseonecg.com;dabernathy@phaseonecg.com;aaxsom@phaseonecg.com", "Notification of Repository Account Approval", $message, $headers );

		//PROD
		//mail( "@domain;@domain;molly_mcevilley@abtassoc.com", "Notification of Repository Account Approval", $message, $headers );

		//DEV
		mail( $email, 'Notification of ' . $app_name . ' Account Approval', $message, $headers );



		print_header();

		?>
		<table width=800 align=center>
		<tr><td>
		<BR>
		<HR>
		<H1 align=center>Approved</H1>
		<BR>
		<HR>
		<H3 align=center>This account has been approved.</H3>
		<BR>
		<CENTER><A HREF=manage_users.php>Click here to continue</A></CENTER>
		<HR>
		</td></tr></table>

		<?

		print_footer();

		} // end has uid

	} // end is logged in
	
}

else{ //etoken check: false
	$message = "Error: Invalid session!";
	print_header();
		print "<br><hr><h1 align=center>$message</h1><hr><h3 align=center>Please press the Back button to return to previous page.</h3>";
		print_footer();

}	

?>