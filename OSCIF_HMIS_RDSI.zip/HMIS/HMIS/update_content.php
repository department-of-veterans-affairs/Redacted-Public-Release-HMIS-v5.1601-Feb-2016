<?php

include('init.php');
include('hmis/libs/functions.php');

$e_token = trim(scrub_white_list($_POST['e_token'], 'ALPHANUMERICONLY'));
$s_e_token = $_SESSION['e_token'];
if ((ISSET($e_token)) && ($e_token===$s_e_token)){


	if (checklogin($userID, "menu.php" && $status == 2)) {

	//$elm1 = scrub_sql($_REQUEST['elm1']);
	//$elm2 = scrub_sql($_REQUEST['elm2']);
	//$elm3 = scrub_sql($_REQUEST['elm3']);
	$elm1 = scrub_sql(scrub_white_list($_REQUEST['elm1'], 'HTMLNOSCRIPT'));
	$elm2 = scrub_sql(scrub_white_list($_REQUEST['elm2'], 'HTMLNOSCRIPT'));
	$elm3 = scrub_sql(scrub_white_list($_REQUEST['elm3'], 'HTMLNOSCRIPT'));

	$sql = "UPDATE tb_content SET html='$elm1', last_updated=getdate() WHERE page_id=1";
	$rs = $db->Execute($sql);
	
	$sql = "UPDATE tb_content SET html='$elm2', last_updated=getdate() WHERE page_id=2";
	$rs = $db->Execute($sql);

	$sql = "UPDATE tb_content SET html='$elm3', last_updated=getdate() WHERE page_id=3";
	$rs = $db->Execute($sql);

	$t = createRandom(3);


	$message = 'Admin edited website content';
	audit_log($userID, $message, 14);

	header("Location: edit_content.php?$t");

	} // end check login
}
else{ //etoken check: false
	$message = "Error: Invalid session!";
	print_header();
		print "<br><hr><h1 align=center>$message</h1><hr><h3 align=center>Please press the Back button to return to previous page.</h3>";
		print_footer();

}
?>