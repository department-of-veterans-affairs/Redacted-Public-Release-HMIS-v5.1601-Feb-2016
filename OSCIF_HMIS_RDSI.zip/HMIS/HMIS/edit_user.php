<?php
include('init.php');
include('hmis/libs/functions.php');


if (checklogin($userID, "menu.php") && $status == 2) {


if (isset($_REQUEST['uid'])) { 
$uid = scrub_sql(scrub_white_list($_REQUEST['uid'], 'NUMBERONLY'), 8);


if (isset($_SESSION['return_page'])) {
$url = $_SESSION['return_page'];
}
else {
$url = "manage_users.php";
}


$sql = "SELECT username, fname, lname, email, phone, organization, status, squares_user FROM tb_user WHERE user_id=$uid";
$rs = $db->Execute($sql);
$username = $rs->fields('username');
$fname = $rs->fields('fname');
$lname = $rs->fields('lname');
$email = $rs->fields('email');
$phone = $rs->fields('phone');
$phone = scrub_sql(scrub_white_list($phone, 'NUMBERONLY'), 10);
$organization = $rs->fields('organization');
$level = $rs->fields('status');
$squares_user = $rs->fields('squares_user');

//echo $squares_user;

if ("0"==$squares_user){ 
	$option1 = "";
	$option2 = "";
	$option3 = "";
	$pid1=0;
	$pid2=0;
	$pid3=0;
	$pid4=0;
	$pid5=0;
	$pid6=0;
	$pid7=0;


	$sql = "select p.program_id, p.program_name from tb_user_programs u, tb_ssvf_program p WHERE u.user_id=$uid AND p.program_id=u.program_id";
	$rs = $db->Execute($sql);
	$results = 0;
	while (!$rs->EOF)
	  { 
	$program_id = $rs->fields('program_id');
	$program = $rs->fields('program_name');
	if ($results == 0) {
	$option1 = "<option value=\"$program_id\" selected>$program</option>";
	$pid1=$program_id;
	}
	else if ($results == 1) {$option2 = "<option value=\"$program_id\" selected>$program</option>";
	$pid2=$program_id;
	}
	else if ($results == 2) {$option3 = "<option value=\"$program_id\" selected>$program</option>";
	$pid3=$program_id;
	}
	else if ($results == 3) {$option4 = "<option value=\"$program_id\" selected>$program</option>";
	$pid4=$program_id;
	}
	else if ($results == 4) {$option5 = "<option value=\"$program_id\" selected>$program</option>";
	$pid5=$program_id;
	}
	else if ($results == 5) {$option6 = "<option value=\"$program_id\" selected>$program</option>";
	$pid6=$program_id;
	}
	else if ($results == 6) {$option7 = "<option value=\"$program_id\" selected>$program</option>";
	$pid7=$program_id;
	}
	else if ($results == 7) {$option8 = "<option value=\"$program_id\" selected>$program</option>";
	$pid8=$program_id;
	}
	else if ($results == 8) {$option9 = "<option value=\"$program_id\" selected>$program</option>";
	$pid9=$program_id;
	}
	else if ($results == 9) {$option10 = "<option value=\"$program_id\" selected>$program</option>";
	$pid10=$program_id;
	}
	else if ($results == 10) {$option11 = "<option value=\"$program_id\" selected>$program</option>";
	$pid11=$program_id;
	}
	else if ($results == 11) {$option12 = "<option value=\"$program_id\" selected>$program</option>";
	$pid12=$program_id;
	}
	else if ($results == 12) {$option13 = "<option value=\"$program_id\" selected>$program</option>";
	$pid13=$program_id;
	}
	else if ($results == 13) {$option14 = "<option value=\"$program_id\" selected>$program</option>";
	$pid14=$program_id;
	}
	else if ($results == 14) {$option15 = "<option value=\"$program_id\" selected>$program</option>";
	$pid15=$program_id;
	}
	else if ($results == 15) {$option16 = "<option value=\"$program_id\" selected>$program</option>";
	$pid16=$program_id;
	}
	else if ($results == 16) {$option17 = "<option value=\"$program_id\" selected>$program</option>";
	$pid17=$program_id;
	}
	else if ($results == 17) {$option18 = "<option value=\"$program_id\" selected>$program</option>";
	$pid18=$program_id;
	}
	else if ($results == 18) {$option19 = "<option value=\"$program_id\" selected>$program</option>";
	$pid19=$program_id;
	}
	else if ($results == 19) {$option20 = "<option value=\"$program_id\" selected>$program</option>";
	$pid20=$program_id;
	}

	$results = $results + 1;
	$rs->MoveNext();
	  }

	$sql = "select program_id, program_name FROM tb_SSVF_program Order By program_name";
	$rs = $db->Execute($sql);
	$programs = "";
	while (!$rs->EOF)
	  { 
	$program_id = $rs->fields('program_id');
	$program_name = $rs->fields('program_name');

	$programs = $programs . "<option value=\"$program_id\">$program_name</option>\n";

	$rs->MoveNext();
	  }
}
//if squaresonly
else{

}

print_header();

?>




<script>
function showhide_progs() {
	var div = document.getElementById("morePrograms");
	if (div.style.display == 'block' || div.style.display == ''){
		div.style.display = 'none';
	}
	else {
		div.style.display = 'block';
	}

}



function check_form() {
var errs=0;
var valid = true;
var msg = "";

	if (document.forms.registration.fname.value == '') {
		//alert('Please enter a first name'); 
		msg = msg + "- Please enter a first name.\n";
		errs=1;
	}

	if (document.forms.registration.fname.value.length > 20) {
		//alert('Please enter a first name'); 
		msg = msg + "- Please enter a first name less than 20 characters.\n";
		errs=1;
	}
	if (document.forms.registration.lname.value == '') {
		//alert('Please enter a last name'); 
		msg = msg + "- Please enter a last name.\n";
		errs=1;
	}

	if (document.forms.registration.lname.value.length > 20) {
		//alert('Please enter a first name'); 
		msg = msg + "- Please enter a last name name less than 30 characters.\n";
		errs=1;
	}

//-----------------------------email validation---------------------
	var x = document.forms.registration.email.value;
	var filter = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;
	if (!filter.test(x)){ 
		msg += "- Please enter a valid email address.\n";
	}

	if (!document.forms.registration.email.value == ""){
		//email_check(document.forms.registration.email.value);
	}

//----------------------------end email-----------------------------

if ((document.forms.registration.phone.value == "") || (document.forms.registration.phone.value.length < 10) || (document.forms.registration.phone.value.length > 10)){
	msg += "- Please enter a valid 10-digit phone number.\n";
}

if (document.forms.registration.organization.value.length > 70) {
	msg += "- Please enter an organization name shorter than 70 characters.\n";
}


//----------------------------- duplicate dropdown check--------------------------
//var ssvf1 = document.getElementById("program_id1").value;
//var ssvf2 = document.getElementById("program_id2").value;
//var ssvf3 = document.getElementById("program_id3").value;
//var ssvf4 = document.getElementById("program_id4").value;
//var ssvf5 = document.getElementById("program_id5").value;

var ssvf_array = [];

for (var i=1; i < 21; i++){
	if (document.getElementById('program_id' + [i]).value != 0){
		ssvf_array.push(document.getElementById('program_id' + [i]).value);
		//alert (document.getElementById('program_id' + [i]).value);
	}
}

var len=ssvf_array.length;

if (len > 1){
	ssvf_array.sort();
	var last=ssvf_array[0];
	var dupefound=0;
		for (var i=1; i<len; i++) {
   			if (ssvf_array[i] == last){
				dupefound=1;
			}
  			last = ssvf_array[i];
		}
	
	if (dupefound > 0){
		msg += "- Please ensure you do not select duplicate SSVF programs for enrollment.";
	}
}

//----------------------------- end duplicate dropdown check-----------------------


//--------------------------------password validation---------------------------

if (((document.forms.registration.password.value == '') && (document.forms.registration.password2.value != '')) || ((document.forms.registration.password.value != '') && (document.forms.registration.password2.value == ''))){
	msg+= "- Please enter a desired password in both fields.\n";
}

if (document.forms.registration.password.value != document.forms.registration.password2.value) {
	msg += "- Passwords do not match.\n";
}

var pwd1 = document.forms.registration.password.value;
var pwd2 = document.forms.registration.password2.value;



if ((document.forms.registration.password.value != '') && (document.forms.registration.password2.value != '')){
	if ((document.forms.registration.password.value.length < 8) || (document.forms.registration.password2.value.length < 8)) {
		msg += "- Passwords must contain at least eight (8) characters, a number and upper and lower case letters.\n";
	}


	if ((document.forms.registration.password.value.length > 20) || (document.forms.registration.password2.value.length > 20)) 
     	{
		msg += "- Passwords must not contain more than twenty (20) characters.\n";
     	}
	
	re = /[0-9]/;
	if ((!re.test(pwd1)) || (!re.test(pwd2))) 
	{
		msg += "- Password must contain at least one number (0-9).\n";
	}
	
	re = /[a-z]/;
	if ((!re.test(pwd1)) || (!re.test(pwd2))) 
	{
		msg+= "- Password must contain at least one lowercase letter (a-z).\n";
	}

	re = /[A-Z]/;
	if ((!re.test(pwd1)) || (!re.test(pwd2)))
	{
		msg += "- Password must contain at least one uppercase letter (A-Z).\n";
	}

	// Create regular expression for password and login id
	var re = new RegExp("[^A-Za-z0-9 ]","i");

}
//-----------------------------end password validation----------------------------

	if (msg != ""){
		alert(msg);
		return false;
	}

	return (valid);
}
</script>


   

<script type="text/javascript" src="password.js"></script>
<style>
#passwordStrength { height:10px; display:block; float:left; } .strength0 { width:250px; background:#cccccc; } .strength1 { width:50px; background:#ff0000; } .strength2 { width:100px; background:#ff5f5f; } .strength3 { width:150px; background:#56e500; } .strength4 { background:#4dcd00; width:200px; } .strength5 { background:#399800; width:250px; }
</style>


<form name="registration" action="adminupdateuser.php" method="post" onSubmit="return check_form();">
<input type="hidden" name="uid" value="<?echo $uid;?>">
<INPUT TYPE=hidden id="e_token" name="e_token" VALUE="<?php echo $_SESSION['e_token']; ?>">

<h1 align="center">Edit Account<!-- END: PAGE TITLE --></h1>
    

<CENTER><A HREF="manage_users.php">Return to Manage Users</A></CENTER>

<HR>


<br><br>

<table width=755 align="center">
<tr class="va-section-header" width="550">
<td colspan=2>Account Information</td>
</tr>
<tr>
<td width="500" colspan="2">
    Edit the fields below to update the user's account information.
<br>
Note: All fields are required.
    <br><br>
 <tr>
<td width="200">Username</td>
<td width="400"><?echo $username;?></td>
</tr>
<tr>
<td width="200"><label for='fname'>First Name</label></td>
<td width="400"><input type="text" name="fname" id="fname" size="20" maxlength="20" VALUE="<?echo $fname;?>" ></td>
</tr>
<tr>
<td width="200"><label for='lname'>Last Name</label></td>
<td width="400"><input type="text" name="lname" id='lname' size="30" maxlength="20" VALUE="<?echo $lname;?>" ></td>
</tr>

<tr>
<td width="200"><label for='email'>Email</label></td>
<td width="400"><input type="text" name="email" id='email' size="40" maxlength="120" VALUE="<?echo $email;?>" >
<?
if ($level==0){
	print("&nbsp; &nbsp; <B><font color='red' size=1> Unconfirmed </font></b> ");
}
?>
</td>
</tr>

<tr>
<td width="200"><label for='phone'>Phone</label></td>
<td width="400"><input type="text" name="phone" id='phone' size="20" maxlength="20" VALUE="<?echo $phone;?>" ></td>
</tr>

<? if ("0"==$squares_user){  ?>
	<tr>
	<td width="200"><label for='organization'>Organization</label></td>
	<td width="400"><input type="text" name="organization" id='organization' size="20" maxlength="60" VALUE="<?echo $organization;?>" ></td>
	</tr>
	<tr>
<? } ?>

	<tr>
	<td width="200"><label for='dd_coc'>CoC</label></td>
	<td width="400">


	<?
		$sqlUC= "select coc_id FROM tb_user_coc where user_id=$uid";
		$rsUC = $db->Execute($sqlUC);
		while (!$rsUC->EOF){
			$user_coc = $rsUC->fields('coc_id');
		$rsUC->MoveNext();
		}
		 
	?>
	<select id="dd_coc" name="dd_coc" style="width: 300px" >
	<option id="0">--- Please select CoC --- </option> 
		<?
			$sql = "select coc_id, hudNum, name FROM tb_coc Order By name";
			$rs = $db->Execute($sql);
			$cocs = "";
			$javascript = "";
			while (!$rs->EOF)
			  { 
				$coc_id = $rs->fields('coc_id');
				$coc_name = $rs->fields('name');
				$coc_HudNum = $rs->fields('hudNum');

			if ($user_coc == $coc_id){
				$cocs = $cocs . "<option value=\"$coc_id\" selected=selected>$coc_name ($coc_HudNum)</option>\n";
			}
			else{
				$cocs = $cocs . "<option value=\"$coc_id\">$coc_name ($coc_HudNum)</option>\n";
			}
			$rs->MoveNext();
			  }

			  echo $cocs
		  ?>

	</select>
	</td>
	</tr>


<td width="200"><label for='level'>User Level</label></td>
<td width="400">
<? if (($level == 0) || ($level==9) || ($level==10)){ ?>
	<?if ($level == 0) {?>
		<select name="level" id="level" >
			<option value="0" <?if ($level == 0) {?>selected<?}?>>Pending (Unconfirmed Email)</option>	
			<option value="1" <?if ($level == 1) {?>selected<?}?>>User</option>
			<option value="2" <?if ($level == 2) {?>selected<?}?>>Administrator</option>
		</select>
	<? } 
	else if (($level == 9) || ($level==10)) {
	?>
		
		<select name="level" id="level" >
			<?if ("1" == $squares_user) {?>
				<option value="10" <?if ($level == 0) {?>selected<?}?>>Pending (SQUARES)</option>		
			<? } else {?>
				<option value="9" <?if ($level == 9) {?>selected<?}?>>Pending</option>	
			<? } ?>
			<option value="1" <?if ($level == 1) {?>selected<?}?>>User</option>
			<option value="2" <?if ($level == 2) {?>selected<?}?>>Administrator</option>
		</select>
	<? }

}
else { ?>
<select name="level" id='level' >
<option value="1" <?if ($level == 1) {?>selected<?}?>>User</option>
<option value="2" <?if ($level == 2) {?>selected<?}?>>Administrator</option>
</select>
<? } ?>
</td>
</tr>

<tr>
<td width="200"><label for='sq_only'>SQUARES Only User?</label></td>
<td width="400"><input type="checkbox" id="sq_only" name="sq_only" value="1" <?if ("1"==$squares_user){?>checked<?}?> >
</td>
</tr>
</table>

<br /><br />

<? if ("0"==$squares_user){ ?>
	<table width="755" align="center" cellspacing='0' class='auto-style1'>
	<tr class="va-section-header" width="550">
	<td colspan="2">SSVF Grant/Programs
	<input type="button" value="Show / Hide" style="float:right;" onclick="showhide_progs();" />
	</tr>

	<tr>
	<td width="755" colspan="3">
	    Select one or more SSVF Grant/Programs
	    <br><br>
	</td>
	</tr>

	<tr>
	<td width="200"><label for='program_id1'>1st SSVF Grant/Program</label></td>
	<td>
	<SELECT name="program_id1" id="program_id1" >
	<OPTION VALUE="0">Select SSVF Program</OPTION>
	<?echo $option1;?>
	<?echo $programs;?>
	</SELECT>
	</td>
	</tr>

	<tr>
	<td width="200"><label for='program_id2'>2nd SSVF Grant/Program</label></td>
	<td>
	<SELECT name="program_id2" id="program_id2" >
	<OPTION VALUE="0">Select SSVF Program</OPTION>
	<?echo $option2;?>
	<?echo $programs;?>
	</SELECT>
	</td>
	</tr>

	<tr>
	<td width="200"><label for='program_id3'>3rd SSVF Grant/Program</label></td>
	<td>
	<SELECT name="program_id3" id="program_id3" >
	<OPTION VALUE="0">Select SSVF Program</OPTION>
	<?echo $option3;?>
	<?echo $programs;?>
	</SELECT>
	</td>
	</tr>

	<tr>
	<td width="200"><label for='program_id4'>4th SSVF Grant/Program</label></td>
	<td>
	<SELECT name="program_id4" id="program_id4" >
	<OPTION VALUE="0">Select SSVF Program</OPTION>
	<?echo $option4;?>
	<?echo $programs;?>
	</SELECT>
	</td>
	</tr>

	<tr>
	<td width="200"><label for='program_id5'>5th SSVF Grant/Program</label></td>
	<td>
	<SELECT name="program_id5" id="program_id5" >
	<OPTION VALUE="0">Select SSVF Program</OPTION>
	<?echo $option5;?>
	<?echo $programs;?>
	</SELECT>
	</td>
	</tr>

	<tr>
	<td width="200"><label for='program_id6'>6th SSVF Grant/Program</label></td>
	<td>
	<SELECT name="program_id6" id="program_id6" >
	<OPTION VALUE="0">Select SSVF Program</OPTION>
	<?echo $option6;?>
	<?echo $programs;?>
	</SELECT>
	</td>
	</tr>

	<tr>
	<td width="200"><label for='program_id7'>7th SSVF Grant/Program</label></td>
	<td>
	<SELECT name="program_id7" id="program_id7" >
	<OPTION VALUE="0">Select SSVF Program</OPTION>
	<?echo $option7;?>
	<?echo $programs;?>
	</SELECT>
	</td>
	</tr>
	</table>

	<div id="morePrograms" name="morePrograms" style="display:none;">
	<table width="755" align="center" cellspacing='0' class='auto-style1'>
	<tr>
	<td width="200"><label for='program_id8'>8th SSVF Grant/Program</label>/td>
	<td>
	<SELECT name="program_id8" id="program_id8" >
	<OPTION VALUE="0">Select SSVF Program</OPTION>
	<?echo $option8;?>
	<?echo $programs;?>
	</SELECT>
	</td>
	</tr>

	<tr>
	<td width="200"><label for='program_id9'>9th SSVF Grant/Program</label></td>
	<td>
	<SELECT name="program_id9" id="program_id9" >
	<OPTION VALUE="0">Select SSVF Program</OPTION>
	<?echo $option9;?>
	<?echo $programs;?>
	</SELECT>
	</td>
	</tr>

	<tr>
	<td width="200"><label for='program_id10'>10th SSVF Grant/Program</label></td>
	<td>
	<SELECT name="program_id10" id="program_id10" >
	<OPTION VALUE="0">Select SSVF Program</OPTION>
	<?echo $option10;?>
	<?echo $programs;?>
	</SELECT>
	</td>
	</tr>

	<tr>
	<td width="200"><label for='program_id11'>11th SSVF Grant/Program</label></td>
	<td>
	<SELECT name="program_id11" id="program_id11" >
	<OPTION VALUE="0">Select SSVF Program</OPTION>
	<?echo $option11;?>
	<?echo $programs;?>
	</SELECT>
	</td>
	</tr>

	<tr>
	<td width="200"><label for='program_id12'>12th SSVF Grant/Program</label></td>
	<td>
	<SELECT name="program_id12" id="program_id12" >
	<OPTION VALUE="0">Select SSVF Program</OPTION>
	<?echo $option12;?>
	<?echo $programs;?>
	</SELECT>
	</td>
	</tr>

	<tr>
	<td width="200"><label for='program_id13'>13th SSVF Grant/Program</label></td>
	<td>
	<SELECT name="program_id13" id="program_id13" >
	<OPTION VALUE="0">Select SSVF Program</OPTION>
	<?echo $option13;?>
	<?echo $programs;?>
	</SELECT>
	</td>
	</tr>

	<tr>
	<td width="200"><label for='program_id14'>14th SSVF Grant/Program</label></td>
	<td>
	<SELECT name="program_id14" id="program_id14" >
	<OPTION VALUE="0">Select SSVF Program</OPTION>
	<?echo $option14;?>
	<?echo $programs;?>
	</SELECT>
	</td>
	</tr>

	<tr>
	<td width="200"><label for='program_id15'>15th SSVF Grant/Program</label></td>
	<td>
	<SELECT name="program_id15" id="program_id15" >
	<OPTION VALUE="0">Select SSVF Program</OPTION>
	<?echo $option15;?>
	<?echo $programs;?>
	</SELECT>
	</td>
	</tr>

	<tr>
	<td width="200"><label for='program_id16'>16th SSVF Grant/Program</label></td>
	<td>
	<SELECT name="program_id16" id="program_id16" >
	<OPTION VALUE="0">Select SSVF Program</OPTION>
	<?echo $option16;?>
	<?echo $programs;?>
	</SELECT>
	</td>
	</tr>

	<tr>
	<td width="200"><label for='program_id17'>17th SSVF Grant/Program</label></td>
	<td>
	<SELECT name="program_id17" id="program_id17" >
	<OPTION VALUE="0">Select SSVF Program</OPTION>
	<?echo $option17;?>
	<?echo $programs;?>
	</SELECT>
	</td>
	</tr>

	<tr>
	<td width="200"><label for='program_id18'>18th SSVF Grant/Program</label></td>
	<td>
	<SELECT name="program_id18" id="program_id18" >
	<OPTION VALUE="0">Select SSVF Program</OPTION>
	<?echo $option18;?>
	<?echo $programs;?>
	</SELECT>
	</td>
	</tr>

	<tr>
	<td width="200"><label for='program_id19'>19th SSVF Grant/Program</label></td>
	<td>
	<SELECT name="program_id19" id="program_id19" >
	<OPTION VALUE="0">Select SSVF Program</OPTION>
	<?echo $option19;?>
	<?echo $programs;?>
	</SELECT>
	</td>
	</tr>

	<tr>
	<td width="200"><label for='program_id20'>20th SSVF Grant/Program</label></td>
	<td>
	<SELECT name="program_id20" id="program_id20" >
	<OPTION VALUE="0">Select SSVF Program</OPTION>
	<?echo $option20;?>
	<?echo $programs;?>
	</SELECT>
	</td>
	</tr>

	</table>
	</div>
	<br><br>
<? } ?>


<table width="755" align="center">
</td></tr>
<tr class="va-section-header" >
<td colspan=2 width="755">Change Password</td>
</tr>

<tr>
<td width="500">
    
    Use the fields below to update this user's account password. Please enter the new password two times to make sure it is correct.
    <br />    <br />
    <TABLE>
        

        <TR><TD><label for='password'>New Password</label></TD>
<TD><input type="password" name="password" id="password" size="20" value="" onkeyup="passwordStrength(this.value)" >

</TD><TD>

                           </TD>
</TR>

<TR><TD></TD>
<TD><div id="passwordDescription">Password not entered</div> <div id="passwordStrength" class="strength0"></div><br /></TD></TR>

<TR><TD><label for='password2'>Confirm Password</label></TD>
<TD><input type="password" name="password2" id="password2" size="20" value="" >
</TD><TD>
                           </TD>
</TR>

<TR>
<TD></td>
</TR>


</TABLE>
<br>
Note: Passwords must be between 8 and 20 characters in length and contain both uppercase and lowercase letters, and at least one number.
    <br />

<br />
</td></tr>

<TR><TD colspan=3 align=center>
<HR>
<INPUT TYPE=SUBMIT VALUE="Update Account" > <INPUT TYPE=RESET VALUE=Cancel onClick="document.location='manage_users.php';" >
<HR>
</TD></TR>



</TABLE>

</form>

</td>





</td>
</tr>
</tbody>
</table>
<br>

<h1 align=center>Login History</h1>
<BR>
<table width="500" align="center" border=1>
<th align=center class="va-section-header" >Login Date (EST)</th>
<?
$sysdate = date("Y-m-d");
$sqlLG = "select top 25 user_id, event_type, event_date from tb_audit where (user_id=$uid) AND (event_type in (54, 7)) AND (event_date > ($sysdate - 30)) order by event_date desc";
$rsLG = $db->Execute($sqlLG);

//echo "<br>" . $sqlLG;
if ($rsLG->EOF){
	print("
		<tr>
		<td align=center><b>NO RECORD FOUND</td>
		</tr>
	");
}

else{
while (!$rsLG->EOF)
  { 
	$login = $rsLG->fields('event_date');
	$login = date("n/j/y g:i:s A", strtotime($login) );

	print ("
		<tr>
		<td align=center>$login</td>
		</tr>
	");

$rsLG->MoveNext();
  }
}
?>


</table>

			
<?php

print_footer();

} // end check uid

else {print "Invalid user";}

} // end check login
?>