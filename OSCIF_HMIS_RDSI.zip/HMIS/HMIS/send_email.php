<?php

//FOR TESTING
//include('../init.php');
//include('../hmis/libs/functions.php');

include('init.php');
include('hmis/libs/functions.php');
$to = "";
$keepSubj="";
$keepBody="";

//if in list generated mode, run the e_token stuff
if (isset($_POST['pToEmail']) || isset($_POST['uToEmail'])){
	//echo "here1<BR>";
	
	if (isset($_POST['pToEmail'])){
				//echo "here2<BR>";
			
			$e_token = trim(scrub_white_list($_POST['e_token_p'], 'ALPHANUMERICONLY'));
			$s_e_token = $_SESSION['e_token'];

		//echo "e_token -> " . $e_token;
		//echo "<BR>s_e_token -> " . $s_e_token;

		if ((!ISSET($e_token)) || ($e_token != $s_e_token)){
			//echo "here2";
			header( 'Location: /index.php');
		}
	
	}
	
	if (isset($_POST['uToEmail'])){
			//echo "here3<BR>";
			
			$e_token = trim(scrub_white_list($_POST['e_token_u'], 'ALPHANUMERICONLY'));
			$s_e_token = $_SESSION['e_token'];

		//echo "e_token -> " . $e_token;
		//echo "<BR>s_e_token -> " . $s_e_token;

		if ((!ISSET($e_token)) || ($e_token != $s_e_token)){
			//echo "here2";
			header( 'Location: /index.php');
		}
	
	}

}

//---------------------------------------------------USER------------------------------------------------------
if (isset($_POST['generate_user']) && $_POST['generate_user'] !=""){
  //echo "<script>document.getElementById('toList').value=6;</script>";

  $userSQL = "";
  $usersSel = array();
  $usersSel = $_POST['uToEmail'];
  if(isset($_POST['uToEmail'])){
    $userSQL = "";
      foreach($usersSel as $value){
				//echo $value . "<br>";
      	      $usersSel = scrub_white_list($usersSel, 'USER');
      	      $userSQL = implode(', ' , $usersSel);
	}
	
 // echo "<br><br>userSQL -> ". $userSQL;
  $sql = "select distinct email from tb_user WHERE user_id IN ($userSQL)";
  //echo "<br> SQL select -> ".$sql;

  $rs = $db->Execute($sql);
  $results = 0;
  while (!$rs->EOF)
  { 
		$email = "<" . $rs->fields('email') . ">";
		if ($results > 0) {
			$to =  $to . ";";
		}
		$to = $to . $email ;
		$results = $results + 1;
		$rs->MoveNext();
  }
}
}


//---------------------------------------------------PROGRAM------------------------------------------------------
if (isset($_POST['generate_prog']) && $_POST['generate_prog'] !=""){
  //echo "<script>document.getElementById('toList').value=5;</script>";

  $progSQL = "";
  $programs = array();
  $programs = $_POST['pToEmail'];
  

  if(isset($_POST['pToEmail'])){
    $progSQL = "";
      foreach($programs as $value){
      	      $programs = scrub_white_list($programs, 'USER');
      	      $progSQL = implode(', ' , $programs);
      }

    $sql = "select distinct email from tb_user u, tb_SSVF_Program p, tb_user_programs j  WHERE j.user_id=u.user_id AND j.program_id IN ($progSQL)";
   // echo "<br><br>progSQL -> ". $progSQL;
    //echo "<br> SQL select -> " . $sql;

$rs = $db->Execute($sql);
$results = 0;
while (!$rs->EOF)
  { 
$email = "<" . $rs->fields('email') . ">";
	if ($results > 0) {
		$to =  $to . ";";
	}
		$to = $to . $email ;
		$results = $results + 1;
		$rs->MoveNext();
  }
}
}

if (checklogin($userID, "menu.php") && $status == 2) {

	print_header();
	?>

	<style type="text/css">
	.auto-style1 {
	
		border: 1px solid #999999;
		border-style: inset;
		border-color: gray;
		background-color: white;
		-moz-border-radius: ;
}

<style type="text/css">
#manage {
	width:755px;
	border-width: 1px;
	border-spacing: ;
	border-style: outset;
	border-color: gray;
	border-collapse: separate;
	background-color: white;
}
#manage th {
	border-width: 1px;
	padding: 1px;
	border-style: inset;
	border-color: gray;
	background-color: white;
	-moz-border-radius: ;
}
#manage td {
	border-width: 1px;
	padding: 1px;
	border-style: inset;
	border-color: gray;
	background-color: white;
	-moz-border-radius: ;
}
</style>

<script>
function check_form() {
var errs=0;
var msg = "";
var valid = true;

if (document.forms.email.subject.value == '') {
	msg = msg + "Please enter a subject.\n";
	//alert('Please enter a subject.'); 
	errs=1;
}

if (document.forms.email.body.value == '') {
	msg = msg + "Please enter text into the email body.\n";
	//alert('Please enter text into the email body.'); 
	errs=1;
}


//if (("5" == document.forms.email.recipient.value) || ("6" == document.forms.email.recipient.value)){
	//if ("" == document.forms.email.toList.value){
		//msg = msg + "Please enter a list of recipients for this message.\n";
		//alert('Please enter a list of recipients for this message.');
		//errs=1;
	//}
//}

if (msg != ""){
	alert (msg);
	valid=false;
}
	
//return (errs==0);
return (valid);
}

function expandSelections() {
  var toSelect = document.getElementById("recipient").value;
 // var userForm = document.getElementById("formUsers");
 // var programForm = document.getElementById("formPrograms");

var userForm = document.forms["formUsers"];
var programForm = document.forms["formPrograms"];
var mailForm = document.forms["email"];

   //document.getElementById("pasteEmails").style.display="none";
  //var usersCount = document.getElementsByName("uToEmail").length;
  //var progCount = document.getElementsByName("pToEmail").length;

  if ("6" == toSelect){
    document.getElementById('selectUsers').style.display="inline";
    document.getElementById("selectPrograms").style.display="none";

    document.getElementById("toList").value="";
    //document.getElementById("toList").disabled=true;
    document.getElementById("toList").setAttribute("rows","1");

  }
  else if ("5" == toSelect){
    document.getElementById('selectPrograms').style.display="inline";
    document.getElementById("selectUsers").style.display="none";

    document.getElementById("toList").value="";
    //document.getElementById("toList").disabled=true;
    document.getElementById("toList").setAttribute("rows","1");

  }
  else{
    document.getElementById("selectPrograms").style.display="none";
    document.getElementById("selectUsers").style.display="none";
    //document.getElementById("recipients").style.display="none";
    document.getElementById("toList").value="";
    document.getElementById("toList").disabled=true;
    document.getElementById("toList").setAttribute("rows","1");

	}
}

function checkSels() {
	var toSelect = document.getElementById("recipient").value;
	if ("5" == toSelect){
		var numSel = 0;
		var chks = document.getElementsByName('pToEmail[]');
			for (var i = 0; i < chks.length; i++){
				if (chks[i].checked){
					numSel = numSel + 1;
				}
			}
		if ("0" == numSel){
			alert ("Please select at least one (1) program to recieve this email.");
			return false;
		}	

	}

	if ("6" == toSelect){
		var numSel = 0;
		var chks = document.getElementsByName('uToEmail[]');
			for (var i = 0; i < chks.length; i++){
				if (chks[i].checked){
					numSel = numSel + 1;
				}
			}
		if ("0" == numSel){
			alert ("Please select at least one (1) user to recieve this email.");
			return false;
		}	

	}
}

function clearSels() {
	var toSelect = document.getElementById("recipient").value;
	var conf = confirm("Are you sure you want clear all selections?");

	if (conf == true){	
		if ("5" == toSelect){
			var numSel = 0;
			var chks = document.getElementsByName('pToEmail[]');
				for (var i = 0; i < chks.length; i++){
					if (chks[i].checked){
						chks[i].checked = false;
					}
				}
		}


		if ("6" == toSelect){
			var numSel = 0;
			var chks = document.getElementsByName('uToEmail[]');
				for (var i = 0; i < chks.length; i++){
					if (chks[i].checked){
						chks[i].checked = false;
					}
				}
		}
	}	
}
</script>

<body>
<H1 align=center>Send Email to Users</H1>
<CENTER><A HREF="menu.php">Repository Home</A></CENTER>
<HR>
<FORM ACTION="sendmail.php" NAME="email" id="email" METHOD="POST" onSubmit="return check_form();">
<TABLE ALIGN="CENTER" NAME="manage" id="manage" cellspacing="0" class="auto-style1" style="width: 80%; float: middle">
<TR>
<Th><label for='recipient'>To:</label></Th>
<TD>
<SELECT NAME="recipient" id="recipient" style="width:100%" onchange="return expandSelections();" >
<OPTION VALUE="1">All HMIS Repository Users</OPTION>
<OPTION VALUE="2">All non-administrative users</OPTION>
<OPTION VALUE="3">All users for programs with a status of "Not Started"</OPTION>
<OPTION VALUE="4">All users for programs with a status of "Complete"</OPTION>


<? 
if(isset($_POST['pToEmail']) || isset($_POST['uToEmail'])){
	$to_id = $_POST['to_id'];
	
	if ($to_id == "5"){ 
		echo "<OPTION VALUE='5' SELECTED>All users at selected programs</OPTION>";
		
	}
	else {
		echo "<OPTION VALUE='5'>All users at selected programs</OPTION>";
	}

	if ($to_id == "6"){
		echo "<OPTION VALUE='6' SELECTED>Selected users</OPTION>";
		echo "</SELECT>";
	}
	else { 
		echo "<OPTION VALUE='6'>Selected users</OPTION>";
		echo "</SELECT>";
	} 
		
}
else{
	echo "<OPTION VALUE='5'>All users at selected programs</OPTION>";
	echo "<OPTION VALUE='6'>Selected users</OPTION>";
	echo "</SELECT>";
}
?>

<?php

$sql = "select fname, lname, email FROM tb_user order by lname";
$rs = $db->Execute($sql);

$usersToEmail = "";

while (!$rs->EOF) { 
	$uFname = $rs->fields('fname');
	$uLname = $rs->fields('lname');
	$uEmail = $rs->fields('email');

	$usersToEmail = $usersToEmail . "<br> <input type='checkbox' name='uEmailArray[]' id='uEmailArray[]' value=\"$uEmail\"> $uLname, $uFname \n";
	$rs->MoveNext();
  }
?>



<?php
$sql = "select program_name, program_id FROM tb_SSVF_program order by program_name";
$rs = $db->Execute($sql);

$progsToEmail = "";

while (!$rs->EOF)
  { 
$progName = $rs->fields('program_name');

$progsToEmail = $progsToEmail . "<br> <input type='checkbox' name='pToEmail' id='pToEmail' value=\"$progName\"> $progName \n";

$rs->MoveNext();
  }

?>

</TD>
</TR>
<?
		echo "<div id='recipients' name='recipients' style='display:inline'>";
		echo "<TR><Th><label for='toList'>Recipients:</label></Th>";

	if(isset($_POST['pToEmail']) || isset($_POST['uToEmail'])){
		echo "<TD><TEXTAREA NAME='toList' ID='toList' COLS='81' ROWS='5' >" . $to . "</TEXTAREA></center>";
	}
	else {
		echo "<TD><TEXTAREA NAME='toList' ID='toList' COLS='81' ROWS='1' DISABLED>" . $to . "</TEXTAREA></center>";
	}
		echo "</TD></TR>";
		echo "</div>";


?>


<TR><Th><label for='subject'>Subject:</label></Th>

<?
if(isset($_POST['pToEmail']) || isset($_POST['uToEmail'])){
	$keepSubj = trim(scrub_white_list($_POST['subject'], 'DATA'));
	//echo "keepSubj -> " . $keepSubj;
	echo "<TD><INPUT TYPE='TEXT' NAME='subject' id='subject' SIZE='108' value='" . $keepSubj . " '></TD>";
}
else {
	echo "<TD><INPUT TYPE='TEXT' NAME='subject' id='subject' SIZE='108' ></TD>";
}
?>
	
</TR>
<TR><Th><label for='body'>Body:</label></Th>
<?
if(isset($_POST['pToEmail']) || isset($_POST['uToEmail'])){
	$keepBody = trim(scrub_white_list($_POST['body'], 'HTMLNOSCRIPT'));
	//echo "keepBody -> " . $keepBody;
	
	echo "<TD><TEXTAREA NAME='body' id='body' COLS='81' ROWS='12' >" . $keepBody ."</TEXTAREA></TD>";
}
else {
	echo "<TD><TEXTAREA NAME='body' id='body' COLS='81' ROWS='12' ></TEXTAREA></TD>";
}
?>
</TR>
</TABLE>
<BR>
<CENTER>
<INPUT TYPE="SUBMIT" VALUE="Send Email" >
</CENTER>
<INPUT TYPE=hidden id="e_token" name="e_token" VALUE="<?php echo $_SESSION['e_token']; ?>">
</form>


<div id="selectionArea" name="selectionArea">

<? 
//---------------------------------- SELECT PROGRAMS--------------------------------------------------
?>

<form id="formPrograms" name="formPrograms" method="POST" action="send_email.php">
<INPUT TYPE=hidden id="e_token_p" name="e_token_p" VALUE="<?php echo $_SESSION['e_token']; ?>">
<div id="selectPrograms" name="selectPrograms" style="display:none">
<?php
$keepSubj = trim(scrub_white_list($_POST['subject'], 'DATA'));
$keepBody = trim(scrub_white_list($_POST['body'], 'HTMLNOSCRIPT'));
echo "<input type='hidden' name='to_id' id='to_id' value='5'>";
echo "<input type='hidden' name='subj_hid' id='subj_hid' value='" . $keepSubj . "'>";
echo "<input type='hidden' name='body_hid' id='body_hid' value='" . $keepBody . "'>";

$sql = "select program_name, program_id FROM tb_SSVF_program order by program_name";
$rs = $db->Execute($sql);
$i=1;
$progsToEmail = "";
while (!$rs->EOF)
  { 
$progName = $rs->fields('program_name');
$program_id = $rs->fields('program_id');

$progsToEmail[] = "<br> <input type='checkbox' name='pToEmail[]' id='pToEmail".$program_id."' value=\"$program_id\"> $progName \n";
//$progsToEmail[] = "<br> <input type='checkbox' name='pToEmail[]' id='pToEmail_id' value=\"$program_id\"> $progName";


$progsToEmail = array_combine(range(1, count($progsToEmail)), array_values($progsToEmail));
$i++;

$rs->MoveNext();
  }

$cols = 3;

echo "<hr width='760'>";
echo "<h2 align='center'>Program List</h2>";
echo "<table align='center'><tr>";
echo "<td align='center'><INPUT type='SUBMIT' id='generate_prog' name='generate_prog' VALUE='Generate Mailing List' onclick='return checkSels();'></td>";
echo "<td align='center'><INPUT type='button' id='clear_sel' name='clear_sel' VALUE='Clear All' onclick='return clearSels();'></td>";
echo "</tr></table>";


echo "<table align='center' border='5' cellspacing='0' class='auto-style1' style='width: 100%; float: left'><br><tr>";

for ($j=1; $j<=count($progsToEmail); $j++){
     echo "<td align='left'  height='5'>" . $progsToEmail[$j] . "</td>";
	if (($j % $cols) == 0){
		echo "</tr>";
    	}
   }
//echo "Progs To email: " . count($progsToEmail);
?>



<input type="hidden" id="progSel" name="progSel" value="1">

<table align="center"><tr>
<td align="center"><INPUT type="SUBMIT" id="generate_prog" name="generate_prog" VALUE="Generate Mailing List" onclick="return checkSels();"></td>
<td align="center"><INPUT type="button" id="clear_sel" name="clear_sel" VALUE="Clear All" onclick="return clearSels();"></td>
</tr></table>
</div></form>

<?php
//--------------------------------------------------------------SELECT USERS---------------------------------------------
?>
<form id="formUsers" name="formUsers" method="POST" action="send_email.php">
<INPUT TYPE=hidden id="e_token_u" name="e_token_u" VALUE="<?php echo $_SESSION['e_token']; ?>">
<div id="selectUsers" name="selectUsers" style="display:none">
<?php

$keepSubj = trim(scrub_white_list($_POST['subject'], 'DATA'));
$keepBody = trim(scrub_white_list($_POST['body'], 'HTMLNOSCRIPT'));
echo "<input type='hidden' name='to_id' id='to_id' value='6'>";
echo "<input type='hidden' name='subj_hid' id='subj_hid' value='" . $keepSubj . "'>";
echo "<input type='hidden' name='body_hid' id='body_hid' value='" . $keepBody . "'>";

$sql = "select user_id, fname, lname, email FROM tb_user order by lname";
$rs = $db->Execute($sql);

$usersToEmail = "";
$i=0;
while (!$rs->EOF)
  { 
$uUID = $rs->fields('user_id');
$uFname = $rs->fields('fname');
$uLname = $rs->fields('lname');
$uEmail = $rs->fields('email');

$usersToEmail[] = "<br> <input type='checkbox' name='uToEmail[]' id='uToEmail".$uUID."' value=\"$uUID\"> <font size='2'>$uLname, $uFname</font> <br><i><font size='1'>($uEmail)</font></i>\n";
//$usersToEmail[] = "<br> <input type='checkbox' name='uToEmail[]' id='uToEmail_id' value=\"$uUID\"> <font size='2'>$uLname, $uFname</font> <br><i><font size='1'>($uEmail)</font></i>\n";

$usersToEmail = array_combine(range(1, count($usersToEmail)), array_values($usersToEmail));
$i++;

$rs->MoveNext();
  }

$cols = 3;

echo "<hr width='760'>";
echo "<h2 align='center'>User List</h2>";

echo "<table align='center'><tr>";
echo "<td align='center'><INPUT type='SUBMIT' id='generate_user' name='generate_user' VALUE='Generate Mailing List' onclick='return checkSels();'></td>";
echo "<td align='center'><INPUT type='button' id='clear_sel' name='clear_sel' VALUE='Clear All' onclick='return clearSels();'></td>";
echo "</tr></table>";
echo "<table align='center' border='5' cellspacing='0' class='auto-style1' style='width: 100%; float: left'><br><tr>";
?>


<?php
for ($j=1; $j<=count($usersToEmail); $j++){
     echo "<td align='left' height='25'>" . $usersToEmail[$j] . "</td>";

    if (($j % $cols) == 0){
	echo "</tr>";
    }
   }
?>
</table>


<input type="hidden" id="userSel" name="userSel" value="1">
<INPUT TYPE=hidden id="e_token" name="e_token" VALUE="<?php echo $_SESSION['e_token']; ?>">
<table align="center"><tr>
<td align="center"><INPUT type="SUBMIT" id="generate_user" name="generate_user" VALUE="Generate Mailing List" onclick="return checkSels();"></td>
<td align="center"><INPUT type="button" id="clear_sel" name="clear_sel" VALUE="Clear All" onclick="return clearSels();"></td>
</tr></table>
</div></form>


</FORM>

</div>
</body>

<?
print_footer();
} //end check login
?>