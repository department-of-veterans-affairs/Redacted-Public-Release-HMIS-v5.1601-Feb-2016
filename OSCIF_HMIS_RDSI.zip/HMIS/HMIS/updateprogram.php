<?php

include('init.php');
include('hmis/libs/functions.php');

$e_token = trim(scrub_white_list($_POST['e_token'], 'ALPHANUMERICONLY'));
$s_e_token = $_SESSION['e_token'];
if ((ISSET($e_token)) && ($e_token===$s_e_token)){

	if (checklogin($userID, "menu.php")) {
		$pid = scrub_sql(scrub_white_list(trim($_POST['pid']),'NUMBERONLY'), 5);
		$prog_name = scrub_sql(scrub_white_list(trim($_POST['pname']),'USER'), 100);
		$coc = scrub_sql(scrub_white_list(trim($_POST['coc']),'USER'), 150);
		$grant_id = scrub_sql(scrub_white_list(trim($_POST['grantee']),'NUMBERONLY'), 5);

		$p_start_date = trim($_POST['p_start_date']);
		$p_start_date = date("Y-m-d", strtotime($p_start_date));

		$p_end_date = trim($_POST['p_end_date']);

		//echo "<br>" . $p_end_date . "<br>";

		if ($p_end_date <> ''){
			$p_end_date = date("Y-m-d", strtotime($p_end_date));
		}

		$new_val_type = scrub_sql(scrub_white_list(trim($_POST['val_type']),'NUMBERONLY'), 1);
		$old_val_type = scrub_sql(scrub_white_list(trim($_POST['og_valtype']),'NUMBERONLY'), 1);

		$errors=0;
	}

	if ($errors == 0) {

		if ($p_end_date <> ''){
			$sqlP = "UPDATE tb_SSVF_program SET program_name='$prog_name', coc='$coc', grant_id='$grant_id', val_type='$new_val_type', p_start_date='$p_start_date', p_end_date='$p_end_date' where program_id=$pid";
		}
		else{
			$sqlP = "UPDATE tb_SSVF_program SET program_name='$prog_name', coc='$coc', grant_id='$grant_id', val_type='$new_val_type', p_start_date='$p_start_date', p_end_date=NULL where program_id=$pid";
		}
			
		//echo $sqlP;
		$rsP = $db->Execute($sqlP);

		$message = 'Admin edited program information';
		audit_log($userID, $message, 20, 0, $pid);


	//--------------------------------------------------- THRESHOLD SECTION ---------------------------------------------------------
		if ($new_val_type==1){
			
			$sql = "delete from HMIS_Custom_Threshold where program_id=$pid";
			$rs = $db->Execute($sql);

			//---------------------------------- client.csv --------------------------------------------------------
			$LegalFirstName_ack = scrub_sql(scrub_white_list(trim($_POST['LegalFirstName_ack']),'NUMERICONLY'), 3);
			$LegalFirstName_rej = scrub_sql(scrub_white_list(trim($_POST['LegalFirstName_rej']),'NUMERICONLY'), 3);
			$sql = "INSERT INTO HMIS_Custom_Threshold (program_id, user_id, format_id, format_name, field_name, util_rate_ack_type, util_rate_ack, util_rate_rej_type, util_rate_rej, date_changed)
					VALUES ($pid, $userID, 97, 'client.csv', 'LegalFirstName', 'A', $LegalFirstName_ack, 'A', $LegalFirstName_rej, getdate())";
			$rs = $db->Execute($sql);

			$LegalLastName_ack = scrub_sql(scrub_white_list(trim($_POST['LegalLastName_ack']),'NUMERICONLY'), 3);
			$LegalLastName_rej = scrub_sql(scrub_white_list(trim($_POST['LegalLastName_rej']),'NUMERICONLY'), 3);
			$sql = "INSERT INTO HMIS_Custom_Threshold (program_id, user_id, format_id, format_name, field_name, util_rate_ack_type, util_rate_ack, util_rate_rej_type, util_rate_rej, date_changed)
					VALUES ($pid, $userID, 99, 'client.csv', 'LegalLastName', 'A', $LegalLastName_ack, 'A', $LegalLastName_rej, getdate())";
			$rs = $db->Execute($sql);


			$SocialSecurityNumber_ack = scrub_sql(scrub_white_list(trim($_POST['SocialSecurityNumber_ack']),'NUMERICONLY'), 3);
			$SocialSecurityNumber_rej = scrub_sql(scrub_white_list(trim($_POST['SocialSecurityNumber_rej']),'NUMERICONLY'), 3);
			$sql = "INSERT INTO HMIS_Custom_Threshold (program_id, user_id, format_id, format_name, field_name, util_rate_ack_type, util_rate_ack, util_rate_rej_type, util_rate_rej, date_changed)
					VALUES ($pid, $userID, 101, 'client.csv', 'SocialSecurityNumber', 'A', $SocialSecurityNumber_ack, 'A', $SocialSecurityNumber_rej, getdate())";
			$rs = $db->Execute($sql);


			$DateOfBirth_ack = scrub_sql(scrub_white_list(trim($_POST['DateOfBirth_ack']),'NUMERICONLY'), 3);
			$DateOfBirth_rej = scrub_sql(scrub_white_list(trim($_POST['DateOfBirth_rej']),'NUMERICONLY'), 3);
			$sql = "INSERT INTO HMIS_Custom_Threshold (program_id, user_id, format_id, format_name, field_name, util_rate_ack_type, util_rate_ack, util_rate_rej_type, util_rate_rej, date_changed)
					VALUES ($pid, $userID, 103,  'client.csv', 'DateOfBirth', 'A', $DateOfBirth_ack, 'A,D', $DateOfBirth_rej, getdate())";
			$rs = $db->Execute($sql);


			$PrimaryRace_ack = scrub_sql(scrub_white_list(trim($_POST['PrimaryRace_ack']),'NUMERICONLY'), 3);
			$PrimaryRace_rej = scrub_sql(scrub_white_list(trim($_POST['PrimaryRace_rej']),'NUMERICONLY'), 3);
			$sql = "INSERT INTO HMIS_Custom_Threshold (program_id, user_id, format_id, format_name, field_name, util_rate_ack_type, util_rate_ack, util_rate_rej_type, util_rate_rej, date_changed)
					VALUES ($pid, $userID, 105, 'client.csv', 'PrimaryRace', 'A,E', $PrimaryRace_ack, 'A,B', $PrimaryRace_rej, getdate())";
			$rs = $db->Execute($sql);


			$Ethnicity_ack = scrub_sql(scrub_white_list(trim($_POST['Ethnicity_ack']),'NUMERICONLY'), 3);
			$Ethnicity_rej = scrub_sql(scrub_white_list(trim($_POST['Ethnicity_rej']),'NUMERICONLY'), 3);
			$sql = "INSERT INTO HMIS_Custom_Threshold (program_id, user_id, format_id, format_name, field_name, util_rate_ack_type, util_rate_ack, util_rate_rej_type, util_rate_rej, date_changed)
					VALUES ($pid, $userID, 107, 'client.csv', 'Ethnicity', 'A,C', $Ethnicity_ack, 'A,B', $Ethnicity_rej, getdate())";
			$rs = $db->Execute($sql);


			$Gender_ack = scrub_sql(scrub_white_list(trim($_POST['Gender_ack']),'NUMERICONLY'), 3);
			$Gender_rej = scrub_sql(scrub_white_list(trim($_POST['Gender_rej']),'NUMERICONLY'), 3);
			$sql = "INSERT INTO HMIS_Custom_Threshold (program_id, user_id, format_id, format_name, field_name, util_rate_ack_type, util_rate_ack, util_rate_rej_type, util_rate_rej, date_changed)
					VALUES ($pid, $userID, 108, 'client.csv', 'Gender', 'A,C', $Gender_ack, 'A,B', $Gender_rej, getdate())";
			$rs = $db->Execute($sql);


			//---------------------------------- clienthistorical.csv ------------------------------------------------
			$IncomeLast30Days_ack = scrub_sql(scrub_white_list(trim($_POST['IncomeLast30Days_ack']),'NUMERICONLY'), 3);
			$IncomeLast30Days_rej = scrub_sql(scrub_white_list(trim($_POST['IncomeLast30Days_rej']),'NUMERICONLY'), 3);
			$sql = "INSERT INTO HMIS_Custom_Threshold (program_id, user_id, format_id, format_name, field_name, util_rate_ack_type, util_rate_ack, util_rate_rej_type, util_rate_rej, date_changed)
					VALUES ($pid, $userID, 122, 'clienthistorical.csv', 'IncomeLast30Days', 'A', $IncomeLast30Days_ack, 'A,B', $IncomeLast30Days_rej, getdate())";
			$rs = $db->Execute($sql);


			$NonCashBenefitsLast30Days_ack = scrub_sql(scrub_white_list(trim($_POST['NonCashBenefitsLast30Days_ack']),'NUMERICONLY'), 3);
			$NonCashBenefitsLast30Days_rej = scrub_sql(scrub_white_list(trim($_POST['NonCashBenefitsLast30Days_rej']),'NUMERICONLY'), 3);
			$sql = "INSERT INTO HMIS_Custom_Threshold (program_id, user_id, format_id, format_name, field_name, util_rate_ack_type, util_rate_ack, util_rate_rej_type, util_rate_rej, date_changed)
					VALUES ($pid, $userID, 123, 'clienthistorical.csv', 'NonCashBenefitsLast30Days', 'A', $NonCashBenefitsLast30Days_ack, 'A,B', $NonCashBenefitsLast30Days_rej, getdate())";
			$rs = $db->Execute($sql);

			//---------------------------------- programparticipation.csv --------------------------------------------
			$EntryDate_ack = scrub_sql(scrub_white_list(trim($_POST['EntryDate_ack']),'NUMERICONLY'), 3);
			$EntryDate_rej = scrub_sql(scrub_white_list(trim($_POST['EntryDate_rej']),'NUMERICONLY'), 3);
			$sql = "INSERT INTO HMIS_Custom_Threshold (program_id, user_id, format_id, format_name, field_name, util_rate_ack_type, util_rate_ack, util_rate_rej_type, util_rate_rej, date_changed)
					VALUES ($pid, $userID, 185, 'programparticipation.csv', 'EntryDate', 'A', $EntryDate_ack, 'A', $EntryDate_rej, getdate())";
			$rs = $db->Execute($sql);

			$VeteranStatus_ack = scrub_sql(scrub_white_list(trim($_POST['VeteranStatus_ack']),'NUMERICONLY'), 3);
			$VeteranStatus_rej = scrub_sql(scrub_white_list(trim($_POST['VeteranStatus_rej']),'NUMERICONLY'), 3);
			$sql = "INSERT INTO HMIS_Custom_Threshold (program_id, user_id, format_id, format_name, field_name, util_rate_ack_type, util_rate_ack, util_rate_rej_type, util_rate_rej, date_changed)
					VALUES ($pid, $userID, 188, 'programparticipation.csv', 'VeteranStatus', 'O', $VeteranStatus_ack, 'O,B', $VeteranStatus_rej, getdate())";
			$rs = $db->Execute($sql);
			
			$DisablingCondition_ack = scrub_sql(scrub_white_list(trim($_POST['DisablingCondition_ack']),'NUMERICONLY'), 3);
			$DisablingCondition_rej = scrub_sql(scrub_white_list(trim($_POST['DisablingCondition_rej']),'NUMERICONLY'), 3);
			$sql = "INSERT INTO HMIS_Custom_Threshold (program_id, user_id, format_id, format_name, field_name, util_rate_ack_type, util_rate_ack, util_rate_rej_type, util_rate_rej, date_changed)
					VALUES ($pid, $userID, 189, 'programparticipation.csv', 'DisablingCondition', 'A', $DisablingCondition_ack, 'A,B', $DisablingCondition_rej, getdate())";
			$rs = $db->Execute($sql);

			$PriorResidence_ack = scrub_sql(scrub_white_list(trim($_POST['PriorResidence_ack']),'NUMERICONLY'), 3);
			$PriorResidence_rej = scrub_sql(scrub_white_list(trim($_POST['PriorResidence_rej']),'NUMERICONLY'), 3);
			$sql = "INSERT INTO HMIS_Custom_Threshold (program_id, user_id, format_id, format_name, field_name, util_rate_ack_type, util_rate_ack, util_rate_rej_type, util_rate_rej, date_changed)
					VALUES ($pid, $userID, 190, 'programparticipation.csv', 'PriorResidence', 'O', $PriorResidence_ack, 'O,B', $PriorResidence_rej, getdate())";
			$rs = $db->Execute($sql);

			$LengthOfStayAtPriorResidence_ack = scrub_sql(scrub_white_list(trim($_POST['LengthOfStayAtPriorResidence_ack']),'NUMERICONLY'), 3);
			$LengthOfStayAtPriorResidence_rej = scrub_sql(scrub_white_list(trim($_POST['LengthOfStayAtPriorResidence_rej']),'NUMERICONLY'), 3);
			$sql = "INSERT INTO HMIS_Custom_Threshold (program_id, user_id, format_id, format_name, field_name, util_rate_ack_type, util_rate_ack, util_rate_rej_type, util_rate_rej, date_changed)
					VALUES ($pid, $userID, 191, 'programparticipation.csv', 'LengthOfStayAtPriorResidence', 'O', $LengthOfStayAtPriorResidence_ack, 'O,B', $LengthOfStayAtPriorResidence_rej, getdate())";
			$rs = $db->Execute($sql);

			$ZIPCode_ack = scrub_sql(scrub_white_list(trim($_POST['ZIPCode_ack']),'NUMERICONLY'), 3);
			$ZIPCode_rej = scrub_sql(scrub_white_list(trim($_POST['ZIPCode_rej']),'NUMERICONLY'), 3);
			$sql = "INSERT INTO HMIS_Custom_Threshold (program_id, user_id, format_id, format_name, field_name, util_rate_ack_type, util_rate_ack, util_rate_rej_type, util_rate_rej, date_changed)
					VALUES ($pid, $userID, 192, 'programparticipation.csv', 'ZIPCode', 'O,M', $ZIPCode_ack, 'O', $ZIPCode_rej, getdate())";
			$rs = $db->Execute($sql);

			$HousingStatusAtEntry_ack = scrub_sql(scrub_white_list(trim($_POST['HousingStatusAtEntry_ack']),'NUMERICONLY'), 3);
			$HousingStatusAtEntry_rej = scrub_sql(scrub_white_list(trim($_POST['HousingStatusAtEntry_rej']),'NUMERICONLY'), 3);
			$sql = "INSERT INTO HMIS_Custom_Threshold (program_id, user_id, format_id, format_name, field_name, util_rate_ack_type, util_rate_ack, util_rate_rej_type, util_rate_rej, date_changed)
					VALUES ($pid, $userID, 194,  'programparticipation.csv', 'HousingStatusAtEntry', 'A', $HousingStatusAtEntry_ack, 'A,B', $HousingStatusAtEntry_rej, getdate())";
			$rs = $db->Execute($sql);

			//$HousingStatusAtExit_ack = scrub_sql(scrub_white_list(trim($_POST['HousingStatusAtExit_ack']),'NUMERICONLY'), 3);
			//$HousingStatusAtExit_rej = scrub_sql(scrub_white_list(trim($_POST['HousingStatusAtExit_rej']),'NUMERICONLY'), 3);
			//$sql = "INSERT INTO HMIS_Custom_Threshold (program_id, user_id, format_id, format_name, field_name, util_rate_ack_type, util_rate_ack, util_rate_rej_type, util_rate_rej, date_changed)
			//		VALUES ($pid, $userID, 195, 'programparticipation.csv', 'HousingStatusAtExit', 'A', $HousingStatusAtExit_ack, 'A,B', $HousingStatusAtExit_rej, getdate())";
			//$rs = $db->Execute($sql);

			$HouseholdIdentificationNumber_ack = scrub_sql(scrub_white_list(trim($_POST['HouseholdIdentificationNumber_ack']),'NUMERICONLY'), 3);
			$HouseholdIdentificationNumber_rej = scrub_sql(scrub_white_list(trim($_POST['HouseholdIdentificationNumber_rej']),'NUMERICONLY'), 3);
			$sql = "INSERT INTO HMIS_Custom_Threshold (program_id, user_id, format_id, format_name, field_name, util_rate_ack_type, util_rate_ack, util_rate_rej_type, util_rate_rej, date_changed)
					VALUES ($pid, $userID, 196,  'programparticipation.csv', 'HouseholdIdentificationNumber', 'A', $HouseholdIdentificationNumber_ack, 'A', $HouseholdIdentificationNumber_rej, getdate())";
			$rs = $db->Execute($sql);

			$Destination_ack = scrub_sql(scrub_white_list(trim($_POST['Destination_ack']),'NUMERICONLY'), 3);
			$Destination_rej = scrub_sql(scrub_white_list(trim($_POST['Destination_rej']),'NUMERICONLY'), 3);
			$sql = "INSERT INTO HMIS_Custom_Threshold (program_id, user_id, format_id, format_name, field_name, util_rate_ack_type, util_rate_ack, util_rate_rej_type, util_rate_rej, date_changed)
					VALUES ($pid, $userID, 198, 'programparticipation.csv', 'Destination', 'P', $Destination_ack, 'P,B', $Destination_rej, getdate())";
			$rs = $db->Execute($sql); 

			$message = 'Admin edited program-specific information validation threshholds';
			audit_log($userID, $message, 15, 0, $pid);


			//END THRESHOLD SECTION
		}
	print_header();
		$sqlDisp = "SELECT sp.program_name, sg.grant_name FROM tb_SSVF_program sp, tb_SSVF_grant sg WHERE sp.program_id=$pid AND sg.grant_id=sp.grant_id";
		$rsDisp = $db->Execute($sqlDisp);

		while (!$rsDisp->EOF){
			$pNameDisp = $rsDisp->fields('program_name');
			$gNameDisp = $rsDisp->fields('grant_name');
				
		$rsDisp->MoveNext();
		}

		print ("
			<table width=800 align=center>
			<tr><td>
			<BR>
			<HR>
			<H1 align=center>Program Information Updated</H1>
			<center>
			<font size=2><b>$pNameDisp</b></font>
			<br>
			<font size=1><i>$gNameDisp</i></font>
			</center>
			<HR>
			<H3 align=center>This program information has been updated successfully.</H3>
			<BR>
			<CENTER><A HREF=manage_programs.php?s=$new_val_type>Manage Programs</A> | <A HREF=menu.php>HMIS Repository Home</A></CENTER>
			<HR>
			</td></tr></table>
			");

	print_footer();
	} // end if no errors


	// display error message
	else {
	print_header();
	print "<br><hr><h1 align=center>$message</h1><hr><h3 align=center>Please press the Back button to return to previous page</h3>";
	print_footer();
	}
}
else{ //etoken check: false
	$message = "Error: Invalid session!";
	print_header();
		print "<br><hr><h1 align=center>$message</h1><hr><h3 align=center>Please press the Back button to return to previous page.</h3>";
		print_footer();

}
?>