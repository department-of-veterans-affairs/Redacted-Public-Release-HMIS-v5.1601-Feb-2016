<?php
include('init.php');

include('hmis/libs/functions.php');

print_header();


?>
<BR>
<H1 align="center">HMIS Repository Support Page</H1>

<?if ($userID>0) {?>
<CENTER><A HREF="menu.php">Home</A></CENTER>
<?}?>
<HR>

<BR>

<div id="body" style="margin-left: auto; margin-right: auto; width: 755px;">

<?


$sql = "SELECT html FROM tb_content WHERE page_id=3";
$rs = $db->Execute($sql);
$record_count = $rs->RecordCount();
if ($record_count == 1) {
	$html = scrub_white_list($rs->fields('html'), 'HTMLNOSCRIPT');
echo $html;
}


else {print "no content";}

?>

</div>

<?
print_footer();
?>