<?php

//FOR TESTING
//include('../init.php');
//include('functions.php');

include('init.php');
include('hmis/libs/functions.php');


$e_token = trim(scrub_white_list($_POST['e_token'], 'ALPHANUMERICONLY'));
$s_e_token = $_SESSION['e_token'];

//echo "e_token -> " . $e_token;
//echo "<BR>s_e_token -> " . $s_e_token;
if ((ISSET($e_token)) && ($e_token===$s_e_token)){
	if (checklogin($userID, "menu.php") && $status == 2) {
		if (isset($_REQUEST['recipient']) && isset($_REQUEST['subject']) && isset($_REQUEST['body'])) { 
			$recipient = scrub_white_list($_REQUEST['recipient'], 'HTMLNOSCRIPT');
			$subject = scrub_white_list($_REQUEST['subject'], 'USER');

			$body = $_REQUEST['body'];
			$body = nl2br($body);
			$body = scrub_white_list($body, 'HTMLNOSCRIPT');


		$to = "";

		if ($recipient == 1) {
			$sql = "select email from tb_user";
		}
		else if ($recipient == 2) {
			$sql = "select email from tb_user WHERE status=1";
		}
		else if ($recipient == 3) {
			$sql = "select email from tb_user u, tb_SSVF_Program p, tb_user_programs j  WHERE u.status=1 AND p.status=1 AND j.user_id=u.user_id AND j.program_id=p.program_id";
		}
		else if ($recipient == 4) {
			$sql = "select email from tb_user u, tb_SSVF_Program p, tb_user_programs j  WHERE u.status=1 AND p.status=3 AND j.user_id=u.user_id AND j.program_id=p.program_id";
		}
		//else if ($recipient == 5) {
			//$sql = "select email from tb_user WHERE status=1";
		//}
		//else if ($recipient == 6) {
			//$sql = "select email from tb_user WHERE status=1";
		//}
		//else{
			//$sql = "select email from tb_user";
		//}



	if ($recipient == 5 || $recipient == 6){
		if(isset($_REQUEST['toList'])){
			$toList = scrub_white_list($_REQUEST['toList'], 'HTMLNOSCRIPT');
			$to = $toList;
		}
	}
	else{
		$rs = $db->Execute($sql);
		$results = 0;

		while (!$rs->EOF){ 
			//$email = $rs->fields('email');
			$email = scrub_sql(scrub_white_list(trim($rs->fields('email')),'USER'), 150);
			
			if ($results > 0) {
				$to = $to . ",";
			}
			$to = $to . $email;
			$results = $results + 1;
			$rs->MoveNext();
		}
	}

	//$headers = "Bcc: HMIS Users \n" . "From: HMIS Repository Admin <noreply@domain>\n" . "MIME-Version: 1.0\n" . "Content-type: text/html; charset=iso-8859-1";

	$headers = "From: HMIS Repository Admin <noreply@domain>\n";
	$headers .= "To: HMIS Recipients <noreply@hmisrepository.domain>\n";
	$headers .= "Bcc: " . $to . " \n";
	$headers .= "MIME-Version: 1.0\n";
	$headers .= "Content-type: text/html; charset=iso-8859-1";


	// UNCOMMENT FOR MAIL TEST
	//mail( $to, $subject, $body, $headers );
	mail(null, $subject, $body, $headers );


	$eventmsg = 'Admin sent email using Send Email function';
	audit_log($userID, $eventmsg, 13);


	print_header();

	?>


	<H1 align=center>Message Sent</H1>
	<HR>

	<? echo "<CENTER>Your email has been sent.<br><A HREF='menu.php'>Click here to continue</A></CENTER>"; 


	?>

	<BR><BR><BR>
	<?

	print_footer();

		} // end check form

	else {print "Error";}

	} // end check login
}

else{ //etoken check: false
	$message = "Error: Invalid session!";
	print_header();
		print "<br><hr><h1 align=center>$message</h1><hr><br><A HREF='menu.php'>Click here to continue</A>";
		print_footer();

}

?>