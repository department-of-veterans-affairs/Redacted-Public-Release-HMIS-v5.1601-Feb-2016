<?
	//require_once('/var/hmis_libs/config.php');
	include('../init.php');
	require_once('libs/functions.php');
	
	if ( 'insert' == $_GET['req'] ) {
		
		$file_id = scrub_white_list($_GET['file'], 'ALPHANUMERICONLY');
		$user_id = scrub_white_list($_GET['uldr'], 'NUMBERONLY'); 
		$zip_file_name = scrub_white_list($_GET['zip'], 'FILENAME');
		$program_id = scrub_white_list($_GET['program_id'], 'BASIC');
		$dataset_id = scrub_sql(scrub_white_list($_GET['dataset_id'], 'NUMBERONLY'), 1);
		$format_version = scrub_sql(scrub_white_list($_REQUEST['format_version'], 'NUMBERONLY'), 1);
		
		$spacer = '&nbsp; &nbsp; &nbsp; &nbsp;';
		
		
		$sql = 'Select program_name, grant_id From tb_SSVF_program Where program_id = ' . $program_id;
		$rs = $db->Execute($sql) or die ("<br>SQL failed");	
		$program_name = $rs->fields('program_name');
			
		$sql = 'Select username, email From tb_user Where user_id = ' . $user_id;
		$rs = $db->Execute($sql) or die ("<br>SQL failed");	
		$user_name = $rs->fields('username');
		$user_email = $rs->fields('email');
		
		$msg = '
				<table width=755 align="center">
				<tr class="va-section-header" width="550">
					<td colspan=2>&nbsp;  </td>
				</tr>
				<tr>
					<td>
			';
		$msg = $msg . '<br><b>[File Upload Information] </b><br><br>';
		$msg = $msg . 'Program name: ' . $program_name . '<br />';
		$msg = $msg . 'User name: ' . $user_name . '<br />';
		$msg = $msg . 'User email: ' . $user_email . '<br />';
		$msg = $msg . 'File name: ' . $zip_file_name . '<br />';
		
		$msg = $msg . '<br><b>[DB Insert Result] </b><br><br>';
		
			
		if (!is_numeric($user_id)) {
			echo 'Error. Invalid uldr: ' . $user_id;
			exit;
		}
		
		
		if ( 4 == $dataset_id ) {
			$valid_file_names = $valid_file_names_v4;
			$valid_file_name_count = $valid_file_name_count_v4;
			$status_init = 1;
			
		} else {
			
		}
		
		$tmp_work_dir = $file_upload_path . $file_id . '/';
		$tmp_work_unzip_dir = $tmp_work_dir . 'unzip/';
		
		global $db;
		if ($dh = opendir($tmp_work_unzip_dir)) {
			$file_num = 0;
			while ( ($file_name = readdir($dh)) !== false ) {
				if ( !(('.' == $file_name) || ('..' == $file_name)) ) {
					$file_num++;
					
					$file_name = scrub_white_list($file_name, 'FILENAME');
					
					$new_file_name =  strtolower (str_replace('_', '', trim($file_name)));
					$tmp_msg = 'Index ' . $file_num . ": <b>$file_name</b> "; 
					echo $tmp_msg;
					
					
					$msg = $msg . $tmp_msg;
					
					
					if (in_array($new_file_name, $valid_file_names)) {
					
						
						$sql = 'Select * From FileFormat Where format_name = \'' . $new_file_name . '\' and format_version = ' . $dataset_id . ' Order By format_order';
						$rs = $db->Execute($sql) or die ("<br>Select file failed");
						$record_count = $rs->RecordCount();
			
						if (($handle = fopen($tmp_work_unzip_dir . $file_name, "r")) !== FALSE) {
							
							$row = 0;
							$total_row = count(file($tmp_work_unzip_dir . $file_name));
							$actual_num_row = $total_row - 1;
			
							$tmp_msg = '['. $total_row . ' rows found in the file.] <br>';
							echo $tmp_msg;
							
							
							$msg = $msg . $tmp_msg;
							
							$insert_sql_head = 'Insert Into ';
							$skip_file = 'N';
							$import = '';	
							$null = 'N';	
							
							if ( 4 == $dataset_id ) {
								
								switch ($new_file_name) {
									
									case 'export.csv':
										$insert_sql_head .= 'td_Export (';
										break;
										
									case 'exit.csv':
										$insert_sql_head .= 'td_Exit (';
										break;
										
									case 'client.csv':
										$insert_sql_head .= 'td_Client (';
										break;
										
									case 'enrollment.csv':
										$insert_sql_head .= 'td_Enrollment (';
										break;
										
									case 'enrollmentcoc.csv':
										$insert_sql_head .= 'td_EnrollmentCoC (';
										break;
										
									case 'project.csv':
										$insert_sql_head .= 'td_Project (';
										break;
										
									case 'projectcoc.csv':
										$insert_sql_head .= 'td_ProjectCoC (';
										break;
										
									case 'services.csv':
										$insert_sql_head .= 'td_Services (';
										break;
										
									case 'incomebenefits.csv':
										$insert_sql_head .= 'td_IncomeBenefits (';
										break;
										
									default:
										
										$skip_file = 'Y';
										$tmp_msg = '<b><font color="red">Notice:</font></b> Unsupported file: ' . $file_name . ' is skipped. <br>';
										
										echo $tmp_msg;
										$msg = $msg . $tmp_msg;
										
										
										break;		
								}
								
							} else {	
								switch ($new_file_name) {
									
									case 'export.csv':
										$insert_sql_head .= 'data_Export (';
										break;
										
									case 'agencyprogram.csv':
										$insert_sql_head .= 'data_AgencyProgram (';
										break;
										
									case 'client.csv':
										$insert_sql_head .= 'data_Client (';
										break;
										
									case 'clienthistorical.csv':
										$insert_sql_head .= 'data_ClientHistorical (';
										break;
										
									case 'incomebenefits.csv':
										$insert_sql_head .= 'data_IncomeBenefits (';
										break;
										
									case 'serviceevent.csv':
										$insert_sql_head .= 'data_ServiceEvent (';
										break;
										
									case 'programparticipation.csv':
										$insert_sql_head .= 'data_ProgramParticipation (';
										break;
										
									default:
										
										$skip_file = 'Y';
										$tmp_msg = '<b><font color="red">Notice:</font></b> Unsupported file: ' . $file_name . ' is skipped. <br>';
										
										echo $tmp_msg;
										$msg = $msg . $tmp_msg;
										
										//exit;
										break;		
								} 
								
							}
							
							while (($data = fgetcsv($handle)) !== FALSE && 'N' == $skip_file) {
								
								$num = count($data);	
								
								if ( 4 == $dataset_id ) {
									$insert_sql_columns = 'File_ID, Program_ID, Status';
									$insert_sql_values = 'Values (\'' . $file_id . '\', ' . $program_id. ', ' . $status_init;
								} else {
									$insert_sql_columns = 'FileID, UserID';
									$insert_sql_values = 'Values (\'' . $file_id . '\', ' . $user_id;
								}
														
								$row++;
								if (1 == $row) {
									
									continue;
								}
								
								
								$rs->movefirst();	//reset for the next row
								
								for ($c=0; $c < $num; $c++) {
									
									$col_num = $c + 1;
									$value = scrub_white_list($data[$c], 'DATA');	
									$data_length = strlen($value);
									
									$field_name = $rs->fields('field_name');
									$data_type = $rs->fields('data_type');
									//$allow_null = $rs->fields('allow_null');
									//$pick_list = $rs->fields('pick_list');
									$field_length = $rs->fields('field_length');
									$skip_data = $rs->fields('skip_data');
							
									
									if ('client.csv' == $new_file_name && 'Gender' == $field_name && 4 == $value) {
										$import = 'Y';	
									} else if ('client.csv' == $new_file_name && 'OtherGender' == $field_name && 'Y' != $import) {
										$value = '';	
									} else if ('client.csv' == $new_file_name && 'OtherGender' == $field_name && 'Y' == $import) {
										$import = 'N';	
									}
									
									if ('enrollment.csv' == $new_file_name && 'ResidencePrior' == $field_name && 17 == $value) {
										$import = 'Y';	
									} else if ('enrollment.csv' == $new_file_name && 'OtherResidencePrior' == $field_name && 'Y' != $import) {
										$value = '';	
									} else if ('enrollment.csv' == $new_file_name && 'OtherResidencePrior' == $field_name && 'Y' == $import) {
										$import = 'N';	
									}
										
									if ('enrollment.csv' == $new_file_name && 'EntryFromStreetESSH' == $field_name && 1 == $value) {
										$import = 'Y';	
									} else if ('enrollment.csv' == $new_file_name && 'DateToStreetESSH' == $field_name && 'Y' != $import) {
										$value = 'NULL';
										$null = 'Y';
									} else if ('enrollment.csv' == $new_file_name && 'DateToStreetESSH' == $field_name && 'Y' == $import) {
										$import = 'N';	
									}
									
									if ('enrollment.csv' == $new_file_name && 'TimesHomelessPastThreeYears' == $field_name && 1 <= $value && 4 >= $value) {
										$import = 'Y';	
									} else if ('enrollment.csv' == $new_file_name && 'MonthsHomelessPastThreeYears' == $field_name && 'Y' != $import) {
										$value = '';	
									} else if ('enrollment.csv' == $new_file_name && 'MonthsHomelessPastThreeYears' == $field_name && 'Y' == $import) {
										$import = 'N';	
									}
									
									if ('exit.csv' == $new_file_name && 'Destination' == $field_name && 17 == $value) {
										$import = 'Y';	
									} else if ('exit.csv' == $new_file_name && 'OtherDestination' == $field_name && 'Y' != $import) {
										$value = '';	
									} else if ('exit.csv' == $new_file_name && 'OtherDestination' == $field_name && 'Y' == $import) {
										$import = 'N';	
									}
									
																			
									if ('N' == $skip_data) {
										
										if ('N' == $data_type) {
											if (0 != strlen(trim($value))) {
												$insert_sql_columns .= ', ' . $field_name;
												$insert_sql_values .= ', ' . scrub_sql($value, $field_length);
											}
											
										} else if ('Y' == $null) {
											
											$insert_sql_columns .= ', ' . $field_name;
											$insert_sql_values .= ', NULL';
											$null = 'N';
											
										} else {
											$insert_sql_columns .= ', ' . $field_name;
											$insert_sql_values .= ', \'' . scrub_sql($value, $field_length) . '\'';
										}
									}
	
									$rs->movenext();
								}	
								
								$insert_sql_columns .= ') ';
								$insert_sql_values .= ') ';
										
								$insert_sql = $insert_sql_head . $insert_sql_columns . $insert_sql_values;
								
								$rs_insert = $db->Execute($insert_sql) or die ("<br>Insert data failed.");	
								
							}	
							
							$tmp_msg = ' - <font color="blue"><b>Data insert Successful.</b></font> <br>';
							
							echo $tmp_msg;
							$msg = $msg . $tmp_msg;
							
						} else {
							
							$result = 'Error. File not available.';
							
							$msg = $msg . $result;
						}
					} else {
						$tmp_msg = '<br> - <b><font color="red">Data insert skipped.</font> This is not a supported file name.</b><br>';
						
						echo $tmp_msg;
						$msg = $msg . $tmp_msg;
					}
					
				
				
				} //end . & ..
				
			}	
			closedir($dh);
		} else {
				
			$result = 'Error. Folder not available.';
			
			$msg = $msg . $result;
		}

		
		echo '<br><br><b>Step 4. DB Insert </b>';
		
		$rs = $db->Execute("SELECT TOP 10 * FROM HMIS_Files ORDER BY ID ASC");
		$arr = $rs->GetArray();
		
		$zip_file_path = $tmp_work_dir . $zip_file_name;
		
		$file_content = file_get_contents($zip_file_path);
		$hex_file_content = '0x'.bin2hex($file_content);
		$safe_zip_file_name = scrub_sql($zip_file_name, 50);
		
		$sql = 'Insert Into HMIS_Files (file_id, user_id, program_id, dataset_id, name, zipfile, file_type, validation, data_insert) OUTPUT Inserted.ID Values (';
		$sql .= "'$file_id', '$user_id', '$program_id', '$dataset_id', '$safe_zip_file_name', $hex_file_content, 'CSV', 1, 1)";
		$zip_file_id = $db->Execute($sql) or die ("<br>Insert file failed");

		$result = '<br><br>' . $spacer . '<font color="navy">* ' . $zip_file_name.' with file id ' . $zip_file_id . ' has been inserted successfully to the database.</font>';
		echo $result;
		
		$msg = $msg . $result;
		
		$sql = 'Update tb_SSVF_program SET status = 3, upload_id = \'' . $file_id . '\', upload_date = getdate()  Where program_id = ' . $program_id;
		$rs = $db->Execute($sql) or die ("<br>Insert file failed");
		
		$result = '<br>' . $spacer . '<font color="navy">* Program Status has been updated as completed.</font>';
		echo $result;
		
		$msg = $msg . $result;
		
		$sql = 'Select name, zipfile From HMIS_Files Where id = ';
		$sql .= "'$zip_file_id'";
		
		if ( 4 == $dataset_id ) {
			
			$sql = 'SELECT * from dbo.GetSummary (\'' . $file_id . '\')';
			$rs = $db->Execute($sql) or die ("<br>Select data summary failed");
			
			$tmp_msg = '<br><br><br><b>[ Data Summary ]</b><br>';
			
			echo $tmp_msg;
			$msg = $msg . $tmp_msg;
			
			$tmp_msg = '<table border="0"><tr><td> </td> <td>  </td></tr>';
			
			echo $tmp_msg;
			$msg = $msg . $tmp_msg;
			
			while (!$rs->EOF) {
				
				$tmp_msg = '<tr><td>' . $rs->fields('category') . '</td>';
				
				echo $tmp_msg;
				$msg = $msg . $tmp_msg;
				
				$tmp_msg = '<td> : ' . $rs->fields('number') . '</td></tr>';
				
				echo $tmp_msg;
				$msg = $msg . $tmp_msg;
				
				$rs->MoveNext();
			}
			$tmp_msg = '</table>';
			
			echo $tmp_msg;
			$msg = $msg . $tmp_msg;
		}
		
		$rs->Close();
		
		$result = '<br><br>' . $spacer . '<font color="navy"><b>The upload was successful and the data has been accepted.</b></font>';
		
		$msg = $msg . $result;
		
		delete_hmis_files($tmp_work_dir);
		
		inactivate_all_previous_data($user_id, $program_id, $file_id, $dataset_id);
		//return $result;
		$message = 'User inserted data';
		audit_log($user_id, $message, 61, $file_id, $program_id);
		
	} else {
		$result = 'Error. Invalid Request Type';
		
		$msg = $msg . $result;
		
		//return 'error';
	}
	
	$send_email = 1;
	
	if (1 == $send_email) {	//waiting confirmaiton from Molly - 02/18/2015
		$headers =  "From: Repository <noreply@domain>\n" . "MIME-Version: 1.0\n" . "Content-type: text/html; charset=iso-8859-1";
		
		$html_msg = '<html><body>' . $msg . '</body></html>';
	
		mail($hmis_csv_report_email, 'HMIS file upload report (DB Insert Result): ' . SERVER_ENV, $html_msg, $headers);
	}
	
	echo $result;
	exit;
?>
