<?

//define('PATH_TO_CLASSES', pathinfo(__FILE__, PATHINFO_DIRNAME));
define('PATH_TO_CLASSES', './libs');

function __autoload($classname) {
	$files = array(
		'HMISValidator' => 'class.HMISValidator.php'
	);

	if ( '' != $files[$classname] ) {
		if ( false === file_exists(PATH_TO_CLASSES . '/' . $files[$classname]) ) {
			throw new Exception("No such file as " . PATH_TO_CLASSES . '/' . $files[$classname]);
		}
	
		if ( true === defined('PATH_TO_CLASSES') ) {
			require_once(PATH_TO_CLASSES . '/' . $files[$classname]);
		}
	
		if ( false === class_exists($classname) ) {
			throw new Exception("No such class as {$classname}");
		}
	}

}

?>
