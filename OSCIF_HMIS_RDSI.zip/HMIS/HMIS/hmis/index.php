<?
include('../init.php');
	require_once('libs/functions.php');

if (checklogin($userID, 'menu.php') && 'off' != $_SESSION['hmis_switch']) {


	$sql = 'Select program_id, program_name, status From view_program Where USER_ID = ' . $userID . ' Order By program_name';
	$rs = $db->Execute($sql) or die ("<br>SQL failed");	//die ("<br>$sql <br>SQL failed");
	$select_program = '';
	
	while (!$rs->EOF) { 

		$program_id = $rs->fields('program_id');
		$program_name = $rs->fields('program_name');
		$program_status = $rs->fields('status');
		if (1 == $program_status) {
			$status_msg = 'Not Started';
		} else if (2 == $program_status) {
			$status_msg = 'Incomplete';
		} else if (3 == $program_status) {
			$status_msg = 'Complete';
		} else {
			$status_msg = 'Not Started';
		}
		
		$select_program = $select_program . "<option value='$program_id'>$program_name [$status_msg]</option>\n";
		
		$rs->MoveNext();
	}
	
	$sql = 'Select * from tb_dataset_info Order By dataset_type asc, dataset_version desc';
	$rs = $db->Execute($sql) or die ("<br>SQL failed");
	$select_dataset = '';
	
	while (!$rs->EOF) { 
		
		$dataset_id = $rs->fields('dataset_id');
		$dataset_type = $rs->fields('dataset_type');
		$dataset_version = $rs->fields('dataset_version');
		
		$select_dataset = $select_dataset . "<option value='$dataset_id'>$dataset_type [V $dataset_version]</option>\n";
		
		$rs->MoveNext();
	}
	
	$sql = 'Select html from tb_content where page_id = 2';
	$rs = $db->Execute($sql) or die ("<br>SQL failed");
	
	$content_2 = $rs->fields('html');

	print_header('','skip_menu');
?>	

	<script>
		function check_form() {
			var errs=0;
			
			if (document.forms.validate.program_id.value == 0) {alert('Please choose a program'); errs=1;}
			else if (document.forms.validate.dataset_id.value == 0) {alert('Please choose a dataset type'); errs=1;}
			
			//else if (document.forms.validate.user.value.length < 4) {alert('Username must be at least 4 characters in length'); errs=1;}
			else if (!isDate(document.forms.validate.export_date.value)){
				//alert("Please enter a valid date of export.\n"); 
				errs=1;
      			}
      			else if (document.forms.validate.file.value == '') {alert('Please choose a file to validate'); errs=1;}
      			
			<? 
				$sql = 'SELECT distinct hf.program_id FROM HMIS_Files hf, tb_user_programs tup
					where hf.program_id = tup.program_id and hf.status = \'ACTIVE\'
					and tup.user_id = ' . $userID . ' and upload_date between 
					DATEADD(mm, DATEDIFF(mm, 0, GETDATE()), 0) and DATEADD(ms, -3, DATEADD(mm, DATEDIFF(m, 0, GETDATE()) + 1, 0))';
		
				$rs = $db->Execute($sql) or die ("<br>SQL failed");
				//$program_counter = 0;
				$program_ids = '';
				while (!$rs->EOF) {
			
					$sql2 = 'SELECT TOP 1 hf.user_id, tu.username, hf.program_id, CONVERT(VARCHAR(20), hf.upload_date, 100) as upload_date
						FROM HMIS_Files hf, tb_user tu
						WHERE hf.program_id = ' . $rs->fields('program_id') . ' and hf.status = \'ACTIVE\'
						and upload_date between DATEADD(mm, DATEDIFF(mm, 0, GETDATE()), 0) and DATEADD(ms, -3, DATEADD(mm, DATEDIFF(m, 0, GETDATE()) + 1, 0))
						and tu.user_id = hf.user_id
						Order By upload_date desc';
		
					$rs2 = $db->Execute($sql2) or die ("<br>SQL failed");
			?>
					if ( <?=$rs->fields('program_id')?> == document.forms.validate.program_id.value ) {
			
						var r=confirm("Data for this program has already been uploaded this month on <?=$rs2->fields('upload_date')?> by <?=$rs2->fields('username')?>. Do you want to delete the previous data and upload again?")
						//alert('Data already exist in the system.'); 
						if (r==true){
							//alert("You pressed OK!")
						} else {
							//alert("You pressed Cancel!")
							errs=1;
						}
			
					}
					
			<?
					//$program_counter++;
					$rs->MoveNext();
				}
				//echo 'Program IDS: ' . $program_ids . '<br>';

			?>
			
      			
			return (errs==0);
		}
		
		var COMP = function()
		{
		    var obj = {};
		    for(var i=0; i<arguments.length; i++)
			obj[arguments[i]] = null;
		
		    return obj;
		};


	function lock_submit(){
		document.getElementById("btn_submit").disabled=true;
	}

	function unlock_submit(){
		var file_name = document.getElementById("file").value;
		//alert(file_name);

		if (file_name != ''){
			document.getElementById("btn_submit").disabled=false;
		}
		else{
			document.getElementById("btn_submit").disabled=true;
		}
	}
	</script>
	
	<SCRIPT LANGUAGE="JavaScript" SRC="CalendarPopup.js"></SCRIPT>

	<script language = "Javascript">
	var cal = new CalendarPopup();
	// Declaring valid date character, minimum year and maximum year
	var dtCh= "/";
	var minYear=1900;
	var maxYear=2100;
	
	function isInteger(s){
		var i;
	    for (i = 0; i < s.length; i++){   
		// Check that current character is number.
		var c = s.charAt(i);
		if (((c < "0") || (c > "9"))) return false;
	    }
	    // All characters are numbers.
	    return true;
	}
	
	function stripCharsInBag(s, bag){
		var i;
	    var returnString = "";
	    // Search through string's characters one by one.
	    // If character is not in bag, append to returnString.
	    for (i = 0; i < s.length; i++){   
		var c = s.charAt(i);
		if (bag.indexOf(c) == -1) returnString += c;
	    }
	    return returnString;
	}
	
	function daysInFebruary (year){
		// February has 29 days in any year evenly divisible by four,
	    // EXCEPT for centurial years which are not also divisible by 400.
	    return (((year % 4 == 0) && ( (!(year % 100 == 0)) || (year % 400 == 0))) ? 29 : 28 );
	}
	function DaysArray(n) {
		for (var i = 1; i <= n; i++) {
			this[i] = 31
			if (i==4 || i==6 || i==9 || i==11) {this[i] = 30}
			if (i==2) {this[i] = 29}
	   } 
	   return this
	}
	
	function isDate(dtStr){
		var daysInMonth = DaysArray(12)
		var pos1=dtStr.indexOf(dtCh)
		var pos2=dtStr.indexOf(dtCh,pos1+1)
		var strMonth=dtStr.substring(0,pos1)
		var strDay=dtStr.substring(pos1+1,pos2)
		var strYear=dtStr.substring(pos2+1)
		strYr=strYear
		if (strDay.charAt(0)=="0" && strDay.length>1) strDay=strDay.substring(1)
		if (strMonth.charAt(0)=="0" && strMonth.length>1) strMonth=strMonth.substring(1)
		for (var i = 1; i <= 3; i++) {
			if (strYr.charAt(0)=="0" && strYr.length>1) strYr=strYr.substring(1)
		}
		month=parseInt(strMonth)
		day=parseInt(strDay)
		year=parseInt(strYr)
		if (pos1==-1 || pos2==-1){
			alert("The date format should be : mm/dd/yyyy")
			return false
		}
		if (strMonth.length<1 || month<1 || month>12){
			alert("Please enter a valid month")
			return false
		}
		if (strDay.length<1 || day<1 || day>31 || (month==2 && day>daysInFebruary(year)) || day > daysInMonth[month]){
			alert("Please enter a valid day")
			return false
		}
		if (strYear.length != 4 || year==0 || year<minYear || year>maxYear){
			alert("Please enter a valid 4 digit year between "+minYear+" and "+maxYear)
			return false
		}
		if (dtStr.indexOf(dtCh,pos2+1)!=-1 || isInteger(stripCharsInBag(dtStr, dtCh))==false){
			alert("Please enter a valid date")
			return false
		}
	return true
	}
	
	</script>
<body onload="lock_submit();">
<?if ($status == 1) {  ?>
<h1 align="center">HMIS Repository Data Import Tools (FY15 Data)</h1>
<?} else if ($status == 2) {?>
<h1 align="center">HMIS Repository Data Import Tools (FY15 Data)</h1>
<?} ?>

<HR><BR><BR>

<div id="body" style="margin-left: auto; margin-right: auto; width: 755px;">
	<div id="leftcolumn" style="float: left; width: 200px; ">
		<div id="menu" style="width: 180px; border: thin solid; padding: 10px 10px 10px 10px;">

		<!--- <div id="skipmenu" style="position: absolute; left: -99999px"> <a href="#programs">skip to form</a> </div> --->
		<!--- style="display:none" --->
		<h2>User Options</h2>
			<UL>
			<LI><A HREF="/hmis/">Upload Data</A> <!---upload_v4.php--->
			<!--- <LI><A HREF="/hmis/">Upload CSV</A> --->
			<!--- <LI><A HREF="/hmis/aggregate_data.php">Upload XML</A> --->
			<LI><A HREF="/hmis/upload_squares.php">SQUARES </A>
			<LI><A HREF="../myaccount.php">My Account</A>
			<LI><A HREF="../activity_history.php">Activity History</A>
			<LI><A HREF="../support.php">Support</A>
			<LI><A HREF="../logout.php">Logout</A>
			</UL>
			
			<?if ($status == 1) {?>
			
			<?} else if ($status == 2) {?>
			
			<h2>Admin Options</h2>
			<UL>
			<!--- <LI><A HREF="../program_activity.php">Program Activity Report</A> --->
			<LI><A HREF="../manage_users.php">Manage Users</A>
			<LI><A HREF="../manage_programs.php?s=0">Manage Programs</A>
			<LI><A HREF="../admin_hmis_config.php">Manage Repository</A>
			<LI><A HREF="../edit_content.php">Edit Website Content</A>
			<LI><A HREF="../send_email.php">Send Email</A>
			<LI><A HREF="../logout.php">Logout</A>
			</UL>
			
			<?}?>
		
		</div>
	</div>
	
	
	<div id="rightcolumn" style="width: 500px; float: right;">
	
		<div id="message" style="width: 475px;">
		<?=$content_2?>
		</div>
		
		<BR><HR><BR>
		
		<div id="programs" style="width: 475px;">
			<h2>CSV Data Upload Form (V4.0)</h2>
			<form name="validate" enctype="multipart/form-data" action="file_uploader.php" method="POST" onSubmit="return check_form();">
			<!---<input type="hidden" name="MAX_FILE_SIZE" value="100000" />--->
			<table align="left" cellspacing="1" class="auto-style1" style="width: 100%; float: left">
				<tr>
					<td style="width: 175px"><label for="program_id">1. Program:</label></td>
					<td>
						<SELECT NAME="program_id" id="program_id" style="width:475px;">
							<OPTION VALUE="0">Select a Program</OPTION>
							<?echo $select_program?>
						</SELECT>
					</td>
				</tr>
				<input type="hidden" NAME="dataset_id" id="dataset_id" value='4'>
				<!---<tr>
					<td style="width: 175px">2. Dataset Type: </td>
					<td>
						<SELECT NAME="dataset_id" id="dataset_id">
							<OPTION VALUE="0">Select Dataset type</OPTION>
							<? //echo $select_dataset 
							?>
						</SELECT>
					</td>
				</tr>--->
				<!--- Increment 3
				<tr>
					<td style="width: 175px"><label for="export_date">2. Date of Export:</label></td>
					<td>
						<input type="text" name="export_date" size="10" tabindex="3" id="export_date"> 
						--->
						<!---<img border="0" src="images/calendarSm.gif" onclick="cal.select(document.forms.validate.export_date,'anchor1','MM/dd/yyyy'); return false;" name="anchor1" id="anchor1" alt="Open Calendar" tabindex="4">--->
				<!--- Increment 3		
						<input type="button" value="Calendar" onclick="cal.select(document.forms.validate.export_date,'anchor1','MM/dd/yyyy'); return false;" name="anchor1" id="anchor1" tabindex="4">
					</td>
				</tr>
				--->
				<tr>
					<td style="width: 175px"><label for="file">2. Zip file:</label></td>
					<td><input name="file" onchange="unlock_submit();" type="file" id="file"/> (zip file) </td>
				</tr>
				<tr>
					<td style="width: 175px">3. <fieldset><legend>Options:</legend></td>
						
					<td><input type="radio" name="option" id="validate_upload" value="validate_upload" checked="checked"> <label for="validate_upload">Validate and upload</label><br>
						<input type="radio" name="option" id="validate_only" value="validate_only"> <label for="validate_only">Validate Only</label> </td>
						<input type="hidden" name="format_version" value="4" /></fieldset>
				</tr>
				<tr>
					<td style="width: 175px"><input type="submit" id="btn_submit" name="btn_submit" value="  Submit  " /></td>
					<td></td>
				</tr>
			</table>

			</form>
		</div>
			
	</div>
	
	<div style="clear:both;"></div>

</div>
</body>


<?

print_footer();

} else {// end check login

	//echo $_SESSION['hmis_switch'];
	header("Location: /index.php");
	
}

?>