<?
include('../init.php');
	require_once('libs/functions.php');

if (checklogin($userID, 'menu.php')) {
	
	print_header('', 'skip_menu');
?>	
<?=print_ajax_squares_header()?>

	<script type="text/javascript">

	function check_form2() {
		//alert("reset");
		//document.getElementById("query_result").value="test"
		
		var errs=0;
			var msg = "";
			/*
			alert("test1");
			if (document.getElementById("hmis_id").value==""){
				msg += "Please enter a Local HMIS Client ID.\n";
				document.getElementById("hidError").innerHTML="Please enter a Local HMIS Client ID.";
			}
			else{
				document.getElementById("hidError").innerHTML="";
			}
			*/
			
			if ((document.getElementById("fname").value=="") || (!isValidName(document.getElementById("fname").value))){
				msg += "Please enter a first name (letters only).\n";
				document.getElementById("fnameError").innerHTML="Please enter a first name (letters only).";
			}
			else{
				document.getElementById("fnameError").innerHTML="";
			}

			if ((document.getElementById("lname").value=="")  || (!isValidName(document.getElementById("lname").value))){
				msg += "Please enter a last name (letters only).\n";
				document.getElementById("lnameError").innerHTML="Please enter a last name (letters only).";
			}
			else{
				document.getElementById("lnameError").innerHTML="";
			}

			if ((document.getElementById("ssn").value=="") || (!isValidSSNFormat(document.getElementById("ssn").value))){
				msg += "Please enter a valid social security number. (#########)\n";
				document.getElementById("ssnError").innerHTML="Please enter a valid social security number. (#########)";
			}
			else{
				document.getElementById("ssnError").innerHTML="";
			}
			
			/*
			if (document.getElementById("gender").value==""){
				msg += "Please enter a gender.\n";
				document.getElementById("genderError").innerHTML="Please enter a gender.";
			}	
			else{
				document.getElementById("genderError").innerHTML="";
			}
			*/

			/* 
			if ((document.getElementById("zip").value=="") || (!isValidUSZip(document.getElementById("zip").value))){
				msg += "Please enter a valid ZIP code.\n";
				document.getElementById("ZIPError").innerHTML="Please enter a valid 5-digit ZIP code.";
			}
			else{
				document.getElementById("ZIPError").innerHTML="";
			}
			*/

			/*
			if ((document.getElementById("dob").value=="")  || (!isValidName(document.getElementById("dob").value))){
				msg += "Please enter a Date of Birth (MM/DD/YYYY).\n";
				document.getElementById("dobError").innerHTML="Please enter a Date of Birth (MM/DD/YYYY).\n";
			}
			else{
				document.getElementById("dobError").innerHTML="";
			}
			*/
			
			if (!isValidDOB(document.getElementById("dob").value)){
				msg +="Please enter a valid date of birth. (YYYY-MM-DD)\n";
				document.getElementById("dobError").innerHTML="Please enter a valid date of birth. (YYYY-MM-DD)";
      			}
      			else{

					document.getElementById("dobError").innerHTML="";
				
			}
			
      			if (msg != ""){
      				return false;
      			}
      			else{
      				enter_squares_data()
      				return true;
      			}
      			alert("test4");
      			
		return true;
	}
	
		function reset_form() {
			alert("reset");
			
			document.getElementById("hmis_id").value=="";
			document.getElementById("hidError").innerHTML="";
			
			document.getElementById("fname").value=="";
			document.getElementById("fnameError").innerHTML="";

			document.getElementById("mname").value=="";
			document.getElementById("mnameError").innerHTML="";

			document.getElementById("lname").value=="";
			document.getElementById("lnameError").innerHTML="";

			document.getElementById("ssn").value=="";
			document.getElementById("ssnError").innerHTML="";

			document.getElementById("gender").value=="";
			document.getElementById("genderError").innerHTML="";
					
			document.getElementById("zip").value=="";
			document.getElementById("ZIPError").innerHTML="";

			document.getElementById("dob").value=="";
			document.getElementById("dobError").innerHTML="";

		}
		
		function lock_submit(){
		document.getElementById("btn_submit").disabled=true;
	}

	function unlock_submit(){
		var file_name = document.getElementById("file").value;
		//alert(file_name);
	}
	
	function isValidSSNFormat(s) {
  		 return /^\d{3}\d{2}\d{4}$/.test(s);
  		 //return /^\d{3}-\d{2}-\d{4}$/.test(s);
	}	

	function isValidUSZip(sZip) {
  		 return /^\d{5}$/.test(sZip);
	}	

	function isValidName(sName) {
		
  		 return /^[a-zA-Z]+$/.test(sName);
	}	

	function isValidDOB(sDate){
		//return /^([0-9]{2})\/([0-9]{2})\/([0-9]{4})$/.test(sDate);

		//return /^([0]?[1-9]|[1|2][0-9]|[3][0|1])[./-]([0]?[1-9]|[1][0-2])[./-]([0-9]{4}|[0-9]{2})$/.test(sDate);
		//return /^(0[1-9]|1[0-2])\/(0[1-9]|1\d|2\d|3[01])\/(19|20)\d{2}$/.test(sDate);	//MM/DD/YYYY
		return /^(19|20)\d{2}-(0[1-9]|1[0-2])-(0[1-9]|1\d|2\d|3[0-1])$/.test(sDate);	//YYYY-MM-DD 1935-12-16
		//return /^(19|20)\d{2}$/.test(sDate);	//YYYY-MM-DD 1935-12-16
	}

	function isValidDOBRange(sDate){
		var dob=sDate.replace(/-/g, '');
		var day=Number(dob.substr(0,2));	
		var month=Number(dob.substr(2,2));
		//alert(month);
		var year=Number(dob.substr(4,8));
		var today=new Date();
		var age=today.getFullYear()-year;
		//if(today.getMonth()<month || (today.getMonth()==month && today.getDate()<day)){age--;}
		//alert(age);
		    if ((today.getMonth()) < (month - 1)){
		    	age--;
		    }
		    if (((month - 1) == today.getMonth()) && (today.getDay() < day)){
		    	age--;
		    }

		if ((age < 18) || (age > 119)){
			//alert ("wrong");
			return false;
		}
		else{
			return true;
		}
	}

	</script>
	
	<SCRIPT LANGUAGE="JavaScript" SRC="CalendarPopup.js"></SCRIPT>

	<script language = "Javascript">
	var cal = new CalendarPopup();
	// Declaring valid date character, minimum year and maximum year
	var dtCh= "/";
	var minYear=1900;
	var maxYear=2100;
	
	function isInteger(s){
		var i;
	    for (i = 0; i < s.length; i++){   
		// Check that current character is number.
		var c = s.charAt(i);
		if (((c < "0") || (c > "9"))) return false;
	    }
	    // All characters are numbers.
	    return true;
	}
	
	function stripCharsInBag(s, bag){
		var i;
	    var returnString = "";
	    // Search through string's characters one by one.
	    // If character is not in bag, append to returnString.
	    for (i = 0; i < s.length; i++){   
		var c = s.charAt(i);
		if (bag.indexOf(c) == -1) returnString += c;
	    }
	    return returnString;
	}
	
	function daysInFebruary (year){
		// February has 29 days in any year evenly divisible by four,
	    // EXCEPT for centurial years which are not also divisible by 400.
	    return (((year % 4 == 0) && ( (!(year % 100 == 0)) || (year % 400 == 0))) ? 29 : 28 );
	}
	function DaysArray(n) {
		for (var i = 1; i <= n; i++) {
			this[i] = 31
			if (i==4 || i==6 || i==9 || i==11) {this[i] = 30}
			if (i==2) {this[i] = 29}
	   } 
	   return this
	}
	


	function isDate(dtStr){
		var daysInMonth = DaysArray(12)
		var pos1=dtStr.indexOf(dtCh)
		var pos2=dtStr.indexOf(dtCh,pos1+1)
		var strMonth=dtStr.substring(0,pos1)
		var strDay=dtStr.substring(pos1+1,pos2)
		var strYear=dtStr.substring(pos2+1)
		strYr=strYear
		if (strDay.charAt(0)=="0" && strDay.length>1) strDay=strDay.substring(1)
		if (strMonth.charAt(0)=="0" && strMonth.length>1) strMonth=strMonth.substring(1)
		for (var i = 1; i <= 3; i++) {
			if (strYr.charAt(0)=="0" && strYr.length>1) strYr=strYr.substring(1)
		}
		month=parseInt(strMonth)
		day=parseInt(strDay)
		year=parseInt(strYr)
		if (pos1==-1 || pos2==-1){
			//alert("The date format should be : dd/mm/yyyy")
			return false
		}
		if (strMonth.length<1 || month<1 || month>12){
			//alert("Please enter a valid month")
			return false
		}
		if (strDay.length<1 || day<1 || day>31 || (month==2 && day>daysInFebruary(year)) || day > daysInMonth[month]){
			//alert("Please enter a valid day")
			return false
		}
		if (strYear.length != 4 || year==0 || year<minYear || year>maxYear){
			//alert("Please enter a valid 4 digit year between "+minYear+" and "+maxYear)
			return false
		}
		if (dtStr.indexOf(dtCh,pos2+1)!=-1 || isInteger(stripCharsInBag(dtStr, dtCh))==false){
			//alert("Please enter a valid date")
			return false
		}
	return true
	}
	
	</script>
	<!---<body onload="lock_submit();">--->
<body> 

<? if ($status == 1) { ?>
<h1 align="center">Veteran Status Query and Response Exchange System (SQUARES)</h1>
<?} else if ($status == 2) {?>
<h1 align="center">Veteran Status Query and Response Exchange System (SQUARES)</h1>
<?}?>

<HR><BR><BR>

<div id="body" style="margin-left: auto; margin-right: auto; width: 755px;">
	<div id="leftcolumn" style="float: left; width: 200px; ">
		<div id="menu" style="width: 180px; border: thin solid; padding: 10px 10px 10px 10px;">

		<!--- <div id="skipmenu" style="position: absolute; left: -99999px"> <a href="#programs">skip to form</a> </div> --->
		<!--- style="display:none" --->
		
		<h2>User Options</h2>
			<UL>
			<? if ("1" <> $squares_user && 'off' != $_SESSION['hmis_switch']){ ?>
				<LI><A HREF="/hmis/">Upload Data</A> 
			<? }?>
			
			<LI><A HREF="/hmis/upload_squares.php">SQUARES </A>
			<LI><A HREF="../myaccount.php">My Account</A>
			<? if ("1" <> $squares_user){ ?>
				<LI><A HREF="../activity_history.php">Activity History</A>
			<? }?>
			<LI><A HREF="../support.php">Support</A>
			<LI><A HREF="../logout.php">Logout</A>
			</UL>
			
			<?if ($status == 1) {?>
			
			<?} else if ($status == 2) {?>
			
			<h2>Admin Options</h2>
			<UL>
			
			<LI><A HREF="../manage_users.php">Manage Users</A>
			<LI><A HREF="../manage_programs.php?s=0">Manage Programs</A>
			<LI><A HREF="../admin_hmis_config.php">Manage Repository</A>
			<LI><A HREF="../edit_content.php">Edit Website Content</A>
			<LI><A HREF="../send_email.php">Send Email</A>
			<LI><A HREF="../logout.php">Logout</A>
			</UL>
			
			<?}?>
		
		</div>
	</div>
	
	<div id="rightcolumn" style="width: 500px; float: right;">
		
		<div id="programs" style="width: 475px;">
			
			
			<form name="validate" id="validate" action='' method="POST"> <!--- onSubmit="return check_form();"> --->
				<table width=550>
					<tr class="va-section-header" width="550">
					<td colspan=5>Veteran Status Lookup Query</td>
					</tr>
					<tr>
					<td width="500" colspan="5">
					    Please complete the following fields to register for a Repository account.
					<br>
					Note: A (*) denotes a required field.
					    <br><br>
					<tr>
					<td width="40%"><label for="hmis_id">Local HMIS Client ID: </label></td>
					<td><input type="text" id="hmis_id" name="hmis_id" size="26" maxlength="15"></td>
					<TD width="45%"  style="font-size:8pt;color:red;"  id="hidError" name="hidError"></TD>
					</tr>

					<tr>
					<td width="40%"><label for="fname">* First Name: </label></td>
					<td><input type="text" id="fname" name="fname" size="26" maxlength="20"></td>
					<TD  style="font-size:8pt;color:red;"   id="fnameError" name="fnameError"></TD>
					</tr>

					<tr>
					<td width="40%"><label for="mname">Middle Name: </label></td>
					<td ><input type="text" id="mname" name="mname" size="26" maxlength="20"></td>
					<TD  style="font-size:8pt;color:red;"    id="mnameError" name="mnameError"></TD>
					</tr>

					<tr>
					<td width="40%"><label for="lname">* Last Name: </label></td>
					<td><input type="text" id="lname" name="lname" size="26" maxlength="26"></td>
					<TD  style="font-size:8pt;color:red;"  id="lnameError" name="lnameError"></TD>
					</tr>

					<tr>
					<td width="40%"><label for="ssn">* Social Security Number: </label></td>
					<td><input type="text" id="ssn" name="ssn" size="26" maxlength="11"></td>
					<TD style="font-size:8pt;color:red;"    id="ssnError" name="ssnError"></TD>
					</tr>
					
					<tr>
					<td width="30%"><label for="dob">* Date of Birth (yyyy-mm-dd): </label></td>
					<td><input type="text" id="dob" name="dob" size="26" maxlength="10">
					<!--<input type="button" value="Calendar" onclick="cal.select(document.forms.validate.dob,'anchor1','MM/dd/yyyy'); return false;" name="anchor1" id="anchor1" tabindex="3"></td>-->

					<TD  style="font-size:8pt;color:red;"   id="dobError" name="dobError"></TD>
					</tr>
					
					<tr>
					<td width="40%"><label for="gender">Gender: </label></td>
					<td>
						<input type="text" id="gender" name="gender" size="1" maxlength="1"></td>
						<!---
						<SELECT NAME="gender" id="gender" tabindex="7" style="width:475px;">
							<OPTION VALUE="0">Select a Gender</OPTION>
							<OPTION VALUE="M">Male</OPTION>
							<OPTION VALUE="F">Female</OPTION>
							<OPTION VALUE="U">U</OPTION>
						</SELECT>
						--->

					<TD  style="font-size:8pt;color:red;"    id="genderError" name="genderError"></TD>
					</tr>

					<tr>
					<td width="40%"><label for="zip">Zip Code of last permanent address: </label></td>
					<td><input type="text" id="zip" name="zip" size="5" maxlength="5"></td>
					<TD  style="font-size:8pt;color:red;"    id="ZIPError" name="ZIPError"></TD>
					</tr>

					<TR>
					<TD colspan=3 align=left>
						<HR>
						<input name='process_data' type='button' value='Submit Query' onclick='return check_form2();' />
						
						<!---<INPUT TYPE=SUBMIT VALUE="Submit Query" id="btnSubmit" name="btnSubmit" onSubmit='enter_squares_data()' >---> 
						<INPUT TYPE=RESET VALUE=Cancel onclick="reset_form();">
						
						<span id='proc_msg'></span><br><br>
						<span id='file_result'></span>
						
						<HR>
					</TD>
					</TR>


					<tr align=center>
					<HR>
					<td colspan = 3 align = 'left'>
					
					<b>Search Result Options:</b><br><br>
					<b>Yes:</b> A matching Veteran record was found in a VA Identity Repository<br><br>
					<b>No:</b> No matching Veteran record was found in a VA Identity Repository<br><br>
					<b>Inconclusive:</b> A matching Veteran record was found in other sources but
					cannot be verified as a Veteran within the VA<br><br>
					
					* For more information on the match process, please see the HMIS Repository / SQUARES User Guide.
					<!---<b>Match Process Explanation:</b>
					The Veteran status request will be sent VADIR via a secure SOAP synchronous transfer to various VA Identity databases where the data will be extracted and verified against all VA client records. 
					<br><br>The data is first sent to <b>DEERS (Defense Enrollment Eligibility Reporting System)</b> to query for matching records. 
					<br><br>If no match is found in DEERS, the data is sent to both the <b>Beneficiary Identification Records Locator Subsystem (BIRLS)</b>. 
					<br><br>If no match is found in BIRLS, the data is sent to the <b>National Center for Veterans Analysis and Statistics (NCVAS)</b>. 
					<br><br>If a matching Veteran record is found in either the <b>VA Department of Defense Identity Repository (VADIR)</b> or 
					Beneficiary Identification Records Locator Subsystem (BIRLS), the system will return <b>'Yes'</b>. 
					If No matching Veteran record found in VADIR, BIRLS or NCVAS, the system will return <b>'No'</b>. 
					If a matching record is only found in NCVAS, the system will display <b>'Inconclusive'</b>.
					--->
					</td>
					<!---
						<td width="40%">Potential Veteran Status</td>
						<td width="400"><input type="text" id="query_result" name="query_result" size="30" maxlength="20" readonly></td>
						--->
					</tr>

				</table>

			</form>
		</div>
			
	</div>
	
	<div style="clear:both;"></div>

</div>
</body>


<?

print_footer();

} // end check login

?>