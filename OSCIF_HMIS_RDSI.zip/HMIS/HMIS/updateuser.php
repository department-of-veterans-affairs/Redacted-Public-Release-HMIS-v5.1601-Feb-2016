<?php

include('init.php');
include('hmis/libs/functions.php');

$e_token = trim(scrub_white_list($_POST['e_token'], 'ALPHANUMERICONLY'));
$s_e_token = $_SESSION['e_token'];
if ((ISSET($e_token)) && ($e_token===$s_e_token)){

		if (checklogin($userID, "menu.php")) {

		$fname = scrub_sql(scrub_white_list(trim($_POST['fname']),'ALPHAONLY'), 20);
		$lname = scrub_sql(scrub_white_list(trim($_POST['lname']),'ALPHAONLY'), 30);
		$email = scrub_sql(scrub_white_list(trim($_POST['email']),'USER'), 150);
		$phone = scrub_sql(scrub_white_list(trim($_POST['phone']),'USER'), 20);
		$organization = scrub_sql(scrub_white_list(trim($_POST['organization']),'USER'), 70);


		$password = trim($_POST['password']);

		$errors=0;

		if ($fname == "" || $lname == "" || $email == "" || $phone == "") {
		$errors = 1;
		$message = "Incomplete Form. Please fill out all required fields.";
		}

		else if (strlen($fname) < 1 || strlen($lname) < 1 || strlen($email) < 4 || strlen($phone) < 10 || strlen($fname) > 20 || strlen($lname) > 30 || strlen($email) > 120 || strlen($phone) > 20) {
		$errors = 1;
		$message = "One or more fields are incorrect length.";
		}


		else if (check_bad_char($email)) {
		$errors = 1;
		$message = "Email contains invalid characters.";
		}

		else if ($password <> "" && strlen($password) > 7 && strlen($password) < 21 && check_password($password)) {
			$password = hash('sha256', "just4uAlanna".$password);	//md5("just4uAlanna".$password);
			$currentpassword = $_POST['currentpassword'];
			$currentpasswordenc = hash('sha256', "just4uAlanna".$currentpassword);	//md5("just4uAlanna".$currentpassword);
			$sql = "SELECT count(user_id) AS cnt FROM tb_user WHERE user_id=$userID AND password='$currentpasswordenc'";
			$rs = $db->Execute($sql);
			$cnt = $rs->fields('cnt');
			if ($cnt != 1) {
				$errors = 1;
				$message = "Incorrect current password";
			}
			else {
				$PWDQ = ", password='$password'";
				$sql = "UPDATE tb_password_update SET last_password_change=getdate() WHERE user_id=$userID";
				$rs = $db->Execute($sql);


				$message = 'User updated password through My Account page';
				audit_log($userID, $message, 57);
			}
		}

		// check if email exists
		if ($errors == 0) {
		$sql = "SELECT count(email) AS cnt FROM tb_user WHERE email='$email' AND email<>(SELECT email FROM tb_user WHERE user_id=$userID)";
		$rs = $db->Execute($sql);
		$cnt = $rs->fields('cnt');
		if ($cnt > 0) {
		$errors = 1;
		$message = "Email address already exists.";
		}
		}

		if ($errors == 0) {
		$sql = "UPDATE tb_user SET fname='$fname', lname='$lname', email='$email', phone='$phone', organization='$organization'$PWDQ WHERE user_id=$userID";
		$rs = $db->Execute($sql);

		//$sql = "INSERT INTO tb_audit (user_id, event, event_date) VALUES ($userID, 'User updated profile', getdate())";
		//$rs = $db->Execute($sql);

		$message = 'User updated profile';
		audit_log($userID, $message, 55);


		print_header();

		$sqlUTE = "select username from tb_user where user_id=$userID";
		$rs = $db->Execute($sqlUTE);
		$UTEdisp = $rs->fields('username');

		print ("

		<table width=800 align=center>
		<tr><td>
		<BR>
		<HR>
		<H1 align=center>Thank You!</H1>
		<BR>
		<HR>
		<H3 align=center>The user account <i>$UTEdisp</i> has been updated. <A HREF=menu.php>Click here to continue</A></H3>
		<BR>
		<HR>
		</td></tr></table>
		");
		print_footer();
		} // end if no errors


		// display error message
		else {
		print_header();
		print "<br><hr><h1 align=center>$message</h1><hr><h3 align=center>Please press the Back button to return to previous page</h3>";
		print_footer();
		}


	} // end check login
}
else{ //etoken check: false
	$message = "Error: Invalid session!";
	print_header();
		print "<br><hr><h1 align=center>$message</h1><hr><h3 align=center>Please press the Back button to return to previous page.</h3>";
		print_footer();

}

?>