<?
include('init.php');
include('hmis/libs/functions.php');

print_header();

if (checklogin($userID, "menu.php") && ($status == 1 || $status == 2)) {
	$eid=trim(scrub_white_list($_GET['e'], 'NUMBERONLY'));

	if ((ISSET($eid)) AND ($eid <> '') AND is_numeric($eid)){
		$sql = "select hur.error_id, hur.error_msg, hur.user_id, hur.error_date, tu.user_id, tu.username, tu.status, tu.fname, tu.lname from HMIS_Upload_Reports hur, tb_user tu where tu.user_id = hur.user_id and error_id=$eid";
		$rs = $db->Execute($sql);

		if ($rs->EOF){
			print ("
				<H1 align=center>Validation Report</H1>
				<center><a href='' onclick='window.close()'>Close this window</a></center>
			");
		}
		else{

			while (!$rs->EOF){
				$eid = $rs->fields('error_id');
				$e_msg = $rs->fields('error_msg');
				$e_date = $rs->fields('error_date');
				$e_date = date("n/j/y g:i:s A", strtotime($e_date));
				
				$uName = $rs->fields('username');
	 			$uStatus = $rs->fields('status');
				$uFname = $rs->fields('fname');
				$uLname = $rs->fields('lname');
	
				$rs->MoveNext();
			}
?>

			<H1 align=center>Validation Report</H1>
			<center><a href="" onclick="window.close()">Close this window</a></center>
			<HR>
<?
			print("<table id='metaerror_info' width=755 align='center'>");
	
			print("<tr><td><b>Uploader: </b>");
			if (uStatus<>2){
				print("$uLname, $uFname (<i>$uName</i>)");
			}
			if (uStatus==2){
				print("Repository Admin");
			}
			print ("</td></tr>");
	
			print("<tr><td><b>Validation ID: </b>$eid</td></tr>");
			print("<tr><td><b>Validation date: </b>$e_date</td></tr>");
			print("</table>");

?>
<br>
			<? echo htmlspecialchars_decode($e_msg); ?>
			<br>
	
<?
		}
	}
	else
	{
		print ("<h1 align=center>Error! No validation report was found.</h1>
			<center><a href='' onclick='window.close()'>Close this window</a></center>	
		");
	}

}// end check login

print_footer();
?>
