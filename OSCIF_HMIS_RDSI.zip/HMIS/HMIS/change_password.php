<?php
include('init.php');
include('hmis/libs/functions.php');


if (checklogin($userID, "menu.php")) {

print_header();

?>




<script>
function check_form() {
var errs=0;

if (document.forms.registration.password.value != document.forms.registration.password2.value) {alert('Passwords do not match'); errs=1;}
else if (document.forms.registration.currentpassword.value == '') {alert('Please enter your current password'); errs=1;}
else if (!validPswrd(document.forms.registration.password)) {errs=1};


return (errs==0);
}

function validPswrd(eSrc){

if(eSrc.value.length < 8) 
     {
        alert("Password must contain at least eight characters. NOTE Passwords must be greater than eight characters, contain a number and upper and lower case letters.");
        eSrc.focus();
        return false;
     }

if(eSrc.value.length > 20) 
     {
        alert("Password must cannot be longer than 20 characters. NOTE Passwords must be greater than eight characters, contain a number and upper and lower case letters.");
        eSrc.focus();
        return false;
     }

     re = /[0-9]/;
     if(!re.test(eSrc.value)) 
     {
        alert("Password must contain at least one number (0-9). NOTE Passwords must be greater than eight characters, contain a number and upper and lower case letters.");
        eSrc.focus();
        return false;
     }
     re = /[a-z]/;
     if(!re.test(eSrc.value)) 
     {
        alert("Password must contain at least one lowercase letter (a-z). NOTE Passwords must be greater than eight characters, contain a number and upper and lower case letters.");
        eSrc.focus();
        return false;
     }
     re = /[A-Z]/;
     if(!re.test(eSrc.value)) 
     {
        alert("Password must contain at least one uppercase letter (A-Z).  NOTE Passwords must be greater than eight characters, contain a number and upper and lower case letters.");
        eSrc.focus();
        return false;
     }

	// Create regular expression for password and login id
	var re = new RegExp("[^A-Za-z0-9 ]","i");


	
	
	

return true;

}


</script>


   

<script type="text/javascript" src="password.js"></script>
<style>
#passwordStrength { height:10px; display:block; float:left; } .strength0 { width:250px; background:#cccccc; } .strength1 { width:50px; background:#ff0000; } .strength2 { width:100px; background:#ff5f5f; } .strength3 { width:150px; background:#56e500; } .strength4 { background:#4dcd00; width:200px; } .strength5 { background:#399800; width:250px; }
</style>


<form name="registration" action="updatepassword.php" method="post" onSubmit="return check_form();">





<h1 align="center">Your Password has expired!<!-- END: PAGE TITLE --></h1>
 

<HR>


<br><br>

<table width="755" align="center">
</td></tr>
<tr class="va-section-header" >
<td colspan=2 width="755">Change Password</td>
</tr>

<tr>
<td width="500">
    
    Use the fields below to update your account password. Please enter your current password first, and then enter your new password two times to make sure it is correct.
    <br />    <br />
    <TABLE>
        

<TR><TD><label for="currentpassword">Current Password</label></TD>
<TD><input type="password" name="currentpassword" id="currentpassword" size="20" >

</TD><TD>

                           </TD>
</TR>



        <TR><TD><label for="password">New Password</label></TD>
<TD><input type="password" name="password" id="password" size="20" value="" onkeyup="passwordStrength(this.value)">

</TD><TD>

                           </TD>
</TR>

<TR><TD></TD>
<TD><div id="passwordDescription">Password not entered</div> <div id="passwordStrength" class="strength0"></div><br /></TD></TR>

<TR><TD><label for="password2">Confirm Password</label></TD>
<TD><input type="password" name="password2" id="password2" size="20" value="">
</TD><TD>
                           </TD>
</TR>




</TABLE>
<br>
Note: Passwords must be between 8 and 20 characters in length and contain both uppercase and lowercase letters, and at least one number.
    <br />

<br />
</td></tr

<TR><TD colspan=3 align=center>
<HR>
<INPUT TYPE=SUBMIT VALUE="Update Password"> <INPUT TYPE=RESET VALUE=Cancel onClick="document.location='menu.php';">
<HR>
</TD></TR>


</TABLE>
<INPUT TYPE=hidden id="e_token" name="e_token" VALUE="<?php echo $_SESSION['e_token']; ?>">

</form>

</td>





</td>
</tr>
</tbody>
</table>


			
<?php

print_footer();

} // end check login

?>
