<?php
include('init.php');
include('hmis/libs/functions.php');

 
	$user = scrub_sql(scrub_white_list(trim($_GET['user']),'DATA'), 16);

	if ($user=="")
		echo "";
	else
		$sql = "SELECT count(username) AS cnt FROM tb_user WHERE username='" . $user. "'";
		$rs = $db->Execute($sql);
		$cnt = $rs->fields('cnt');

	echo $cnt;
?>