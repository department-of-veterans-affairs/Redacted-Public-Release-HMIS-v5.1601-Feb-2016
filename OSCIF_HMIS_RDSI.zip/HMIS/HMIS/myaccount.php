<?php
include('init.php');
include('hmis/libs/functions.php');


if (checklogin($userID, "menu.php")) {


$sql = "SELECT fname, lname, email, phone, organization FROM tb_user WHERE user_id=$userID";
$rs = $db->Execute($sql);
$fname = $rs->fields('fname');
$lname = $rs->fields('lname');
$email = $rs->fields('email');
$phone = $rs->fields('phone');
$organization = $rs->fields('organization');

print_header();

?>




<script>
function check_form() {
var errs=0;

if (document.forms.registration.fname.value == '') {alert('Please enter your first name'); errs=1;}
else if (document.forms.registration.lname.value == 0) {alert('Please enter your last name'); errs=1;}
else if (checkMail()) {alert('Please enter a valid email address'); errs=1;}

else if (document.forms.registration.password.value != '') {
if (document.forms.registration.password.value != document.forms.registration.password2.value) {alert('Passwords do not match'); errs=1;}
else if (document.forms.registration.currentpassword.value == '') {alert('Please enter your current password'); errs=1;}
else if (!validPswrd(document.forms.registration.password)) {errs=1};
}

return (errs==0);
}

function checkMail()
{
	var x = document.forms.registration.email.value;
	var filter  = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	if (filter.test(x)) return false;
	else return true;
}

function validPswrd(eSrc){

if(eSrc.value.length < 8) 
     {
        alert("Password must contain at least eight characters. NOTE Passwords must be greater than eight characters, contain a number and upper and lower case letters.");
        eSrc.focus();
        return false;
     }

if(eSrc.value.length > 20) 
     {
        alert("Password must cannot be longer than 20 characters. NOTE Passwords must be greater than eight characters, contain a number and upper and lower case letters.");
        eSrc.focus();
        return false;
     }

     re = /[0-9]/;
     if(!re.test(eSrc.value)) 
     {
        alert("Password must contain at least one number (0-9). NOTE Passwords must be greater than eight characters, contain a number and upper and lower case letters.");
        eSrc.focus();
        return false;
     }
     re = /[a-z]/;
     if(!re.test(eSrc.value)) 
     {
        alert("Password must contain at least one lowercase letter (a-z). NOTE Passwords must be greater than eight characters, contain a number and upper and lower case letters.");
        eSrc.focus();
        return false;
     }
     re = /[A-Z]/;
     if(!re.test(eSrc.value)) 
     {
        alert("Password must contain at least one uppercase letter (A-Z).  NOTE Passwords must be greater than eight characters, contain a number and upper and lower case letters.");
        eSrc.focus();
        return false;
     }

	// Create regular expression for password and login id
	var re = new RegExp("[^A-Za-z0-9 ]","i");


	
	
	

return true;

}


</script>


   

<script type="text/javascript" src="password.js"></script>
<style>
#passwordStrength { height:10px; display:block; float:left; } .strength0 { width:250px; background:#cccccc; } .strength1 { width:50px; background:#ff0000; } .strength2 { width:100px; background:#ff5f5f; } .strength3 { width:150px; background:#56e500; } .strength4 { background:#4dcd00; width:200px; } .strength5 { background:#399800; width:250px; }
</style>


<form name="registration" action="updateuser.php" method="post" onSubmit="return check_form();">





<h1 align="center">My Account<!-- END: PAGE TITLE --></h1>
    

<CENTER><A HREF="menu.php">Home</A></CENTER>

<HR>


<br><br>

<table width=755 align="center">
<tr class="va-section-header" width="550">
<td colspan=2>Account Information</td>
</tr>
<tr>
<td width="500" colspan="2">
    Edit the fields below to update your account information.
<br>
Note: All fields are required.
    <br><br>
<tr>
<td width="200"><label for="fname">First Name</label></td>
<td width="400"><input type="text" name="fname" size="20" maxlength="20" VALUE="<?echo $fname;?>" id="fname"></td>
</tr>
<tr>
<td width="200"><label for="lname">Last Name</label></td>
<td width="400"><input type="text" name="lname" size="20" maxlength="20" VALUE="<?echo $lname;?>" id="lname"></td>
</tr>
<tr>
<td width="200"><label for="email">Email</label></td>
<td width="400"><input type="text" name="email" size="40" maxlength="120" VALUE="<?echo $email;?>" id="email"></td>
</tr>
<tr>
<td width="200"><label for="phone">Phone</label></td>
<td width="400"><input type="text" name="phone" size="20" maxlength="20" VALUE="<?echo $phone;?>" id="phone"></td>
</tr>
<tr>
<td width="200"><label for="organization">Organization</label></td>
<td width="400"><input type="text" name="organization" size="20" maxlength="60" VALUE="<?echo $organization;?>" id="organization"></td>
</tr>
<tr>
</table>

<br /><br />

<table width="755" align="center">
</td></tr>
<tr class="va-section-header" >
<td colspan=2 width="755">Change Password</td>
</tr>

<tr>
<td width="500">
    
    Use the fields below to update your account password. Please enter your current password first, and then enter your new password two times to make sure it is correct.
    <br />    <br />
    <TABLE>
        

<TR><TD><label for="currentpassword">Current Password</label></TD>
<TD><input type="password" name="currentpassword" size="20" id="currentpassword" >

</TD><TD>

                           </TD>
</TR>



        <TR><TD><label for="password">New Password</label></TD>
<TD><input type="password" name="password" size="20" value="" onkeyup="passwordStrength(this.value)" id="password">

</TD><TD>

                           </TD>
</TR>

<TR><TD></TD>
<TD><div id="password not entered">Password not entered</div> <div id="passwordStrength" class="strength0"></div><br /></TD></TR>

<TR><TD><label for="password2">Confirm Password</label></TD>
<TD><input type="password" name="password2" size="20" value="" id="password2">
</TD><TD>
                           </TD>
</TR>




</TABLE>
<br>
Note: Passwords must be between 8 and 20 characters in length and contain both uppercase and lowercase letters, and at least one number.
    <br />

<br />
</td></tr

<TR><TD colspan=3 align=center>
<HR>
<INPUT TYPE=SUBMIT VALUE="Update Account" > <INPUT TYPE=RESET VALUE=Cancel onClick="document.location='menu.php';">
<HR>
</TD></TR>


</TABLE>


<BR>
<h1 align=center>Login History</h1>

<br>
<table width="500" align="center" border=1>
<th>Login Date (EST)</th>
<?
$sysdate = date("Y-m-d");
$sqlLG = "select user_id, event_type, event_date from tb_audit where (user_id=$userID) AND (event_type in (54, 7)) AND (event_date > ($sysdate - 30)) order by event_date desc";
$rsLG = $db->Execute($sqlLG);

//echo "<br>" . $sqlLG;

if ($rsLG->EOF){
	print("
		<tr>
		<td align=center><b>NO RECORD FOUND</td>
		</tr>
	");
}

else{
while (!$rsLG->EOF)
  { 
	$login = $rsLG->fields('event_date');
	$login = date("n/j/y g:i:s A", strtotime($login) );
	print ("
		<tr>
		<td align=center>$login</td>
		</tr>
	");

$rsLG->MoveNext();
  }
}
?>


</table>
<INPUT TYPE=hidden id="e_token" name="e_token" VALUE="<?php echo $_SESSION['e_token']; ?>">
</form>

</td>








			
<?php

print_footer();

} // end check login

?>
