<?php

include('init.php');
include('hmis/libs/functions.php');


if (checklogin($userID, "index.php")) {

print_header();

/*
$sql = "SELECT squares_user from tb_user where user_id=$$userID";
$rs = $db->Execute($sql);
while (!$rs->EOF)
  { 
$squares_user = $rs->fields('squares_user');
$rs->MoveNext();
  }
*/

?>

<?if ($status == 1) {?>
<h1 align="center">HMIS Repository / SQUARES Account Menu</h1>
<?} else if ($status == 2) {?>
<h1 align="center">HMIS Repository / SQUARES Admin Menu</h1>
<?}?>

<HR>
<BR><BR>

<div id="body" style="margin-left: auto; margin-right: auto; width: 755px;">


<div id="leftcolumn" style="float: left; width: 200px; ">

<div id="menu" style="width: 180px; border: thin solid; padding: 10px 10px 10px 10px;">



<?if (($status == 1) || ($status == 2)) { ?>
<h2>User Options</h2>
<UL>
<? if ("1" <> $squares_user && 'off' != $_SESSION['hmis_switch']){ ?>
	<LI><A HREF="/hmis/">Upload Data</A>
<? }?>
 <!---upload_v4.php--->
<!--- <LI><A HREF="/hmis/">Upload CSV</A> --->
<!--- <LI><A HREF="/hmis/aggregate_data.php">Upload XML</A> --->
<LI><A HREF="/hmis/upload_squares.php">SQUARES </A>
<LI><A HREF="myaccount.php">My Account</A>
<? if ("1" <> $squares_user){ ?>
	<LI><A HREF="activity_history.php">Activity History</A>
<? }?>	
<LI><A HREF="support.php">Support</A>
</UL>
<?} 

if ($status == 2) {?>

<h2>Admin Options</h2>
<UL>

<!--- <LI><A HREF="program_activity.php">Program Activity Report</A> --->
<LI><A HREF="manage_users.php">Manage Users</A>
<LI><A HREF="manage_programs.php?s=0">Manage Programs</A>
<LI><A HREF="admin_hmis_config.php">Manage Repository</A>
<LI><A HREF="edit_content.php">Edit Website Content</A>
<LI><A HREF="send_email.php">Send Email</A>
</UL>
<?} else if($status == 4) {?>

<h2>HRC Options</h2>
<UL>
<LI><A HREF="myaccount.php">My Account</A>
<LI><A HREF="hrc_manage_users.php?s=1">Manage Users</A>
<LI><A HREF="support.php">Support</A>
</UL>
<?}?>
<UL>
<LI><A HREF="logout.php">Logout</A>
</UL>



</div>

</div>

<div id="rightcolumn" style="width: 500px; float: right;">

<div id="message" style="width: 475px;">
<?
$sql = "SELECT html FROM tb_content WHERE page_id=2";
$rs = $db->Execute($sql);
$record_count = $rs->RecordCount();
if ($record_count == 1) {
$html = scrub_white_list($rs->fields('html'), 'HTMLNOSCRIPT');
echo $html;
}

?>
</div>

<BR>
<HR>
<BR>

<?	if ("1" <> $squares_user){ ?>
<div id="programs" style="width: 475px;">
<h2>Grant/Programs:</h2>
<ul>
<?

$sql = "select p.program_name from tb_user_programs u, tb_ssvf_program p WHERE u.user_id=$userID AND p.program_id=u.program_id";
$rs = $db->Execute($sql);

while (!$rs->EOF)
  { 

$program = $rs->fields('program_name');
print "<li>$program</li>";
$rs->MoveNext();
  }

?>
</ul>
</div>
<? }?>

 <br>
 <br>

<div id="user_CoC" style="width: 475px;">
<h2>CoC:</h2>
<ul>
<?

$sql = "select c.name, c.hudNum from tb_user_coc uc, tb_CoC c WHERE uc.user_id=$userID AND uc.coc_id=c.coc_id";
$rs = $db->Execute($sql);

while (!$rs->EOF)
  { 

$user_coc = $rs->fields('name');
$user_cocNum = $rs->fields('hudNum');;
print "<li>$user_coc ($user_cocNum)</li>";
$rs->MoveNext();
  }

?>
</ul>
</div>


</div>

<div style="clear:both;"></div>

</div>



<?

print_footer();

} // end check login

?>
