<?php

include('init.php');
include('hmis/libs/functions.php');

//$e_token = $_POST['e_token'];
$s_e_token = $_SESSION['e_token'];

if ((!ISSET($s_e_token)) OR (""==$s_e_token) or (is_null($s_e_token))){
	//code to generate random session token
	$charset='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
	$str = '';
	$count = strlen($charset);
	$length=8;
	while ($length--) {
	        $str .= $charset[mt_rand(0, $count-1)];
			

	}
	//echo strtoupper($str);
	$_SESSION['e_token'] = strtoupper($str);
	//echo $_SESSION['e_token'];
	//end code to generate random session token
}

if (isset($_POST['email'])) {
$email = scrub_sql(scrub_white_list($_POST['email'], 'USER'), 150);
$sql = "SELECT user_id, username FROM tb_user WHERE email='$email';";
$rs = $db->Execute($sql);
$record_count = $rs->RecordCount();
if ($record_count == 1) {
$user_id = $rs->fields('user_id');
$user = $rs->fields('user');
}

}

print_header();

?>



<script>
function stopRKey(evt) { 
  var evt = (evt) ? evt : ((event) ? event : null); 
  var node = (evt.target) ? evt.target : ((evt.srcElement) ? evt.srcElement : null); 
  if ((evt.keyCode == 13) && (node.type=="text"))  {return false;} 
} 

document.onkeypress = stopRKey; 

function pullAjax(){
        	var a;
	        try{
	          a=new XMLHttpRequest()
	        }
	        catch(b)
	        {
	          try
	          {
	            a=new ActiveXObject("Msxml2.XMLHTTP")
	          }catch(b)
	          {
	            try
	            {
	              a=new ActiveXObject("Microsoft.XMLHTTP")
	            }
	            catch(b)
	            {
	              alert("Browser error.");return false
	            }
	          }
	        }
	        return a;
	      }

function check_form() {
	var msg = "";

	if (!document.getElementById('uorp1').checked && !document.getElementById('uorp2').checked) {
		msg += "- Please select either username or password.\n";
		//errs=1;
	}

	//-----------------------------email validation---------------------
	var x = document.getElementById("email").value;
	var filter = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;
	if (!filter.test(x)){ 
		msg += "- Please enter a valid email address.\n";
	}
	
	if (!document.getElementById("email").value == ""){
		//email_check(document.forms.registration.email.value);
	}
	
	//-------------------------------------begin email exist check---------------------------------
	//	obj=pullAjax();
	//	 
	       //var x = document.getElementById("email").value;
	//	if (x != ""){
	//        obj.onreadystatechange=function()
	//        {
	//          if(obj.readyState==4)
	//          {
	           // returns email exists
	//            var tmp=obj.responseText;
	//		if (tmp == 0){
	//			//document.getElementById("btnSubmit").disabled = true; 
	//			//document.getElementById("emailError").innerHTML = "<b><font color='red'>Email address does not exist.</font></b>"
	//			msg += "- Email address does not match any existing information in the system. Please try again.\n";
	//			//alert("false");
	//			//return false;
	//		}
	//		else{
	//			document.getElementById("btnSubmit").disabled = false;
	//			document.getElementById("emailError").innerHTML = "";
				//alert("true");
				//return true;
	//		}
	//        }
	//    };
	//	var email_URL = "check_email.php?email=" + x + "&nocache=" + new Date().getTime();
	//       obj.open("GET",email_URL,true);
	//       obj.send(null);
	//	}
	//-------------------------------------end email exist check---------------------------------


	//----------------------------end email-----------------------------
	if (msg != ""){
		alert (msg);
		return false;
	}
}


</script>



<div id="login" style="border: thin solid; margin-left: auto; margin-right: auto; width: 500px; padding: 25px 25px 25px">


<TABLE cellpadding="3" cellspacing="1" border="0">
<tr>
<td>
<H1 align="CENTER">Lookup Username or Password</H1>
</td>
</tr>
<tr>
<td>
<HR>
<p>
<center>
Please supply the information below to retrieve your lost/forgotten HMIS Repository username or password. The system will send an email containing your username or a temporary password.</p>
</center>
<HR>
</td>
</tr>
<tr>
<td>
<form name="forgot" action="retrieve_login.php" method="post" onSubmit="return check_form();">

<TABLE>
<TR>
<TD align="center"><input type="radio" name="uorp" id="uorp1" value="1" > <label for="uorp1">I forgot my username</label>
&nbsp;&nbsp;&nbsp;<input type="radio" name="uorp" id="uorp2" value="2" > <label for="uorp2">I forgot my password</label></td>
</tr>
<tr>
<td>
<BR>

<div id="formdisplay">
<TABLE>
<!---<tr>
<td width="200">First Name</td>
<td width="400"><input type="text" name="fname" size="20" maxlength="20"></td>
</tr>
<tr>
<td width="200">Last Name</td>
<td width="400"><input type="text" name="lname" size="20" maxlength="20"></td>
</tr>--->

<tr>
<td width="200"><label for="email">Email address</label>:</td>
<td width="400"><input type="text" id="email" name="email" size="40" maxlength="120"></td>
</tr>

<tr align="center">
<TD colspan="2" width="200" id="emailError" name="emailError"></TD>
</tr>

</TABLE>
<BR>
<CENTER>
<INPUT TYPE="submit" name="btnSubmit" id="btnSubmit"  VALUE="Retrieve Login"> <INPUT TYPE="Button" VALUE="Cancel" onClick="window.location='/';">

</CENTER>
</div>

</td>
</tr>
</TABLE>
<INPUT TYPE=hidden id="e_token" name="e_token" VALUE="<?php echo $_SESSION['e_token']; ?>">
</form>

</td>
</tr>
</TABLE>





</div>








<?php

print_footer();


?>