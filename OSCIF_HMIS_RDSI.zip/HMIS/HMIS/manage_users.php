<?php
include('init.php');
include('hmis/libs/functions.php');

if (checklogin($userID, "menu.php") && $status == 2) {


if (isset($_REQUEST['s'])) {
$s = scrub_white_list($_REQUEST['s'], 'NUMBERONLY');
}
else {$s = 9;}

if (isset($_REQUEST['p'])) {
$p = scrub_white_list($_REQUEST['p'], 'NUMBERONLY');
}
else {$p = 1;}


if (isset($_REQUEST['search'])) {
$search = scrub_white_list($_REQUEST['search'], 'USER');
}
else {$search="";}


$_SESSION['return_page']= $_SERVER['REQUEST_URI'];

print_header();

?>

<style type="text/css">
#manage {
	width:755px;
	border-width: 1px;
	border-spacing: ;
	border-style: outset;
	border-color: gray;
	border-collapse: separate;
	background-color: white;
}
#manage th {
	border-width: 1px;
	padding: 1px;
	border-style: inset;
	border-color: gray;
	background-color: white;
	-moz-border-radius: ;
}
#manage td {
	border-width: 1px;
	padding: 1px;
	border-style: inset;
	border-color: gray;
	background-color: white;
	-moz-border-radius: ;
}
</style>



<H1 align=center>Manage Users</H1>
<?if (($s==9) || ($s==10)){ ?>
<h3 align=center>All Pending / Unconfirmed HMIS Users</h3>
<? } ?>

<? if ($s==1){ ?>
<h3 align=center>All Approved HMIS Users</h3>
<? } ?>


<? if ($s==6){ ?>
<h3 align=center>All Suspended HMIS Users</h3>
<? } ?>

<? if ($s==2){ ?>
<h3 align=center>All HMIS Administrators</h3>
<? } ?>

<CENTER><A HREF="menu.php">Repository Home</A> <!--- | <A HREF="program_activity.php">Program Activity Report</A> ---></CENTER>
<HR>


<TABLE ALIGN="CENTER" WIDTH="755" border="2">

<!--<TR><TD valign="top" align="left">HMIS Users: -->
<tr>
<th width="200px" colspan="1">HMIS Users</th>
<th width="200px" colspan="1">Administrators</th>
<!--<th width="200px" colspan="1">HRC Users</th>-->
</tr>

<tr align="center">
<td>
<?if (($s!=9) && ($s!=10)) {?>
<A HREF=manage_users.php?s=9>Pending</a> |
<? } 
if (($s==9) || ($s==10)) { ?>

<b>Pending</b> | 
<? } ?>

<?if ($s != 1) {?>
<A HREF=manage_users.php?s=1>Approved</a> | 
<? } 
if ($s == 1) { ?>

<b>Approved</b> | 
<? } ?>

<?if ($s != 6) {?>
<A HREF=manage_users.php?s=6>Suspended</a>
<? } 
if ($s == 6) { ?>

<b>Suspended</b>
<? } ?>

</td>

<td>
<?if ($s != 2) {?>
<A HREF=manage_users.php?s=2>Show</a>
<? } 
if ($s == 2) { ?>

<b>Show</b>
<? } ?></td>

</tr>
</table>
<br>

<TABLE ALIGN="CENTER" WIDTH="755" border=0>

<TR>
<TD valign="top" align="center"><FORM ACTION=manage_users.php METHOD=GET><b><label for='search'>User Search</label>: </b>
<INPUT TYPE=TEXT NAME='search' id='search' VALUE="<?echo $search;?>" >
<INPUT TYPE=SUBMIT VALUE="Search" ><INPUT TYPE="HIDDEN" NAME="s" VALUE="<?echo $s;?>"></FORM></TD>

</TR>
</TABLE>


<br>
<TABLE ALIGN="CENTER" NAME="manage" id="manage" WIDTH="755">
<TR>
<TH>Username</TH><? if ($s != 2){ ?><TH>SQUARES<br>Only?</TH><?}?>.<TH>User Information</TH><TH>Last Login (EST)</th><TH>Actions</TH>
</TR>


<?
$results = 0;
$start = 1+($p-1)*40;
$finish = $start+39;
$sql = "list_users $s, $start, $finish, '$search'";
$rs = $db->Execute($sql);

//echo $sql;
while (!$rs->EOF)
  { 

$user_id = $rs->fields('user_id');
$user = $rs->fields('username');
$fname = $rs->fields('fname');
$lname = $rs->fields('lname');
$email = $rs->fields('email');
$uStatus = $rs ->fields('status');
$sq_only = $rs ->fields('squares_user');

$sqlLG = "select TOP 1 event_date from tb_audit where (user_id=$user_id) AND (event_type in (54,7)) order by event_date desc";
$rsLG = $db->Execute($sqlLG);

if (!$rsLG->EOF){
	$login = $rsLG->fields('event_date');
	$login = date("n/j/y g:i:s A", strtotime($login) );
}
else{
	$login = 'N/A';
}



if ("1"==$sq_only){
	$sq_only_str = "Y";
}
else{
	$sq_only_str = "N";
}


if ($s==9) {

$action = "<FORM ACTION='approve.php' id='approve_$user_id' METHOD='POST'><INPUT TYPE='HIDDEN' NAME='u' VALUE='$user_id'><INPUT TYPE='HIDDEN' NAME='e_token' id='e_token' VALUE='" . $_SESSION['e_token'] . "'></FORM><a href='#' onClick='if (confirm(\"Are you sure you want to approve this user?\")) {document.getElementById(\"approve_$user_id\").submit();}'>Approve</A>";
$action = $action . " | <FORM ACTION='suspend.php' id='suspend_$user_id' METHOD='POST'><INPUT TYPE='HIDDEN' NAME='u' VALUE='$user_id'><INPUT TYPE='HIDDEN' NAME='e_token' id='e_token' VALUE='" . $_SESSION['e_token'] . "'></FORM><a href='#' onClick='if (confirm(\"Are you sure you want to suspend this account?\")) {document.getElementById(\"suspend_$user_id\").submit();}'>Suspend</A>";
$action = $action . " | <a href=edit_user.php?uid=$user_id>Edit</a>";

}
else if ($s==1) {
$action = "<a href=edit_user.php?uid=$user_id>Edit</a> | <FORM ACTION='suspend.php' id='suspend_$user_id' METHOD='POST'><INPUT TYPE='HIDDEN' NAME='u' VALUE='$user_id'><INPUT TYPE='HIDDEN' NAME='e_token' id='e_token' VALUE='" . $_SESSION['e_token'] . "'></FORM><a href='#' onClick='if (confirm(\"Are you sure you want to suspend this account?\")) {document.getElementById(\"suspend_$user_id\").submit();}'>Suspend</A>";
}
else if ($s==2) {
$action = "<a href=edit_user.php?uid=$user_id>Edit</a> | <FORM ACTION='suspend.php' id='suspend_$user_id' METHOD='POST'><INPUT TYPE='HIDDEN' NAME='u' VALUE='$user_id'><INPUT TYPE='HIDDEN' NAME='e_token' id='e_token' VALUE='" . $_SESSION['e_token'] . "'></FORM><a href='#' onClick='if (confirm(\"Are you sure you want to suspend this account?\")) {document.getElementById(\"suspend_$user_id\").submit();}'>Suspend</A>";
}
else if ($s==4) {
$action = "<a href=edit_user.php?uid=$user_id>Edit</a> | <FORM ACTION='suspend.php' id='suspend_$user_id' METHOD='POST'><INPUT TYPE='HIDDEN' NAME='u' VALUE='$user_id'><INPUT TYPE='HIDDEN' NAME='e_token' id='e_token' VALUE='" . $_SESSION['e_token'] . "'></FORM><a href='#' onClick='if (confirm(\"Are you sure you want to suspend this account?\")) {document.getElementById(\"suspend_$user_id\").submit();}'>Suspend</A>";
}

else if ($s==6) {
$action = "<FORM ACTION='unsuspend.php' id='unsuspend_$user_id' METHOD='POST'><INPUT TYPE='HIDDEN' NAME='u' VALUE='$user_id'><INPUT TYPE='HIDDEN' NAME='e_token' id='e_token' VALUE='" . $_SESSION['e_token'] . "'></FORM><a href='#' onClick='if (confirm(\"Are you sure you want to unsuspend this account?\")) {document.getElementById(\"unsuspend_$user_id\").submit();}'>Unsuspend</A>";
}

if ($s ==2){
		print ("
			<tr><td><A HREF=\"edit_user.php?uid=$user_id\">$user</A></td>
			<td>$fname $lname<BR><A HREF=\"mailto:$email\">$email</A></td><td>$login</TD>
			<td>$action</td></tr>
		");
}
else{
	if ($uStatus==0){
		print ("
			<tr><td>(*) <A HREF=\"edit_user.php?uid=$user_id\">$user</A></td><td align=center>$sq_only_str</td>
			<td>$fname $lname<BR><A HREF=\"mailto:$email\">$email</A></td><td>$login</TD>
			<td>$action</td></tr>
		");
	}

	else{
		print ("
			<tr><td><A HREF=\"edit_user.php?uid=$user_id\">$user</A></td><td align=center>$sq_only_str</td>
			<td>$fname $lname<BR><A HREF=\"mailto:$email\">$email</A></td><td>$login</TD>
			<td>$action</td></tr>
		");
	}
}
$results = $results + 1;    
$rs->MoveNext();
  }


if ($s==9){
print ("
	<tr border=0>
	<td colspan='5' align='center'><font size=1><b>NOTE:</b> <i>(*)</i> denotes a user with an unconfirmed email address.</font></td>
	</tr>
");
}
?>
</TABLE>
<?

print "<center>";
if ($p > 1) {
$lastp=$p-1;
print "<a href=manage_users.php?s=$s&p=$lastp><< Previous Page</a> ";
}


if ($results == 40) {
$nextp=$p+1;
print "<a href=manage_users.php?s=$s&p=$nextp> Next Page >></a>";
}
print "</center>";


print_footer();

} // end check login

?>
