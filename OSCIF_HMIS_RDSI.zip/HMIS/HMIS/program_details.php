<?php
include('init.php');
include('hmis/libs/functions.php');


if (checklogin($userID, "menu.php") && $status == 2) {
	print_header();

	$_SESSION['return_page']= $_SERVER['REQUEST_URI'];

	if (isset($_REQUEST['p'])) { 
		$pid = scrub_sql(scrub_white_list($_REQUEST['p'], 'NUMBERONLY'), 8);
	}

	if (isset($_SESSION['return_page'])) {
		$url = $_SESSION['return_page'];
	}
	else {
		$url = "manage_users.php";
	}

	$sql = "SELECT * FROM tb_SSVF_program sp, tb_SSVF_grant sg WHERE sp.program_id=$pid AND sg.grant_id=sp.grant_id";
	$rs = $db->Execute($sql);
	
	$pname = $rs->fields("program_name");
	$gname = $rs->fields("grant_name");
?>

<script>

function enable_clear() {
	var msg = "";
	var numSel = 0;
	var chks = document.getElementsByName('remove_from_prog[]');

	for (var i = 0; i < chks.length; i++){
		if (chks[i].checked){
			numSel = numSel + 1;
		}
	}

	if ("0" == numSel){
		document.getElementById("clearSels").disabled=true;
	}
	
	if (numSel > 0){
		document.getElementById("clearSels").disabled=false;
	}

}
function check_form() {
	var msg = "";
	var numSel = 0;
	var chks = document.getElementsByName('remove_from_prog[]');
	
	for (var i = 0; i < chks.length; i++){
		if (chks[i].checked){
			numSel = numSel + 1;
		}
	}
	if ("0" == numSel){
		msg += ("Please select at least one (1) user to disassociate from this program.");
	}	

	if (numSel > 0){
		var rfp=confirm('Are you sure you wish to disassociate these users from this program?');
	}

	if (msg != ""){
		alert(msg);
		return false;
	}
		
}



function reset_form() {
	var msg = "";
	var numSel = 0;
	var chks = document.getElementsByName('remove_from_prog[]');

	for (var i = 0; i < chks.length; i++){
			if (chks[i].checked){
				numSel = numSel + 1;
			}
	}

	if (numSel < 1){
		msg += ("Error: There are no checkboxes to reset.");
		alert(msg);
		return false;
	}

	else
	{
		var rfp=confirm('Are you sure you wish to reset all user selections?');
	
		if (rfp==true){
			for (var i = 0; i < chks.length; i++){
				chks[i].checked = false;
			}
		enable_clear();
		}
	}
}
</script>

<body onload="return enable_clear();">
<form name="progdetails" action="remove_program_users.php?p=<?echo $pid?>" method="post" onSubmit="return check_form();">
<input type="hidden" name="uid" value="<?echo $uid;?>">

<h1 align="center">Program Details<!-- END: PAGE TITLE --></h1></b>
<CENTER><A HREF="manage_programs.php?s=0">Return to Manage Programs</A></CENTER>
<hr>
<br>
<center>
<h2 align="center"><?echo $pname;?></h2>
<i><?echo $gname;?></i>
<br><br>

<font size=1><i>To remove a user's access to this program: Click the checkbox next to the desired user(s), and click the 'Update Program' button.</i></font>
</center>

<TABLE ALIGN="CENTER" NAME="pd_approved" id="pd_approved" WIDTH="755" border=1>
<tr class="va-section-header" width="550">
<td colspan=3 align=center>Approved Users</td>
</tr>

<?
$sql = "SELECT u.user_id, username, fname, lname, status from tb_user u, tb_user_programs up where u.status in (1,7) AND u.user_id=up.user_id AND up.program_id=$pid order by lname asc";
$rs = $db->Execute($sql);

	if ($rs->EOF)
	{
		print("
			<tr>
			<td colspan='3' align='center'><B>NO USERS FOUND</b></td>
			</tr>
		");
	}

	else
	{
		print ("<TH></TH><th align='center'>Name</th><th align='center'>Last Login</th>");
		while (!$rs->EOF)
		  { 
			
			$user_id = $rs->fields('user_id');
			$user = $rs->fields('username');
			$fname = $rs->fields('fname');
			$lname = $rs->fields('lname');
			$status = $rs->fields('status');
			
		$sqlLG = "select TOP 1 event_date from tb_audit where (user_id=$user_id) AND (event_type in (54,7)) order by event_date desc";
		$rsLG = $db->Execute($sqlLG);

		if (!$rsLG->EOF){
			$login = $rsLG->fields('event_date');
			$login = date("n/j/y g:i:s A", strtotime($login) );
		}
		else{
			$login = 'N/A';
		}

				print ("
					<tr>
					<td align='center'><input type='checkbox' name='remove_from_prog[]' id='rfp_".$user_id."' value=\"$user_id\" onchange='enable_clear();'></td>
					<td>$lname, $fname (<font size=1><A HREF=\"edit_user.php?uid=$user_id\">$user</A></font>)

					
				");
				
				if ($status==7){
					print ("<font size=1<i>(password expired)</i>");
				}
				
				print("</td>");
				print ("<td align='center'>$login</td> ");

		$rs->MoveNext();
		  }
	}

?>


</table>

<br>
<!--
<TABLE ALIGN="CENTER" NAME="pd_pending" id="pd_pending" WIDTH="755" border=1>
<tr class="va-section-header" width="550">
<td colspan=3 align=center>Pending Users</td>
</tr>


<?
/*
$sql = "SELECT u.user_id, username, fname, lname, status from tb_user u, tb_user_programs up where (u.status=9 OR u.status=0) AND u.user_id=up.user_id AND up.program_id=$pid order by lname asc";
$rs = $db->Execute($sql);

	if ($rs->EOF)
	{
		print("
			<tr>
			<td colspan='3' align='center'><B>NO USERS FOUND</b></td>
			</tr>
		");
	}

	else
	{
		print ("<TH></TH><th align='center'>Name</th><th align='center'>Last Login</th>");
		while (!$rs->EOF)
		  { 
			$user_id = $rs->fields('user_id');
			$user = $rs->fields('username');
			$fname = $rs->fields('fname');
			$lname = $rs->fields('lname');

		$sqlLG = "select TOP 1 event_date from tb_audit where (user_id=$user_id) AND (event_type in (54,7)) order by event_date desc";
		$rsLG = $db->Execute($sqlLG);

		if (!$rsLG->EOF){
			$login = $rsLG->fields('event_date');
			$login = date("n/j/y g:i:s A", strtotime($login) );
		}
		else{
			$login = 'N/A';
		}
		

				print ("
					<tr>
					<td align='center'><input type='checkbox' name='remove_from_prog[]' id='rfp_".$user_id."' value=\"$user_id\" onchange='enable_clear();'></td>
					<td>$lname, $fname (<font size=1><A HREF=\"edit_user.php?uid=$user_id\">$user</A></font>)</td>
					<td align='center'>$login</td>
					
				");

		$rs->MoveNext();
		  }
	}
	*/
?>


</table>
-->

<br>
<!--
<TABLE ALIGN="CENTER" NAME="pd_susp" id="pd_susp" WIDTH="755" border=1>
<tr class="va-section-header" width="550">
<td colspan=3 align=center>Suspended Users</td>
</tr>
-->
<?/*

$sql = "SELECT u.user_id, username, fname, lname, status from tb_user u, tb_user_programs up where u.status=6 AND u.user_id=up.user_id AND up.program_id=$pid order by lname asc";
$rs = $db->Execute($sql);
	if ($rs->EOF)
	{
		print("
			<tr>
			<td colspan='3' align='center'><B>NO USERS FOUND</b></td>
			</tr>
		");
	}

	else
	{
		print ("<TH></TH><th align='center'>Name</th><th align='center'>Last Login</th>");
		while (!$rs->EOF)
		  { 
			$user_id = $rs->fields('user_id');
			$user = $rs->fields('username');
			$fname = $rs->fields('fname');
			$lname = $rs->fields('lname');


		$sqlLG = "select TOP 1 event_date from tb_audit where (user_id=$user_id) AND (event_type in (54,7)) order by event_date desc";
		$rsLG = $db->Execute($sqlLG);

		if (!$rsLG->EOF){
			$login = $rsLG->fields('event_date');
			$login = date("n/j/y g:i:s A", strtotime($login) );
		}
		else{
			$login = 'N/A';
		}


				print ("
					<tr>
					<td align='center'><input type='checkbox' name='remove_from_prog[]' id='rfp_".$user_id."' value=\"$user_id\" onchange='enable_clear();'></td>
					<td>$lname, $fname (<font size=1><A HREF=\"edit_user.php?uid=$user_id\">$user</A></font>)</td>
					<td align='center'>$login</td>
					
				");

		$rs->MoveNext();
		  }

		
	}
	*/
?>


<!--</table>-->

<br>
<br>
<table WIDTH="755" align=center>
<TR><TD colspan=3 align=center>
<HR>
<INPUT TYPE=SUBMIT VALUE="Update Program"> <INPUT TYPE=button id="clearSels" name="clearSels" onclick="return reset_form();" VALUE="Clear All"> <br><br><INPUT TYPE=RESET VALUE=Cancel onClick="document.location='manage_programs.php?s=0';">
<HR>
</TD></TR>
</table>
<INPUT TYPE=hidden id="e_token" name="e_token" VALUE="<?php echo $_SESSION['e_token']; ?>">

<!-- <INPUT TYPE=button onclick="return check_form();" VALUE="Test Checkboxes">-->

</form>
</body>			
<?php

print_footer();

} // end check uid
?>