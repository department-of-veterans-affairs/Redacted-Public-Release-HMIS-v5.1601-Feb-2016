function Poll()
{
	var triggerCall = '<scr' + 'ipt type="text/javascript" src="/va_files/foresee/foresee-trigger.js"></scr' + 'ipt>';
	document.write(triggerCall);
}