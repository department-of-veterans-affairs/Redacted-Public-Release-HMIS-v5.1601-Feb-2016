var surveyTemp = null;
