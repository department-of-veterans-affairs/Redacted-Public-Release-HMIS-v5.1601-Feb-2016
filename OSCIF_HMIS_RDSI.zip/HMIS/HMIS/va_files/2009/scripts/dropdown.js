// Global JavaScripts
$(document).ready(function(){

//JQuery IFRAME Plugin
$('.menu').bgiframe(); 
//End IFRAM Plugin

var currentNav;

    $("#banner-area-menu ul > li").hover(
      function () {
        $(this).addClass("over");
      }, 
      function () {
        $(this).removeClass("over");
      }
    );
	
	$("#banner-area-menu ul li > a").focus(function () {
        $(this).parent("li").trigger("focus");
    });
	
	$("#banner-area-menu li").focus(function () {
		$(currentNav).trigger("blur");
        $(this).addClass("over");
		currentNav = this;
    });
	
	$("#banner-area-menu li").blur(function () {
        $(this).removeClass("over");
    });
	
	$("#banner-area-menu li .menu").each(function () {
		$(this).find("a:last").blur(function () {
			$(this).parent("li").parents("li").removeClass("over");
		});
	});

	$("#banner-area-menu ul li > a").click(function () {
		$(this).trigger("blur");
	});

		
});

function createMenu(){
	
	document.write(
		'<ul>'+ '\n'
           +'<li>' + '\n'	
               +'<a href="http://www.domain/">Home</a>' + '\n'
           +'</li>' + '\n'
		
        +'<li>' + '\n'
        	+'<a href="http://www.domain/landing2_vetsrv.htm">Veteran Services</a>' + '\n'
            	+'<div class="menu twoColumn">' + '\n'
                +'<div class="sub_nav">' + '\n'
                    +'<h4>Inside Veteran Services</h4>' +'\n'
                    +'<ul>' + '\n'
                    +'<li><a href="http://www.domain/opa/newtova.asp">New to VA</a></li>' + '\n'
					+'<li><a href="http://www.domain/opa/publications/benefits_book.asp">Benefits Booklet</a></li>' + '\n'
                    +'</ul>' + '\n'
                    +'<h4>Benefits & Services</h4>' + '\n'
                    +'<ul>' + '\n'
                    	+'<li><a href="http://www.vba.domain/VBA/">General Benefits Information</a></li>' + '\n'
                        +'<li><a href="http://www.vba.domain/bln/21/compensation/">Disability Compensation</a></li>' + '\n'
                        +'<li><a href="http://www.vba.domain/bln/21/pension/">Pension</a></li>' + '\n'
                        +'<li><a href="http://www.gibill.domain/">GI Bill</a></li>' + '\n'
                        +'<li><a href="http://www.vba.domain/bln/vre/">Vocational Rehabilitation &amp; Employment</a></li>' + '\n'
                        +'<li><a href="http://vetsuccess.gov/">Vet Success</a></li>' + '\n'
                        +'<li><a href="http://www.gibill.domain/benefits/other_programs/dea.html">Dependents\' Educational Assistance</a></li>' + '\n'
                        +'<li><a href="http://www.vba.domain/survivors/">Survivor Benefits</a></li>' + '\n'
                        +'<li><a href="http://www.benefits.domain/homeloans/">Home Loans</a></li>' + '\n'
                        +'<li><a href="http://www.insurance.domain/miscellaneous/">Life Insurance</a></li>' + '\n'
                        +'<li><a href="http://www.insurance.domain/sgliSite/TSGLI/TSGLI.htm">Traumatic Injury Insurance</a></li>' + '\n'
                    +'</ul>' + '\n'
                 +'</div>' + '\n'
              	 +'<div class="sub_nav">' + '\n'
                 	+'<h4>Health &amp; Well-Being</h4>' + '\n'
                    +'<ul>' + '\n'
                	+'<li><a href="http://www.domain/health/">Health Care Information</a></li>' + '\n'
					+'<li><a href="http://www.domain/health/topics/">A-Z Health Topic Finder</a></li>' + '\n'
                    +'<li><a href="http://www.myhealth.domain/">My Health<span style="text-decoration:underline; font-style:italic">e<\/span>Vet</a></li>' + '\n'
                    +'<li><a href="https://www.myhealth.domain/mhv-portal-web/anonymous.portal?_nfpb=true&_pageLabel=rxRefillHome">Refill Prescriptions</a></li>' + '\n'
					+'<li><a href="http://www.domain/ext_redirect.asp?url=http://www.veteranscrisisline.net">Crisis Prevention</a></li>' + '\n'
					+'<li><a href="http://www.mentalhealth.domain/">Mental Health</a></li>' + '\n'
                    +'<li><a href="http://www.ptsd.domain/">PTSD</a></li>' + '\n'
                    +'<li><a href="http://www.publichealth.domain/">Public Health</a></li>' + '\n'
                   	+'</ul>' + '\n'
                    +'<h4>Burials &amp; Memorials</h4>' + '\n'
                    +'<ul>' + '\n'
                    +'<li><a href="http://www.cem.domain/">Cemetery Services</a></li>' + '\n'
                    +'<li><a href="http://www.cem.domain/bbene_burial.asp">Burials</a></li>' + '\n'
                    +'<li><a href="http://www.cem.domain/hm_hm.asp">Headstones &amp; Markers</a></li>' + '\n'
                    +'<li><a href="http://www.cem.domain/pmc.asp">Presidential Memorial Certificates</a></li>' + '\n'
                    +'<li><a href="http://www.cem.domain/cems/listcem.asp">Cemeteries</a></li>' + '\n'
                    +'<li><a href="http://gravelocator.cem.domain/">Nationwide Gravesite Locator</a></li>' + '\n'
                    +'<li><a href="http://www.cem.domain/bbene/bflags.asp">Burial Flags</a></li>' + '\n'
                    +'<li><a href="http://www.cem.domain/bbene/benvba.asp">Burial Allowance</a></li>' + '\n'
                    +'</ul>' + '\n'
                +'</div>' + '\n'
                 	+'<div class="clear"></div>' + '\n'
          +'</div>' + '\n'
          +'</li>' + '\n'
             
              +'<li>' + '\n'
            	+'<a href="http://www.domain/landing2_business.htm">Business</a>' + '\n'
                +'<div class="menu">' + '\n'
                +'<div class="sub_nav">' + '\n'
                +'<h4>Inside Business</h4>' + '\n'
                	+'<ul>' + '\n'
                	+'<li><a href="http://www.domain/osdbu/">Small Business Opportunities</a></li>' + '\n'
                    +'<li><a href="http://www.domain/osdbu/veteran/">Starting a Business</a></li>' + '\n'
					+'<li><a href="http://www.vetbiz.gov/">VetBiz.gov</a></li>' + '\n'
				+'</ul>' + '\n'
                +'<h4>Doing Business with VA</h4>' + '\n'
                	+'<ul>' + '\n'
                    +'<li><a href="http://www.domain/oamm/oa/dbwva/">Acquisitions</a></li>' + '\n'
                    +'<li><a href="http://www.cfm.domain/">Construction</a></li>' + '\n'
                    +'<li><a href="http://www.volunteer.domain/">Volunteer</a></li>' + '\n'
                    +'</ul>' + '\n'
                +'</div> ' + '\n'
                	+'<div class="clear"></div>' + '\n'
                +'</div>' + '\n'
          +'</li>' + '\n'
				
                +'<li>' + '\n'
                	+'<a href="http://www.domain/landing2_about.htm" >About VA</a>' + '\n'
					+'<div class="menu twoColumn">' + '\n'
                +'<div class="sub_nav">' + '\n'
                	+'<h4>Inside the VA</h4>' + '\n'
                	+'<ul>' + '\n'
                    +'<li><a href="http://www.domain/opa/bios/secretary.asp">Secretary of VA</a></li>' + '\n'
                    +'<li><a href="http://www.domain/opa/bios/">Executive Biographies</a></li>' + '\n'
                    +'<li><a href="http://www.domain/landing_organizations.htm">Organizations</a></li>' + '\n'
                    +'<li><a href="http://www.domain/about_va/vahistory.asp">History</a></li>' + '\n'
                    +'<li><a href="http://www.domain/vetdata/">Data and Statistics</a></li>' + '\n'
                    +'<li><a href="http://www.domain/jobs/">Jobs</a></li>' + '\n'
                    +'<li><a href="http://www.domain/cfbnpartnerships/">Faith-based &amp; Neighborhood Partnerships</a></li>' + '\n'
                    +'<li><a href="http://www.domain/kids/">VA for Kids</a></li>' + '\n'
                 +'</ul>' + '\n'
                 	+'<h4>Congressional Affairs</h4>' + '\n'
                    +'<ul>' + '\n'
                    +'<li><a href="http://www.domain/oca/Vet_Legis.asp">Legislation</a></li>' + '\n'
                    +'<li><a href="http://www.domain/oca/testimony.asp">Testimony</a></li>' + '\n'
                    +'</ul>' + '\n'
                 +'</div>' + '\n'
				+'<div class="sub_nav">' + '\n'
                	+'<h4>Budget and Performance</h4>' + '\n'
                	+'<ul>' + '\n'
                	+'<li><a href="http://www.domain/performance/">VA Plans, Budget, and Performance</a></li>' + '\n'
                    +'<li><a href="http://www.domain/vai2/">VA Innovation Initiative (VAi2)</a></li>' + '\n'
                    +'<li><a href="http://www.domain/budget/report/">Performance and Accountability Report</a></li>' + '\n'
                    +'<li><a href="http://www.domain/budget/products.htm">Budget Submission</a></li>' + '\n'
                    +'<li><a href="http://www.domain/recovery/">Recovery Act</a></li>' + '\n'
                    +'</ul>' + '\n'
                    +'<h4>Partners</h4>' + '\n'
                    +'<ul>' + '\n'
                    +'<li><a href="http://www.domain/statedva.htm">State Veterans Affairs Offices</a></li>' + '\n'
                    +'<li><a href="http://www.domain/vso/">Veterans Service Organizations</a></li>' + '\n'
                    +'</ul>' + '\n'
                 +'</div>' + '\n'
                 	+'<div class="clear"></div>' + '\n'
               +'</div>' + '\n'
				+'</li>' + '\n'
	           
              
			
            +'<li>' + '\n'
            	+'<a href="http://www.domain/landing2_media_room.htm">Media Room</a>' + '\n'
                +'<div class="menu twoColumn">' + '\n'
                +'<div class="sub_nav">' + '\n'
                	+'<h4>Inside the Media Room</h4>' + '\n'
                	+'<ul>' + '\n'
					+'<li><a href="http://www.domain/opa/pressrel/">News Releases</a></li>' + '\n'
                	+'<li><a href="http://www.domain/opa/speeches/">Speeches</a></li>' + '\n'
                	+'<li><a href="http://www.domain/opa/videos/">Videos</a></li>' + '\n'
                    +'<li><a href="http://www.domain/opa/publications/">Publications</a></li>' + '\n'
                    +'</ul>' + '\n'
					+'<h4>National Observances</h4>' + '\n'
					+'<ul>' + '\n'
					+'<li><a href="http://www.domain/opa/vetsday/">Veterans Day</a></li>' + '\n'
					+'<li><a href="http://www.domain/opa/speceven/memday/">Memorial Day</a></li>' + '\n'
					+'<li><a href="http://www.domain/opa/publications/celebrate_americas_freedoms.asp">Celebrating America\'s Freedoms</a></li>' + '\n'
					+'</ul>' + '\n'
                +'</div>' + '\n'
                +'<div class="sub_nav">' + '\n'
                	+'<h4>Special Events</h4>' + '\n'
                	+'<ul>' + '\n'
                	+'<li><a href="http://www.creativeartsfestival.domain/">Creative Arts Festival</a></li>' + '\n'
					+'<li><a href="http://www.veteransgoldenagegames.domain/">Golden Age Games</a></li>' + '\n'
                    +'<li><a href="http://www.summersportsclinic.domain/">Summer Sports Clinic</a></li>' + '\n'
                    +'<li><a href="http://www.tee.domain/">Training&ndash;Exposure&ndash; Experience (TEE) Tournament</a></li>' + '\n'
                    +'<li><a href="http://www.wheelchairgames.domain/">Wheelchair Games</a></li>' + '\n'
                    +'<li><a href="http://www.wintersportsclinic.domain/">Winter Sports Clinic</a></li>' + '\n'
                    +'</ul>' + '\n'
                 +'</div>' + '\n'
                    +'<div class="clear"></div>' + '\n'
				+'</div>' + '\n'
          +'</li>' + '\n'
               
                +'<li>' + '\n'
                +'<a href="http://www.domain/landing2_locations.htm">Locations</a>' + '\n'
                +'<div class="menu">' + '\n'
                +'<div class="sub_nav">' + '\n'
                	+'<ul>' + '\n'
					+'<li><a href="http://www.domain/directory/guide/division_flsh.asp?dnum=1">Hospitals and Clinics</a></li>' + '\n'
                	+'<li><a href="http://www.domain/directory/guide/vetcenter_flsh.asp">Vet Centers</a></li>' + '\n'
                	+'<li><a href="http://www.domain/directory/guide/division_flsh.asp?dnum=3">Regional Benefits Offices</a></li>' + '\n'
                    +'<li><a href="http://homeloans.domain/rlcweb.htm">Regional Loan Centers</a></li>' + '\n'
                    +'<li><a href="http://www.domain/directory/guide/division_flsh.asp?dnum=4">Cemetery Locations</a></li>' + '\n'
                    +'</ul>' + '\n'
                  +'</div>' + '\n'
                   	+'<div class="clear"></div>' + '\n'
               	+'</div>' + '\n'
                +'</li>' + '\n'
                
                +'<li>' + '\n'
                +'<a href="http://www.domain/landing2_contact.htm">Contact Us</a>' + '\n'
                +'<div class="menu">' + '\n'
                +'<div class="sub_nav">' + '\n'
                	+'<ul>' + '\n'
					+'<li><a href="http://www.domain/ext_redirect.asp?url=https://iris.custhelp.com/app/answers/list">FAQs</a></li>' + '\n'
					+'<li><a href="http://www.domain/ext_redirect.asp?url=https://iris.custhelp.com">Ask a Question</a></li>' + '\n'
                	+'<li><a href="http://www.domain/ext_redirect.asp?url=https://iris.custhelp.com/app/answers/detail/a_id/1703">Toll Free Numbers</a></li>' + '\n'
                    +'</ul>' + '\n'
                  +'</div>' + '\n'
                   	+'<div class="clear"></div>' + '\n'
                +'</div>' + '\n'
          +'</li>' + '\n'
                
       +'</ul>' + '\n'
	   
	  
			
			 )
	
};