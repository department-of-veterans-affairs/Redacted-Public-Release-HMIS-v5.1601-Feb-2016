document.write('<script type="text/javascript" src="/va_files/2009/scripts/jquery-min-modified.js"></script>');
document.write('<script type="text/javascript" src="/va_files/2009/scripts/jquery-bgiframe.js"></script>');
document.write('<script type="text/javascript" src="/va_files/2009/scripts/dropdown.js"></script>');

document.write('<!--[if IE 7]><style type="text/css" media="screen">@import url(/va_files/2009/styles/ie7.css);</style><![endif]-->');