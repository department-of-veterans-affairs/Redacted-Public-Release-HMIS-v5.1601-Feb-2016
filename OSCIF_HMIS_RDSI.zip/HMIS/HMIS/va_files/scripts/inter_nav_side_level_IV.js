//  File............: inter_nav_side_level_IV.js
//  Description.....: JavaScript code for left-side navigation on Level IV pages
//  Version.........: 1.1
//  Release Date....: December 19, 2005
/*
Updates
	1.1 - January 10, 2006
		Added IFRAME layers to prevent select boxes and embedded objects from showing through the flyouts 
		when viewed in Internet Explorer.
*/

var isIE = 0;
if (navigator.appName == "Microsoft Internet Explorer") {
	if (navigator.userAgent.indexOf("Opera") ==-1 ) {
		isIE = 1;
	}
}

var flyoutText = '';
flyoutText = '<div><ul id="nav">';

// HEALTH CARE
flyoutText += '<li class="nav-section-hdr"><h1 class="hideme">Health Care</h1></li>';
flyoutText += '<li><a href="http://www.domain/health/" class="parent" title="Information on health care benefits offered by Veterans Affairs">Health Care</a>';
if (isIE) {
	flyoutText += '<iframe id="coverer_health_care" frameborder="0" title="Health Care fly-out" src="javascript: \'Health Care hyperlinks\';" style="height:265px"></iframe>';
}
flyoutText += '<ul>';
flyoutText += '<li><a href="http://www.domain/health/" title="Information on health care benefits offered by Veterans Affairs">Health Benefits &amp; Services</a></li>';
flyoutText += '<li><a href="http://www.myhealth.domain/" title="Information on the My HealtheVet program">My Health<em style="text-decoration:underline">e</em>Vet</a></li>';
flyoutText += '<li><a href="http://www.domain/health/gateway.html" title="Organization and Programs within the Veterans Health Administration of Veterans Affairs">VHA Organizations and Programs</a></li>';
flyoutText += '<li><a href="http://www.patientsafety.gov/" title="National Center for Patient Safety">National Center for Patient Safety</a></li>';
flyoutText += '<li><a href="http://www.domain/directory/" title="Find a Veterans Affairs facility">Facility Locator</a></li>';
flyoutText += '<li><a href="http://www.domain/volunteer/" title="Volunteer to help veterans">Volunteer</a></li>';
flyoutText += '<li><a href="http://www.domain/hac/forbeneficiaries/champva/champva.asp" title="CHAMPVA">CHAMPVA</a></li>';
flyoutText += '<li><a href="http://www.pbm.domain/PBM/menu.asp" title="Pharmacy Benefits">Pharmacy Benefits</a></li>';
flyoutText += '</ul></li>';

// BENEFITS
flyoutText += '<li class="nav-section-hdr"><h1 class="hideme">Benefits</h1></li>';
flyoutText += '<li><a href="http://www.vba.domain/" class="parent" title="Information on benefits offered by Veterans Affairs">Benefits</a>';
if (isIE) {
	flyoutText += '<iframe id="coverer_benefits" frameborder="0" title="Benefits fly-out" src="javascript: \'Benefits hyperlinks\';" style="height:261px"></iframe>';
}
flyoutText += '<ul>';
flyoutText += '<li><a href="http://www.vba.domain/bln/21/index.htm" title="Information on compensation and pension benefits">Compensation &amp; Pension</a></li>';
flyoutText += '<li><a href="http://www.gibill.domain/" title="Information on education benefits">Education</a></li>';
flyoutText += '<li><a href="http://www.homeloans.domain/" title="Information on home loan benefits">Home Loans</a></li>';
flyoutText += '<li><a href="http://www.insurance.domain/" title="Information on life insurance benefits">Life Insurance</a></li>';
flyoutText += '<li><a href="http://www.vba.domain/bln/vre/index.htm" title="Information on vocational rehabilitation and training">Vocational Rehabilitation</a></li>';
flyoutText += '<li><a href="http://www.vba.domain/survivors/index.htm" title="Information on benefits for survivors">Survivors\' Benefits</a></li>';
flyoutText += '<li><a href="http://www.pbm.domain/PBM/menu.asp" title="Pharmacy Benefits">Pharmacy Benefits</a></li>';
flyoutText += '<li><a href="http://www.domain/hac/forbeneficiaries/champva/champva.asp" title="CHAMPVA">CHAMPVA</a></li>';
flyoutText += '<li><a href="http://www.cem.domain/burial.htm" title="Information on burial benefits">Burial Benefits</a></li>';
flyoutText += '</ul></li>';

// BURIAL & MEMORIALS
flyoutText += '<li class="nav-section-hdr"><h1 class="hideme">Burial &amp; Memorials</h1></li>';
flyoutText += '<li><a href="http://www.cem.domain/" class="parent" title="Information on burial and memorial benefits">Burial &amp; Memorials</a>';
if (isIE) {
	flyoutText += '<iframe id="coverer_burial_memorials" frameborder="0" title="Burial &amp; Memorials fly-out" src="javascript: \'Burial &amp; Memorials hyperlinks\';" style="height:207px"></iframe>';
}
flyoutText += '<ul>';
flyoutText += '<li><a href="http://www.cem.domain/" title="Information on burial and memorial benefits">Burial and Memorial Benefits</a></li>';
flyoutText += '<li><a href="http://gravelocator.cem.domain/" title="Find a veteran\'s gravesite">Nationwide Gravesite Locator</a></li>';
flyoutText += '<li><a href="http://www.cem.domain/cem/cems_nmc.asp" title="Cemeteries">Cemeteries</a></li>';
flyoutText += '<li><a href="http://www.cem.domain/cem/bbene_burial.asp" title="Burial benefits provided by Veterans Affairs">Burial Benefits</a></li>';
flyoutText += '<li><a href="http://www.cem.domain/cem/hm_hm.asp" title="Information on Veterans Affairs headstones and markers">Headstones and Markers</a></li>';
flyoutText += '<li><a href="http://www.cem.domain/cem/pmc.asp" title="Information on Presidential Memorial Certificates">Presidential Memorial Certificates</a></li>';
flyoutText += '</ul></li>';

flyoutText += '</ul></div>';
document.write(flyoutText);
