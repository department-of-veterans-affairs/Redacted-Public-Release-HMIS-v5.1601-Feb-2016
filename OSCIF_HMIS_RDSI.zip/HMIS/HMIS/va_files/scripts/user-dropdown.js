//  File............: user-dropdown.js
//  Description.....: JavaScript function for left-side navigation flyouts of user-defined hyperlinks
//  Version.........: 1.1
//  Release Date....: December 19, 2005
/*
Updates
	1.1 - January 10, 2006
		Added if structure to activate an IFRAME layers to prevent select boxes and embedded objects from showing 
		through the flyouts when viewed in Internet Explorer.
*/

var sfHover = function() {
	if (navigator.appName == "Microsoft Internet Explorer") {
		var ucvrEls = document.getElementById("nav2").getElementsByTagName("IFRAME");
		for (var j=0; j<ucvrEls.length; j++) {
			ucvrEls[j].onmouseover=function() {
				this.className+=" sfhover";
			}
			ucvrEls[j].onmouseout=function() {
				this.className=this.className.replace(new RegExp(" sfhover\\b"), "");
			}
		}
	}
	var sfEls = document.getElementById("nav2").getElementsByTagName("LI");
	for (var i=0; i<sfEls.length; i++) {
		sfEls[i].onmouseover=function() {
			this.className+=" sfhover";
		}
		sfEls[i].onmouseout=function() {
			this.className=this.className.replace(new RegExp(" sfhover\\b"), "");
		}
	}
}
if (window.attachEvent) window.attachEvent("onload", sfHover);