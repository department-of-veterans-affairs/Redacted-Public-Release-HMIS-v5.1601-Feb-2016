//  File............: inter_nav_side.js
//  Description.....: JavaScript code for left-side navigation on Level III and Level V pages
//  Version.........: 1.1
//  Release Date....: December 19, 2005
/*
Updates
	1.1 - January 10, 2006
		Added IFRAME layers to prevent select boxes and embedded objects from showing through the flyouts 
		when viewed in Internet Explorer.

    2.1 - June 2, 2009
	    Added flyout link (Veterans Law Review) to the BVA site nav
*/
var isIE = 0;
if (navigator.appName == "Microsoft Internet Explorer") {
	if (navigator.userAgent.indexOf("Opera") ==-1 ) {
		isIE = 1;
	}
}

var flyoutText = '';
flyoutText = '<div><ul id="nav">';

// HEALTH CARE
flyoutText += '<li class="nav-section-hdr"><h1 class="hideme">Health Care</h1></li>';
flyoutText += '<li><a href="http://www.domain/health/" class="parent" title="Information on health care benefits offered by Veterans Affairs">Health Care</a>';
if (isIE) {
	flyoutText += '<iframe id="coverer_health_care" frameborder="0" title="Health Care fly-out" src="javascript: \'Health Care hyperlinks\';" style="height:265px"></iframe>';
}
flyoutText += '<ul>';
flyoutText += '<li><a href="http://www.domain/health/" title="Information on health care benefits offered by Veterans Affairs">Health Benefits &amp; Services</a></li>';
flyoutText += '<li><a href="http://www.myhealth.domain/" title="Information on the My HealtheVet program">My Health<em style="text-decoration:underline">e</em>Vet</a></li>';
flyoutText += '<li><a href="http://www.domain/health/AboutVHA.asp" title="Organization and Programs within the Veterans Health Administration of Veterans Affairs">VHA Organizations and Programs</a></li>';
flyoutText += '<li><a href="http://www.patientsafety.gov/" title="National Center for Patient Safety">National Center for Patient Safety</a></li>';
flyoutText += '<li><a href="http://www.domain/directory/" title="Find a Veterans Affairs facility">Locations</a></li>';
flyoutText += '<li><a href="http://www.domain/volunteer/" title="Volunteer to help veterans">Volunteer</a></li>';
flyoutText += '<li><a href="http://www.domain/hac/forbeneficiaries/champva/champva.asp" title="CHAMPVA">CHAMPVA</a></li>';
flyoutText += '<li><a href="http://www.pbm.domain/" title="Pharmacy Benefits">Pharmacy Benefits</a></li>';
flyoutText += '</ul></li>';

// BENEFITS
flyoutText += '<li class="nav-section-hdr"><h1 class="hideme">Benefits</h1></li>';
flyoutText += '<li><a href="http://www.vba.domain/" class="parent" title="Information on benefits offered by Veterans Affairs">Benefits</a>';
if (isIE) {
	flyoutText += '<iframe id="coverer_benefits" frameborder="0" title="Benefits fly-out" src="javascript: \'Benefits hyperlinks\';" style="height:290px"></iframe>';
}
flyoutText += '<ul>';
flyoutText += '<li><a href="http://www.vba.domain/bln/21/index.htm" title="Information on compensation and pension benefits">Compensation &amp; Pension</a></li>';
flyoutText += '<li><a href="http://www.gibill.domain/" title="Information on education benefits">Education</a></li>';
flyoutText += '<li><a href="http://www.homeloans.domain/" title="Information on home loan benefits">Home Loans</a></li>';
flyoutText += '<li><a href="http://www.insurance.domain/" title="Information on life insurance benefits">Life Insurance</a></li>';
flyoutText += '<li><a href="http://www.vba.domain/bln/vre/index.htm" title="Information on vocational rehabilitation and training">Vocational Rehabilitation</a></li>';
flyoutText += '<li><a href="http://www.vetsuccess.gov/" title="VetSuccess Web site">VetSuccess</a></li>';
flyoutText += '<li><a href="http://www.vba.domain/survivors/index.htm" title="Information on benefits for survivors">Survivors\' Benefits</a></li>';
flyoutText += '<li><a href="http://www.pbm.domain/" title="Pharmacy Benefits">Pharmacy Benefits</a></li>';
flyoutText += '<li><a href="http://www.domain/hac/forbeneficiaries/champva/champva.asp" title="CHAMPVA">CHAMPVA</a></li>';
flyoutText += '<li><a href="http://www.cem.domain/cem/bbene_burial.asp" title="Information on burial benefits">Burial Benefits</a></li>';
flyoutText += '</ul></li>';

// BURIAL & MEMORIALS
flyoutText += '<li class="nav-section-hdr"><h1 class="hideme">Burial &amp; Memorials</h1></li>';
flyoutText += '<li><a href="http://www.cem.domain/" class="parent" title="Information on burial and memorial benefits">Burial &amp; Memorials</a>';
if (isIE) {
	flyoutText += '<iframe id="coverer_burial_memorials" frameborder="0" title="Burial &amp; Memorials fly-out" src="javascript: \'Burial &amp; Memorials hyperlinks\';" style="height:207px"></iframe>';
}
flyoutText += '<ul>';
flyoutText += '<li><a href="http://www.cem.domain/" title="Information on burial and memorial benefits">Burial and Memorial Benefits</a></li>';
flyoutText += '<li><a href="http://gravelocator.cem.domain/" title="Find a veteran\'s gravesite">Nationwide Gravesite Locator</a></li>';
flyoutText += '<li><a href="http://www.cem.domain/cem/cems_nmc.asp" title="Cemeteries">Cemeteries</a></li>';
flyoutText += '<li><a href="http://www.cem.domain/cem/bbene_burial.asp" title="Burial benefits provided by Veterans Affairs">Burial Benefits</a></li>';
flyoutText += '<li><a href="http://www.cem.domain/cem/hm_hm.asp" title="Information on Veterans Affairs headstones and markers">Headstones and Markers</a></li>';
flyoutText += '<li><a href="http://www.cem.domain/cem/pmc.asp" title="Information on Presidential Memorial Certificates">Presidential Memorial Certificates</a></li>';
flyoutText += '</ul></li>';

// VA JOBS
flyoutText += '<li class="nav-section-hdr"><h1 class="hideme">VA Jobs</h1></li>';
flyoutText += '<li><a href="http://www.domain/jobs/" class="parent" title="Jobs with Veterans Affairs">VA Jobs</a>';
if (isIE) {
	flyoutText += '<iframe id="coverer_va_jobs" frameborder="0" title="Veterans Affairs Jobs fly-out" src="javascript: \'Veterans Affairs jobs hyperlinks\';" style="height:174px"></iframe>';
}
flyoutText += '<ul>';
flyoutText += '<li><a href="http://www.domain/jobs/va_in_depth.asp" title="A look at who we are and those we serve">VA In Depth</a></li>';
flyoutText += '<li><a href="http://www.domain/jobs/job_benefits/benefits.asp" title="Review the benefits of working for VA">Job Benefits</a></li>';
flyoutText += '<li><a href="http://www.domain/jobs/types_careers.asp" title="Explore VA career categories">Types of VA Jobs</a></li>';
flyoutText += '<li><a href="http://www.domain/jobs/hiring_programs.asp" title="VA hiring programs and incentives">Hiring Programs</a></li>';
flyoutText += '<li><a href="http://www.domain/jobs/hiring_process.asp" title="VA hiring process and qualifications">Hiring Process</a></li>';
flyoutText += '<li><a href="http://www.domain/jobs/career_search.asp" title="VA Career Search">Career Search</a></li>';
flyoutText += '</ul></li>';

// BOARD OF VETERANS' APPEALS
flyoutText += '<li class="nav-section-hdr"><h1 class="hideme">Board of Veterans\' Appeals</h1></li>';
flyoutText += '<li><a href="http://www.domain/vbs/bva/" class="parent" title="Board of Veterans\' Appeals">Board of Veterans\' Appeals</a>';
if (isIE) {
	flyoutText += '<iframe id="coverer_bva" frameborder="0" title="Board of Veterans Appeals fly-out" src="javascript: \'Board of Veterans Appeals hyperlinks\';" style="height:185px"></iframe>';
}
flyoutText += '<ul class="twolinemenu">';
flyoutText += '<li><a href="http://www.domain/vbs/bva/annual_rpt.htm" title="Chairman\'s Annual Reports to Congress">Chairman\'s Annual Reports to Congress</a></li>';
flyoutText += '<li><a href="http://www.domain/vbs/bva/lawReview_MailCopy.htm" title="Veterans Law Review">Veterans Law Review</a></li>';
flyoutText += '<li><a href="http://www.domain/vbs/bva/pamphlet.htm" title="Information on the appeals process">Pamphlets: Appeals Process</a></li>';
flyoutText += '<li><a href="http://www.domain/vbs/bva/contactbva.htm" title="Customer service for the appeals process">Customer Service</a></li>';
flyoutText += '<li><a href="http://www.domain/vaforms/" title="Access forms used by Veterans Affairs">VA Forms</a></li>';
flyoutText += '<li><a href="http://www.index.domain/search/va/bva.html" title="Search the decision of the Board of Veterans\' Appeals">Search Decisions</a></li>';
flyoutText += '</ul></li>';

// PUBLIC AFFAIRS
flyoutText += '<li class="nav-section-hdr"><h1 class="hideme">Public Affairs</h1></li>';
flyoutText += '<li><a href="http://www.domain/opa/" class="parent" title="Office of Public Affairs">Public Affairs</a>';
if (isIE) {
	flyoutText += '<iframe id="coverer_opia" frameborder="0" title="Public Affairs fly-out" src="javascript: \'Public Affairs hyperlinks\';" style="height:243px"></iframe>';
}
flyoutText += '<ul>';
flyoutText += '<li><a href="http://www.domain/opa/pressrel/index.cfm" title="Veterans Affairs new releases">News Releases</a></li>';
flyoutText += '<li><a href="http://www.domain/opa/bios/index.asp" title="Veterans Affairs executive biographies">Executive Biographies</a></li>';
flyoutText += '<li><a href="http://www.domain/opa/speeches/index.asp" title="Speeches by the Secretary of Veterans Affairs">Speeches</a></li>';
flyoutText += '<li><a href="http://www.domain/opa/fact/index.asp" title="Veterans Affairs fact sheets">Fact Sheets</a></li>';
flyoutText += '<li><a href="http://www.domain/opa/feature/index.asp" title="Items featured by Public Affairs">Feature Items</a></li>';
flyoutText += '<li><a href="http://www.domain/opa/speceven/index.asp" title="Special events for Veterans">Special Events</a></li>';
flyoutText += '<li><a href="http://www.domain/opa/iga/index.asp" title="Intergovernmental Affairs">Intergovernmental Affairs</a></li>';
flyoutText += '<li><a href="http://www.domain/fbci/index.cfm" title="Veterans Affairs faith-based initiatives">Faith-Based Initiatives</a></li>';
flyoutText += '</ul></li>';

// CONGRESSIONAL AFFAIRS
flyoutText += '<li class="nav-section-hdr"><h1 class="hideme">Congressional Affairs</h1></li>';
flyoutText += '<li><a href="http://www.domain/oca/" class="parent" title="Office of Congressional Affairs">Congressional Affairs</a>';
if (isIE) {
	flyoutText += '<iframe id="coverer_oca" frameborder="0" title="Congressional Affairs fly-out" src="javascript: \'Congressional Affairs hyperlinks\';" style="height:145px"></iframe>';
}
flyoutText += '<ul class="twolinemenu">';
flyoutText += '<li><a href="http://www.domain/oca/casework.asp" title="Casework resources">Casework Resources</a></li>';
flyoutText += '<li><a href="http://www.domain/oca/c2c.asp" title="Communications to Congress">Communications to Congress</a></li>';
flyoutText += '<li><a href="http://www.domain/oca/testimony.asp" title="Testimony before Congress by Veterans Affairs officals">VA Testimony</a></li>';
flyoutText += '<li><a href="http://www.domain/oca/vet_legis.asp" title="Information on legislation affecting veterans">Veterans Legislation</a></li>';
flyoutText += '<li><a href="http://www.domain/oca/fed_reg_index.asp" title="Federal regulations">Federal Regulations</a></li>';
flyoutText += '</ul></li>';

// BUSINESS OPPORTUNITIES
flyoutText += '<li class="nav-section-hdr"><h1 class="hideme">Business Opportunities</h1></li>';
flyoutText += '<li><a href="http://www.domain/partners/buspart/index.htm" class="parent" title="Business opportunities with Veterans Affairs">Business Opportunities</a>';
if (isIE) {
	flyoutText += '<iframe id="coverer_bizops" frameborder="0" title="Business Opportunities fly-out" src="javascript: \'Business Opportunities hyperlinks\';" style="height:178px"></iframe>';
}
flyoutText += '<ul class="twolinemenu">';
flyoutText += '<li><a href="http://www.domain/oamm/oa/dbwva/index.cfm" title="Veterans Affairs business opportunities">VA Business Opportunities</a></li>';
flyoutText += '<li><a href="http://www.domain/oamm/oa/ars/policyreg/index.cfm" title="Acquisition policies and regualtions">Acquisition Policies &amp; Regulations</a></li>';
flyoutText += '<li><a href="http://www.cfm.domain/" title="Construction and design">Construction &amp; Design</a></li>';
flyoutText += '<li><a href="http://www.domain/OSDBU/" title="Small and disadvantaged business information">Small &amp; Disadvantaged Business Utilization</a></li>';
flyoutText += '<li><a href="http://www.research.domain/" title="Information on Veterans Affairs research and development">Research &amp; Development</a></li>';
flyoutText += '</ul></li>';

// PARTNERS
flyoutText += '<li class="nav-section-hdr"><h1 class="hideme">Partners</h1></li>';
flyoutText += '<li><a href="http://www.domain/partners/" class="parent" title="Information on partners of Veterans Affairs">Partners</a>';
if (isIE) {
	flyoutText += '<iframe id="coverer_partners" frameborder="0" title="Partners fly-out" src="javascript: \'Partners hyperlinks\';" style="height:138px"></iframe>';
}
flyoutText += '<ul>';
flyoutText += '<li><a href="http://www.domain/vso/" title="Veterans Service Organizations">Veterans Service Organizations</a></li>';
flyoutText += '<li><a href="http://www.domain/statedva.htm" title="Links to state Veterans Affairs offices">State Veterans Affairs Offices</a></li>';
flyoutText += '<li><a href="http://www.domain/advisory/" title="Links to Advisory Committee">Advisory Committees</a></li>';
flyoutText += '<li><a href="http://www.domain/partners/init/index.htm#government" title="Links to other government partners">Other Government Links</a></li>';
flyoutText += '</ul></li>';

// VETERAN DATA
flyoutText += '<li class="nav-section-hdr"><h1 class="hideme">Veteran Data</h1></li>';
flyoutText += '<li><a href="http://www.domain/vetdata/" title="Statistics on the veterans population">Veteran Data</a></li>';

// INSPECTOR GENERAL
flyoutText += '<li class="nav-section-hdr"><h1 class="hideme">Inspector General</h1></li>';
flyoutText += '<li><a href="http://www.domain/oig/" title="Office of the Inspector General">Inspector General</a></li>';

// BUDGET AND PERFORMANCE
flyoutText += '<li class="nav-section-hdr"><h1 class="hideme">Budget and Performance</h1></li>';
flyoutText += '<li><a href="http://www.domain/performance/" class="parent" title="Budget and Performance">Budget and Performance</a>';
if (isIE) {
	flyoutText += '<iframe id="coverer_budget" frameborder="0" title="Budget and Performance fly-out" src="javascript: \'Budget and Performance hyperlinks\';" style="height:116px"></iframe>';
}
flyoutText += '<ul class="twolinemenu">';
flyoutText += '<li><a href="http://www1.domain/op3/docs/VA_2006_2011_Strategic_Plan.pdf" title="Strategic Plan">Strategic Plan</a></li>';
flyoutText += '<li><a href="http://www.domain/budget/report/2008/index.htm" title="Performance and Accountability Report">Performance and Accountability Report</a></li>';
flyoutText += '<li><a href="http://www.domain/budget/summary/2010/index.htm" title="Budget Submission">Budget Submission</a></li>';
flyoutText += '<li><a href="http://www.itsegov.oit.domain/docs/it_strat_plan.pdf" title="IT Strategic Plan">IT Strategic Plan</a></li>';
flyoutText += '</ul></li>';

// RECOVERY PAGE
flyoutText += '<li class="nav-section-hdr"><h1 class="hideme">Recovery Act</h1></li>';
flyoutText += '<li><a href="http://www.domain/recovery/" title="Information related to the Recovery Act">Recovery Act</a></li>';

// KIDS PAGE
flyoutText += '<li class="nav-section-hdr"><h1 class="hideme">KIDS Page</h1></li>';
flyoutText += '<li><a href="http://www.domain/kids/" title="Information on Veterans Affairs for children"><span style="color:#00FF00">K</span><span style="color:#FFFF00">I</span><span style="color:#00FFFF">D</span><span style="color:#FFCCFF">S</span> Page</a></li>';

flyoutText += '</ul></div>';
document.write(flyoutText);
