//  File............: inter_nav_top.js
//  Description.....: JavaScript code for top navigation
//  Version.........: 1.1
//  Release Date....: December 19, 2005
/*
Updates
	1.1 - January 10, 2006
		Added IFRAME layers to prevent select boxes and embedded objects from showing through the flyouts 
		when viewed in Internet Explorer.
*/
var isIE = 0;
if (navigator.appName == "Microsoft Internet Explorer") {
	if (navigator.userAgent.indexOf("Opera") ==-1 ) {
		isIE = 1;
	}
}

var flyoutText = '';
flyoutText = '<ul id="nav-top">';
flyoutText += '<li class="narrowtop"><a href="http://www.domain/" title="Veterans Affairs Home Page" class="narrowtop">VA Home</a></li>';
flyoutText += '<li class="narrowtop"><a href="http://www.domain/about_va/" title="Information about the Department of Veterans Affairs" class="narrowtop">About VA</a></li>';
flyoutText += '<li class="averagetop"><a href="http://www.domain/landing_organizations.htm" title="Department of Veterans Affairs Organizations" class="averagetop">Organizations</a></li>';
flyoutText += '<li><a href="http://www.domain/onlineapps.htm" class="parenttop" title="Apply Online for VA Services">Apply Online</a>';
if (isIE) {
	flyoutText += '<iframe id="coverer_apply_online" frameborder="0" title="Apply Online drop down" src="javascript: \'Apply Online hyperlinks\';" style="height:190px"></iframe>';
}
flyoutText += '<ul class="widesttop">';
flyoutText += '<li class="widesttop"><a href="http://vabenefits.vba.domain/vonapp/" class="widesttop" target="_blank" title="Apply for compensation and pension benefits - this opens in a new browser window">Compensation &amp; Pension <img src="/va_files/images/newWindow.gif" height="9" width="12" alt="hyperlink opens in a new browser window" style="border:0px"> </a></li>';
flyoutText += '<li class="widesttop"><a href="http://vabenefits.vba.domain/vonapp/" class="widesttop" target="_blank" title="Apply for education benefits - this opens in a new browser window">Education <img src="/va_files/images/newWindow.gif" height="9" width="12" alt="hyperlink opens in a new browser window" style="border:0px"> </a></li>';
flyoutText += '<li class="widesttop"><a href="https://www.1010ez.domain.ext/sec/vha/1010ez/" class="widesttop" title="Apply for health benefits">Health Eligibility</a></li>';
flyoutText += '<li class="widesttop"><a href="http://www.myhealth.domain/" class="widesttop" title="Information on the My HealtheVet program">My Health<em style="text-decoration:underline">e</em>Vet</a></li>';
flyoutText += '<li class="widesttop"><a href="http://vabenefits.vba.domain/vonapp/" class="widesttop" target="_blank" title="Vocational Rehabilitation and Employment Service - this opens in a new browser window">Vocational Rehab &amp; Employment Services <img src="/va_files/images/newWindow.gif" height="9" width="12" alt="hyperlink opens in a new browser window" style="border:0px"> </a></li>';
flyoutText += '<li class="widesttop"><a href="https://insurance.domain/Autoform/index.asp" class="widesttop" title="Life Insurance">Life Insurance</a></li>';
flyoutText += '<li class="widesttop"><a href="http://www.domain/jobs/career_search.asp" class="widesttop" title="Career Search on VA Jobs">Career Search</a></li>';
flyoutText += '</ul></li>';
flyoutText += '<li class="narrowtop"><a href="http://www.domain/directory/" title="Find a Veterans Affairs facility" class="narrowtop">Locations</a></li>';
flyoutText += '<li class="averagetop"><a href="https://iris.domain/" title="Contact the Department of Veterans Affairs" class="averagetop">Contact VA</a></li>';

flyoutText += '</ul>';
document.write(flyoutText);
