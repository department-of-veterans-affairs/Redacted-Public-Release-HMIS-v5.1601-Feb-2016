//  File............: dropdown.js
//  Description.....: JavaScript function for left-side navigation flyouts
//  Version.........: 1.2
//  Release Date.....: December 19, 2005
/*
Updates
	1.1 - January 10, 2006
		Added if structure to activate an IFRAME layers to prevent select boxes and embedded objects from showing 
		through the flyouts when viewed in Internet Explorer.
	1.2 - July 11, 2006
		Added code for pop-up customer satisfaction survey.
		Added code to allow for proper display of flyouts even when Opera identifies itself as IE
*/
var sfHover = function() {
	if (navigator.appName == "Microsoft Internet Explorer") {
		var cvrEls = document.getElementById("nav").getElementsByTagName("IFRAME");
		for (var j=0; j<cvrEls.length; j++) {
			cvrEls[j].onmouseover=function() {
				this.className+=" sfhover";
			}
			cvrEls[j].onmouseout=function() {
				this.className=this.className.replace(new RegExp(" sfhover\\b"), "");
			}
		}
	}
	var sfEls = document.getElementById("nav").getElementsByTagName("LI");
	for (var i=0; i<sfEls.length; i++) {
		sfEls[i].onmouseover=function() {
			this.className+=" sfhover";
		}
		sfEls[i].onmouseout=function() {
			this.className=this.className.replace(new RegExp(" sfhover\\b"), "");
		}
	}
}
if (window.attachEvent) window.attachEvent("onload", sfHover);
