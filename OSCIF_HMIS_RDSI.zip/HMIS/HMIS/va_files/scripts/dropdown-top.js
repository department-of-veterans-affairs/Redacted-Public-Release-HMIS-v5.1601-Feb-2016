//  File............: dropdown-top.js
//  Description.....: JavaScript function for top navigation dropdowns
//  Version.........: 1.1
//  Release Date....: December 19, 2005
/*
Updates
	1.1 - January 10, 2006
		Added if structure to activate an IFRAME layers to prevent select boxes and embedded objects from showing 
		through the flyouts when viewed in Internet Explorer.
*/

var sfhovertop = function() {
	if (navigator.appName == "Microsoft Internet Explorer") {
		var cvrElsTop = document.getElementById("nav-top").getElementsByTagName("IFRAME");
		for (var j=0; j<cvrElsTop.length; j++) {
			cvrElsTop[j].onmouseover=function() {
				this.className+=" sfhovertop";
			}
			cvrElsTop[j].onmouseout=function() {
				this.className=this.className.replace(new RegExp(" sfhovertop\\b"), "");
			}
		}
	}
	var sfElsTop = document.getElementById("nav-top").getElementsByTagName("LI");
	for (var i=0; i<sfElsTop.length; i++) {
		sfElsTop[i].onmouseover=function() {
			this.className+=" sfhovertop";
		}
		sfElsTop[i].onmouseout=function() {
			this.className=this.className.replace(new RegExp(" sfhovertop\\b"), "");
		}
	}
}
if (window.attachEvent) window.attachEvent("onload", sfhovertop);
