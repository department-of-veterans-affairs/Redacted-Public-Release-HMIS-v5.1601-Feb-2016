<?php
include('init.php');
include('hmis/libs/functions.php');


if (checklogin($userID, "menu.php") && $status == 2) {



print_header();

?>

<H1 align=center>Edit Website Content</H1>
<CENTER><A HREF="menu.php" >Repository Home</A></CENTER>
<HR>


<FORM ACTION="update_content.php" METHOD="POST">
<INPUT TYPE=hidden id="e_token" name="e_token" VALUE="<?php echo $_SESSION['e_token']; ?>">

<?



// INDEX

$sql = "SELECT html FROM tb_content WHERE page_id=1";
$rs = $db->Execute($sql);
$record_count = $rs->RecordCount();
if ($record_count == 1) {
$html = scrub_white_list($rs->fields('html'), 'HTMLNOSCRIPT');
}
else {$html = "";}

?>

<H2><label for="elm1">Home Page</label></H2>
<textarea id="elm1" name="elm1" rows="15" cols="80" style="width: 80%">
<?echo $html;?>
</textarea>

<?


// Account Menu

$sql = "SELECT html FROM tb_content WHERE page_id=2";
$rs = $db->Execute($sql);
$record_count = $rs->RecordCount();
if ($record_count == 1) {
$html = scrub_white_list($rs->fields('html'), 'HTMLNOSCRIPT');
}
else {$html = "";}

?>

<H2><label for="elm2">Account Menu</label></H2>
<textarea id="elm2" name="elm2" rows="15" cols="80" style="width: 80%">
<?echo $html;?>
</textarea>

<?
// Support Page

$sql = "SELECT html FROM tb_content WHERE page_id=3";
$rs = $db->Execute($sql);
$record_count = $rs->RecordCount();
if ($record_count == 1) {
	$html = scrub_white_list($rs->fields('html'), 'HTMLNOSCRIPT');
}
else {$html = "";}

?>

<H2><label for="elm3">Support Page Text</label></H2>
<textarea id="elm3" name="elm3" rows="15" cols="80" style="width: 80%">
<?echo $html;?>
</textarea>

<BR>

<INPUT TYPE=SUBMIT VALUE="Save Changes">
</FORM>
<?

print_footer();

} // end check login

?>