<?php

include('init.php');
include('hmis/libs/functions.php');


$e_token = trim(scrub_white_list($_POST['e_token'], 'ALPHANUMERICONLY'));
$s_e_token = $_SESSION['e_token'];

//echo "e_token-> " . $e_token;
//echo "<BR>s_e_token -> " . $s_e_token;

if ((ISSET($e_token)) && ($e_token===$s_e_token)){
	if (checklogin($userID, "menu.php") && $status == 2) {

		if ((isset($_REQUEST['p'])) && (isset($_REQUEST['remove_from_prog']))) { 
			$pid = scrub_sql(scrub_white_list($_REQUEST['p'], 'NUMBERONLY'), 8);
			
			$sql = "SELECT * FROM tb_SSVF_program sp, tb_SSVF_grant sg WHERE sp.program_id=$pid AND sg.grant_id=sp.grant_id";
			$rs = $db->Execute($sql);
			$pNameDisp = $rs->fields('program_name');
			$gNameDisp = $rs->fields('grant_name');
		
			$userSQL = "";
			$usersSel = array();
			$usersSel = $_REQUEST['remove_from_prog'];
		
			foreach($usersSel as $value){
				//echo $value . "<br>";
					  $usersSel = scrub_white_list($usersSel, 'NUMBERONLY');
					  $userSQL = implode(', ' , $usersSel);
			}
			
			 //echo "<br><br>userSQL -> ". $userSQL;
			
			$sql = "DELETE FROM tb_user_programs where user_id IN ($userSQL) AND program_id=$pid";
			$rs = $db->Execute($sql);
		
			//echo $sql;
		
			//$sql = "INSERT INTO tb_audit (user_id, event, event_date) VALUES ($userID, 'Admin disassociated users from program $pid', getdate())";
			//$rs = $db->Execute($sql);

			
			$message = 'Admin removed users from program';
			audit_log($userID, $message, 5, 0, $pid);

		
			print_header();
		
			print ("
				<table width=800 align=center>
				<tr><td>
				<BR>
				<HR>
				<H1 align=center>Users Removed</H1>
				<center>
				<font size=2><b>$pNameDisp<b></font>
				<br>
				<font size=1><i>$gNameDisp</i></font>
				</center>
				<BR>
				<HR>
				<H3 align=center>The requested users have been disassociated from this program.</H3>
				<BR>
				<CENTER><A HREF=manage_programs.php?s=0>Click here to continue</A></CENTER>
				<HR>
				</td></tr></table>
			");
		
			print_footer();
			
		}
		else
		{
		print_header();
			print ("
				<table width=800 align=center>
				<tr><td>
				<BR>
				<HR>
				<H1 align=center>Error</H1>
				<BR>
				<HR>
				<H3 align=center>The requested users have not been disassociated from the requested program.</H3>
				<BR>
				<CENTER><A HREF=manage_programs.php?s=0>Click here to continue</A></CENTER>
				<HR>
				</td></tr></table>
			");
		print_footer();
		}
	} // end is logged in
}
else{ //etoken check: false
	$message = "Error: Invalid session!";
	print_header();
		print "<br><hr><h1 align=center>$message</h1><hr><h3 align=center>Please press the Back button to return to previous page.</h3>";
		print_footer();

}
?>