<?php
include('init.php');
include('hmis/libs/functions.php');


$e_token = trim(scrub_white_list($_POST['e_token'], 'ALPHANUMERICONLY'));
$s_e_token = $_SESSION['e_token'];
if ((ISSET($e_token)) && ($e_token===$s_e_token)){

	if (checklogin($userID, "menu.php") && $status == 2) {


	if (isset($_POST['onoff'])) {
		$onoff = scrub_white_list($_POST['onoff'], 'ALPHAONLY');
		
		if ('on' == $onoff) {
			$result = toggle_hmis_onoff($onoff);
			$message = '1. Admin has successfully turned <b>ON</b> HMIS. ';
		} else if ('off' == $onoff) {
			$result = toggle_hmis_onoff($onoff);
			$message = '1. Admin has successfully turned <b>OFF</b> HMIS. ';	
		} else {
			$message = 'Invalid request: ' . $onoff;
		}
		
		audit_log($userID, $message);
		
	} else {
		$message = 'Invalid Request';
	}

	print_header();
	?>
	<style type="text/css">
	.auto-style1 {
		
		border: 1px solid #999999;
		border-style: inset;
		border-color: gray;
		background-color: white;
		-moz-border-radius: ;
	}
	</style>

	<style type="text/css">
	#manage {
		width:755px;
		border-width: 1px;
		border-spacing: ;
		border-style: outset;
		border-color: gray;
		border-collapse: separate;
		background-color: white;
	}
	#manage th {
		border-width: 1px;
		padding: 1px;
		border-style: inset;
		border-color: gray;
		background-color: white;
		-moz-border-radius: ;
	}
	#manage td {
		border-width: 1px;
		padding: 1px;
		border-style: inset;
		border-color: gray;
		background-color: white;
		-moz-border-radius: ;
	}
	</style>

	<H1 align=center>Update HMIS Configuration Result</H1>
	<CENTER><A HREF="menu.php">Main Menu</A> | <A HREF="admin_hmis_config.php">Configure HMIS</A></CENTER>
	<HR>
	<br><br>
	<TABLE ALIGN="CENTER" WIDTH="500">
	<TR>
		<TD valign="top" align="left"> 
			<?=$message?>
		</TD>
	</TR>
	</TABLE>


	<?
		//print '<br><br><CENTER><A HREF="menu.php">Return to Main Menu</A></CENTER>';
		print_footer();

	} // end check login
}
else{ //etoken check: false
	$message = "Error: Invalid session!";
	print_header();
		print "<br><hr><h1 align=center>$message</h1><hr><h3 align=center>Please press the Back button to return to previous page.</h3>";
		print_footer();

}

?>