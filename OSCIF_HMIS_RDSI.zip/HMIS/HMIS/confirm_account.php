<?php

include('init.php');
include('hmis/libs/functions.php');

if (isset($_REQUEST['c'])) { 
$c = scrub_sql(scrub_white_list($_REQUEST['c'], 'ALPHANUMERICONLY'), 32);

$sql = "SELECT user_id FROM tb_email_confirmation WHERE confirmation='$c' AND confirmed=0";
$rs = $db->Execute($sql);
$record_count = $rs->RecordCount();
if ($record_count == 1) {
$user_id = $rs->fields('user_id');

$sql = "UPDATE tb_email_confirmation SET confirmed=1 WHERE user_id=$user_id";
$rs = $db->Execute($sql);

$sql = "SELECT user_id, fname, lname, email, username, squares_user from tb_user where user_id=$user_id";
$rs2 = $db->Execute($sql);
$uNameDisp = $rs2->fields('username');
$emailDisp = $rs2->fields('email');
$squares_user = $rs2->fields('squares_user');

if ("1"==$squares_user){
	$sql = "UPDATE tb_user SET status=10 WHERE user_id=$user_id";
}
else
{
	$sql = "UPDATE tb_user SET status=9 WHERE user_id=$user_id";
}
$rs = $db->Execute($sql);

//$sql = "INSERT INTO tb_audit (user_id, event, event_date) VALUES ($user_id, 'User confirmed email address', getdate())";
//$rs = $db->Execute($sql);

$eventmsg = 'User confirmed email address';
audit_log($user_id, $eventmsg, 52);



$message = ("

<HTML>
<BODY>


Dear HMIS Repository administrators,
<BR><BR>

The user account <b>$uNameDisp</b> now has a confirmed email address ($emailDisp). <br>
<br>Please visit the <a href=http://ip_redacted/>HMIS Repository</a> <i>Manage Users</i> page to review this account.
<BR><BR>
Thank you.
<BR><HR><BR>
</BODY></HTML>

");

$headers = "From: HMIS Repository <noreply@domain>\n" . "MIME-Version: 1.0\n" . "Content-type: text/html; charset=iso-8859-1";


//PREPROD
//mail( "@domain;@domain;ugandhi@phaseonecg.com;jmarkowski@phaseonecg.com", "Notification of Repository Account Request", $message, $headers );

//PROD
//mail( "@domain;@domain;molly_mcevilley@abtassoc.com", "Notification of Repository Account Email Confirmation", $message, $headers );

//DEV
mail( "@domain;@domain", "Notification of Repository Account Email Confirmation", $message, $headers );

print_header();

?>
<table width=800 align=center>
<tr><td>
<BR>
<HR>
<H1 align=center>Thank You!</H1>
<BR>
<HR>
<H3 align=center>Your email address has been confirmed. Your account must now be reviewed and approved by the HMIS Administrator. You will receive an email confirmation once your account has been approved.</H3>
<BR>

<H3 align=center><a href='login.php' target='_self'>Back to Login Page</a></H3>
<HR>
</td></tr></table>

<?

print_footer();

}

else {
print_header();

?>

<table width=800 align=center>
<tr><td>
<BR>
<HR>
<H1 align=center>Error</H1>
<BR>
<HR>
<H3 align=center>Invalid confirmation code</H3>
<BR>
<HR>
</td></tr></table>

<?

print_footer();
}

}

else {
print_header();

?>

<table width=800 align=center>
<tr><td>
<BR>
<HR>
<H1 align=center>Error</H1>
<BR>
<HR>
<H3 align=center>Confirmation code required</H3>
<BR>
<HR>
</td></tr></table>

<?
print_footer();
}
?>