<?
include('init.php');
include('hmis/libs/functions.php');

$t = $_SESSION['e_token'];

print_header();


?>
<head>
<link rel="stylesheet" type="text/css" href="datatables/jquery.dataTables.css">
<!-- <link rel="stylesheet" type="text/css" href="datatables/jquery.dataTables.min.css"> -->
<link rel="stylesheet" type="text/css" href="datatables/jquery.dataTables_themeroller.css">

<script type="text/javascript" src="datatables/jquery-1.11.3.min.js"></script>
<script type="text/javascript" src="datatables/jquery.dataTables.min.js"></script>


<!--
<script type="text/javascript" src="tablesorter/jquery-1.11.3.min.js"></script>
<script type="text/javascript" src="tablesorter/jquery.tablesorter.pager.js"></script>
<script type="text/javascript" src="tablesorter/jquery.tablesorter.js"></script>
<script type="text/javascript" src="tablesorter/jquery.tablesorter.filter.js"></script>
<script type="text/javascript" src="tablesorter/jquery.tablesorter.widgets.js"></script>
-->

<script>

function pullAjax(){
        	var a;
	        try{
	          a=new XMLHttpRequest()
	        }
	        catch(b)
	        {
	          try
	          {
	            a=new ActiveXObject("Msxml2.XMLHTTP")
	          }catch(b)
	          {
	            try
	            {
	              a=new ActiveXObject("Microsoft.XMLHTTP")
	            }
	            catch(b)
	            {
	              alert("Your browser is not responding!");return false
	            }
	          }
	        }
	        return a;
	      }
 //this function does the ajax call, and appends counties into the counties dropdown
      function display_activity(x)
      {
        obj=pullAjax();
        var ddProgram=document.getElementById('user_programs');

        obj.onreadystatechange=function()
        {
          if(obj.readyState==4)
          {
            //returns comma separated list of counties after successful ajax request
            var tmp=obj.responseText;

            //split function returns array of county
           document.getElementById("dispResults").innerHTML=tmp;

		$(document).ready(function() {

		    $('#tableOne').DataTable({
		    	"order": [[ 0, "desc" ]],
		    	"paging": flase,
		    	"columnDefs": [{ 
		    		"orderable": false, "targets": 3, 
		    		"searchable": false, "targets": 3
		    	}],
		    	"search":{"regex":false, "caseInsensitive": true}
		    });
		});

		$('#tableOne').$('th').attr('scope', 'row');
           }
           else
	    {
		document.getElementById("dispResults").innerHTML = "<center><img src='378.gif' alt='Updating results...'></center>";
	    }
        };
		
	var t = document.getElementById('e_token').value;
	var activity_URL = "show_act_hist.php?p=" + x.value + "&t=" + t + "&nocache=" + new Date().getTime();
        obj.open("GET",activity_URL,true);
        obj.send(null);
}
</script>

<?
if (checklogin($userID, "menu.php") && ($status == 1 || $status == 2)) {
?>

</head>

<body onload="return display_activity(x);">
<H1 align=center>Activity History</H1>
<CENTER><A HREF="menu.php">Repository Home</A></CENTER>
<HR>
	<INPUT TYPE=hidden id="e_token" name="e_token" VALUE="<?php echo $_SESSION['e_token']; ?>">
<TABLE ALIGN="CENTER">

<?
	if ($status == 2) {
		
		$sql = "select program_id, program_name FROM tb_SSVF_program Order By program_name";
		
	} else if ($status == 1) {
		$sql = "select up.program_id, sp.program_name from tb_user_programs up, tb_SSVF_program sp where (up.user_id = $userID) and (up.program_id = sp.program_id) order by program_name asc";
	}
$rsUP = $db->Execute($sql);
$UPArray = array();

if ($rsUP->EOF){
	print("
		<TR><TD align='center'><font color='red'><b>No affiliated programs found.</b></font></td></tr>
	");

}

else{

	print("
		<TR><TD><label for='user_programs'>Select program: </label>
		<select name='user_programs' id='user_programs' onchange='display_activity(this);'>
		<option value=0> All Affiliated Programs</option>
	");


while (!$rsUP->EOF)
{
	$UPpid = $rsUP->fields('program_id');
	$UPpname = $rsUP->fields('program_name');

		
		array_push($UPArray, $UPpid);

		foreach($UPArray as $value){
			//echo $value . "<br>";
	      	      $UPSQL = implode(', ' , $UPArray);
		}
		print_r($UPSQL);
		

	$UPpid = $rsUP->fields('program_id');
	$UPpname = $rsUP->fields('program_name');

	print ("
		<option value='$UPpid'>$UPpname</option>
	");


	$rsUP->MoveNext();
  }

print ("</select></td></tr>");
}
?>

</TABLE>
<br>

<div id="dispResults">
<center><b>Please select an option above...<b></center>
</div>

<hr>

<?

} else {
	echo 'You need admin permission to access this page.';
	print '<br><br><CENTER><A HREF="menu.php">Repository Home</A></CENTER>';
}// end check login

print_footer();
?>
</body>