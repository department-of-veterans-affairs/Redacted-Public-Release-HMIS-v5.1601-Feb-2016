<?php
include('init.php');
include('hmis/libs/functions.php');

if (checklogin($userID, "menu.php") && $status == 2) {


if (isset($_REQUEST['s'])) {
	$s = scrub_white_list($_REQUEST['s'], 'NUMBERONLY');
}
else {
	$s = 9;
}

if (isset($_REQUEST['p'])) {
	$p = scrub_white_list($_REQUEST['p'], 'NUMBERONLY');
}
else {
	$p = 1;	
}


if (isset($_REQUEST['search'])) {
$search = scrub_white_list($_REQUEST['search'], 'USER');
}
else {$search="";}


$_SESSION['return_page']= $_SERVER['REQUEST_URI'];

print_header();

?>

<style type="text/css">
#manage {
	width:755px;
	border-width: 1px;
	border-spacing: ;
	border-style: outset;
	border-color: gray;
	border-collapse: separate;
	background-color: white;
}
#manage th {
	border-width: 1px;
	padding: 1px;
	border-style: inset;
	border-color: gray;
	background-color: white;
	-moz-border-radius: ;
}
#manage td {
	border-width: 1px;
	padding: 1px;
	border-style: inset;
	border-color: gray;
	background-color: white;
	-moz-border-radius: ;
}
</style>



<H1 align=center>Manage Programs</H1>
<CENTER><A HREF="create_program.php">Add New Program</A> | 
<A HREF="menu.php">Repository Home</A></CENTER> 
<HR>

<TABLE ALIGN="CENTER" WIDTH="755">

<TR><TD valign="top" align="left"><b>Validation type: </b>
<?if ($s != 0) {?><A HREF=manage_programs.php?s=0><?}?><? if ($s==0){?><b><?}?>Standard<? if ($s==0){?></b><?}?><?if ($s != 0) {?></A><?}?> |
<?if ($s != 1) {?><A HREF=manage_programs.php?s=1><?}?><? if ($s==1){?><b><?}?>Custom<? if ($s==1){?></b><?}?><?if ($s != 1) {?></A><?}?>

</TD>
<TD valign="top" align="right"><FORM ACTION=manage_programs.php METHOD=GET><label for='search'>Search Program/Grantee</label>: <INPUT TYPE='TEXT' NAME='search' id='search' VALUE="<?echo $search;?>"><INPUT TYPE=SUBMIT VALUE="Search"><INPUT TYPE="HIDDEN" NAME="s" VALUE="<?echo $s;?>"></FORM></TD>

</TR>
</TABLE>

<TABLE ALIGN="CENTER" NAME="manage" id="manage" WIDTH="755">
<TR>
<TH>Program / Grantee</TH><TH>Users</TH><TH>Status</TH><TH>Actions</TH>
</TR>


<?
$results = 0;
$start = 1+($p-1)*20;
$finish = $start+19;
$sql = "list_programs $s, $start, $finish, '$search'";
$rs = $db->Execute($sql);
while (!$rs->EOF)
  { 
	$program_id = $rs->fields('program_id');
	$grant_id = $rs->fields('sp_gid');
	$grant_name = $rs->fields('grant_name');
	$program_name = $rs->fields('program_name');
	$coc = $rs->fields('coc');
	$status = $rs->fields('status');
	$upload = $rs->fields('upload');


	//$sql1 = "select COUNT(user_id) as tot from tb_user_programs WHERE program_id=$program_id";
	
	$sql1 = "			SELECT  COUNT(up.user_id) as tot from tb_user u, tb_user_programs up where (up.program_id=$program_id) AND (u.user_id = up.user_id) AND (u.status in (1,7))";
	$rs1 = $db->Execute($sql1);

	$uCount = $rs1->fields('tot');
	

	$action = "<a href=edit_program.php?pid=$program_id>Edit</a>";

	print ("
		<tr><td><b><font size='1'><a href=program_details.php?p=$program_id>$program_name</font></b></a> <br><font size=1>$grant_name</font></td>
		<td align='center'><a href=program_details.php?p=$program_id>$uCount</a></td>
		");

	if ($status==3) {
		echo "<td align='center'>Complete<br><FORM ACTION='reset_program_data.php' id='reset_$program_id' METHOD='POST'><INPUT TYPE='HIDDEN' NAME='p' VALUE='$program_id'><INPUT TYPE='HIDDEN' NAME='e_token' id='e_token' VALUE='" . $_SESSION['e_token'] . "'></FORM>
			<a href='#' onClick='if (confirm(\"Are you sure you wish to reset the upload status of this program of this program? This will de-activate all associated data.\")) {document.getElementById(\"reset_$program_id\").submit();}'>Reset</a></td>";
	}
	elseif ($status==1) {
		echo "<td align='center'>Not Started</td>";
	}
		echo "<td align='center'>$action</td>";

	
	$results = $results + 1;    
	$rs->MoveNext();
  	}

?>

</TABLE>
<INPUT TYPE=hidden id="e_token" name="e_token" VALUE="<?php echo $_SESSION['e_token']; ?>">
<?

print "<center>";
if ($p > 1) {
$lastp=$p-1;
print "<a href=manage_programs.php?s=$s&p=$lastp><< Previous Page</a> ";
}


if ($results == 20) {
$nextp=$p+1;
print "<a href=manage_programs.php?s=$s&p=$nextp> Next Page >></a>";
}
print "</center>";


print_footer();

} // end check login

?>