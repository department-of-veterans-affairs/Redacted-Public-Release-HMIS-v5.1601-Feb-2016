<?php

include('init.php');
include('hmis/libs/functions.php');

$e_token = trim(scrub_white_list($_POST['e_token'], 'ALPHANUMERICONLY'));
$s_e_token = $_SESSION['e_token'];

//echo "e_token-> " . $e_token;
//echo "<BR>s_e_token -> " . $s_e_token;

if ((ISSET($e_token)) && ($e_token===$s_e_token)){

	if (checklogin($userID, "menu.php") && $status == 2) {

		if (isset($_POST['u'])) { 
			$uid = scrub_sql(scrub_white_list($_POST['u'], 'NUMBERONLY'), 8);
			$sql = "UPDATE tb_user SET status=1 WHERE user_id=$uid";
			$rs = $db->Execute($sql);

			//$sql = "INSERT INTO tb_audit (user_id, event, event_date) VALUES ($userID, 'Admin unsuspended account $uid', getdate())";
			//$rs = $db->Execute($sql);

			$message = 'Admin unsuspended account';
			audit_log($userID, $message, 9, $uid);


			print_header();

			?>
			<table width=800 align=center>
			<tr><td>
			<BR>
			<HR>
			<H1 align=center>Unsuspended</H1>
			<BR>
			<HR>
			<H3 align=center>This account has been unsuspended.</H3>
			<BR>
			<CENTER><A HREF=manage_users.php>Click here to continue</A></CENTER>
			<HR>
			</td></tr></table>

			<?

		print_footer();

		} // end has uid

	} // end is logged in
}
else{ //etoken check: false
	$message = "Error: Invalid session!";
	print_header();
		print "<br><hr><h1 align=center>$message</h1><hr><h3 align=center>Please press the Back button to return to previous page.</h3>";
		print_footer();

}		
	
?>