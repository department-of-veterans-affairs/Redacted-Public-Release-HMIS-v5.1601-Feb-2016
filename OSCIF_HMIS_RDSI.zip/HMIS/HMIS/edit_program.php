<?php
include('init.php');
include('hmis/libs/functions.php');


if (checklogin($userID, "menu.php") && $status == 2) {


if (isset($_REQUEST['pid'])) { 
$pid = scrub_sql(scrub_white_list($_REQUEST['pid'], 'NUMBERONLY'), 8);


if (isset($_SESSION['return_page'])) {
$url = $_SESSION['return_page'];
}
else {
$url = "manage_programs.php";
}



$sql = "SELECT program_id, grant_id, program_name, status, coc, upload, p_start_date, p_end_date, val_type FROM tb_SSVF_program WHERE program_id=$pid";
$rs = $db->Execute($sql);

if (!$rs->EOF){
	while (!$rs->EOF)
	{
		$program_id = $rs->fields('program_id');
		$p_grant_id = $rs->fields('grant_id');
		$program_name = $rs->fields('program_name');
		$coc = $rs->fields('coc');
		$status = $rs->fields('status');
		$coc = $rs->fields('coc');
		$upload = $rs->fields('upload');

		$p_start_date = $rs->fields('p_start_date');
		$p_start_date = date("m/d/Y", strtotime($p_start_date));

		$p_end_date = $rs->fields('p_end_date');

		if ($p_end_date <> ''){
			$p_end_date = date("m/d/Y", strtotime($p_end_date));
		}
		else{
			$p_end_date = '';
		}

		$val_type = $rs->fields('val_type');
		
	$rs->MoveNext();
	}
	
	print_header();

	?>

<SCRIPT LANGUAGE="JavaScript" SRC="./hmis/CalendarPopup.js"></SCRIPT>

	<script language = "Javascript">
	var cal = new CalendarPopup();
	// Declaring valid date character, minimum year and maximum year
	var dtCh= "/";
	var minYear=1900;
	var maxYear=2100;
	
	function isInteger(s){
		var i;
	    for (i = 0; i < s.length; i++){   
		// Check that current character is number.
		var c = s.charAt(i);
		if (((c < "0") || (c > "9"))) return false;
	    }
	    // All characters are numbers.
	    return true;
	}
	
	function stripCharsInBag(s, bag){
		var i;
	    var returnString = "";
	    // Search through string's characters one by one.
	    // If character is not in bag, append to returnString.
	    for (i = 0; i < s.length; i++){   
		var c = s.charAt(i);
		if (bag.indexOf(c) == -1) returnString += c;
	    }
	    return returnString;
	}
	
	function daysInFebruary (year){
		// February has 29 days in any year evenly divisible by four,
	    // EXCEPT for centurial years which are not also divisible by 400.
	    return (((year % 4 == 0) && ( (!(year % 100 == 0)) || (year % 400 == 0))) ? 29 : 28 );
	}
	function DaysArray(n) {
		for (var i = 1; i <= n; i++) {
			this[i] = 31
			if (i==4 || i==6 || i==9 || i==11) {this[i] = 30}
			if (i==2) {this[i] = 29}
	   } 
	   return this
	}
	
	function isDate(dtStr){
		var daysInMonth = DaysArray(12)
		var pos1=dtStr.indexOf(dtCh)
		var pos2=dtStr.indexOf(dtCh,pos1+1)
		var strMonth=dtStr.substring(0,pos1)
		var strDay=dtStr.substring(pos1+1,pos2)
		var strYear=dtStr.substring(pos2+1)
		strYr=strYear
		if (strDay.charAt(0)=="0" && strDay.length>1) strDay=strDay.substring(1)
		if (strMonth.charAt(0)=="0" && strMonth.length>1) strMonth=strMonth.substring(1)
		for (var i = 1; i <= 3; i++) {
			if (strYr.charAt(0)=="0" && strYr.length>1) strYr=strYr.substring(1)
		}
		month=parseInt(strMonth)
		day=parseInt(strDay)
		year=parseInt(strYr)
		if (pos1==-1 || pos2==-1){
			alert("The date format should be : mm/dd/yyyy")
			return false
		}
		if (strMonth.length<1 || month<1 || month>12){
			alert("Please enter a valid month")
			return false
		}
		if (strDay.length<1 || day<1 || day>31 || (month==2 && day>daysInFebruary(year)) || day > daysInMonth[month]){
			alert("Please enter a valid day")
			return false
		}
		if (strYear.length != 4 || year==0 || year<minYear || year>maxYear){
			alert("Please enter a valid 4 digit year between "+minYear+" and "+maxYear)
			return false
		}
		if (dtStr.indexOf(dtCh,pos2+1)!=-1 || isInteger(stripCharsInBag(dtStr, dtCh))==false){
			alert("Please enter a valid date")
			return false
		}
	return true
	}

	var cust_updated;
function custom_updated(){
	cust_updated=true;
}

function check_form() {
var errs=0;
var valid = true;
var msg = "";

	var startDate = document.getElementById('p_start_date').value;
	var endDate = document.getElementById('p_end_date').value;

	var sdTest = new Date(startDate);
	var edTest = new Date(endDate);

	sdTest = sdTest.getTime();
	edTest = edTest.getTime();

	if (document.getElementById('pname').value == '') {
		msg = msg + "- Please enter a valid program name (under 125 characters).\n";
	}

	if (document.getElementById('pname').value.length > 125) { 
		msg = msg + "- Please enter a valid program name (under 125 characters).\n";
	}
	
	if (document.getElementById('coc').value.length > 150) { 
		msg = msg + "- Please enter a valid COC (under 150 characters).\n";
	}
		
	if (document.getElementById('grantee').value=='000'){
		msg = msg + "- Please select a grantee name.\n";
	}

	if (startDate == '') { 
		msg = msg + "- Please make sure a start date is chosen.\n";
	}
	if (startDate != ''){
		var date_error=0;
		var daysInMonth = DaysArray(12)
		var pos1=startDate.indexOf(dtCh)
		var pos2=startDate.indexOf(dtCh,pos1+1)
		var strMonth=startDate.substring(0,pos1)
		var strDay=startDate.substring(pos1+1,pos2)
		var strYear=startDate.substring(pos2+1)
		strYr=strYear
		if (strDay.charAt(0)=="0" && strDay.length>1) strDay=strDay.substring(1)
		if (strMonth.charAt(0)=="0" && strMonth.length>1) strMonth=strMonth.substring(1)
		for (var i = 1; i <= 3; i++) {
			if (strYr.charAt(0)=="0" && strYr.length>1) strYr=strYr.substring(1)
		}
		month=parseInt(strMonth)
		day=parseInt(strDay)
		year=parseInt(strYr)
		if (pos1==-1 || pos2==-1){
			date_error=1;
		}
		if (strMonth.length<1 || month<1 || month>12){
			date_error=1;
		}
		if (strDay.length<1 || day<1 || day>31 || (month==2 && day>daysInFebruary(year)) || day > daysInMonth[month]){
			date_error=1;
		}
		if (strYear.length != 4 || year==0 || year<minYear || year>maxYear){
			date_error=1;
		}
		if (startDate.indexOf(dtCh,pos2+1)!=-1 || isInteger(stripCharsInBag(startDate, dtCh))==false){
			date_error=1;
		}
		
		if (1==date_error){
			msg += "- Please enter a correct program start date. (MM/DD/YYYY)\n";
		}
	
	}
	
	if (endDate != '') { 
	
	var date_error=0;
		var daysInMonth = DaysArray(12)
		var pos1=endDate.indexOf(dtCh)
		var pos2=endDate.indexOf(dtCh,pos1+1)
		var strMonth=endDate.substring(0,pos1)
		var strDay=endDate.substring(pos1+1,pos2)
		var strYear=endDate.substring(pos2+1)
		strYr=strYear
		if (strDay.charAt(0)=="0" && strDay.length>1) strDay=strDay.substring(1)
		if (strMonth.charAt(0)=="0" && strMonth.length>1) strMonth=strMonth.substring(1)
		for (var i = 1; i <= 3; i++) {
			if (strYr.charAt(0)=="0" && strYr.length>1) strYr=strYr.substring(1)
		}
		month=parseInt(strMonth)
		day=parseInt(strDay)
		year=parseInt(strYr)
		if (pos1==-1 || pos2==-1){
			date_error=1;
		}
		if (strMonth.length<1 || month<1 || month>12){
			date_error=1;
		}
		if (strDay.length<1 || day<1 || day>31 || (month==2 && day>daysInFebruary(year)) || day > daysInMonth[month]){
			date_error=1;
		}
		if (strYear.length != 4 || year==0 || year<minYear || year>maxYear){
			date_error=1;
		}
		if (endDate.indexOf(dtCh,pos2+1)!=-1 || isInteger(stripCharsInBag(endDate, dtCh))==false){
			date_error=1;
		}
		
		if (1==date_error){
			msg += "- Please enter a correct program end date. (MM/DD/YYYY)\n";
		}
		
		if (sdTest > edTest){
			msg += "- Please make sure the chosen start date is before the chosen end date.\n";
		}
	}

if (document.getElementById('val_custom').checked){
		//------------------------------------------------------- CLIENT.CSV ---------------------------------------------------------------------------------
		if ((isNaN(document.getElementById('DateOfBirth_ack').value) || (document.getElementById('DateOfBirth_ack').value == '') || (document.getElementById('DateOfBirth_ack').value < 0) || (document.getElementById('DateOfBirth_ack').value > 100))){
			msg += "\n- Client.csv: Please enter an acknowledgment threshold for DateOfBirth (0 - 100).\n";
		}
		if ((isNaN(document.getElementById('DateOfBirth_rej').value) || (document.getElementById('DateOfBirth_rej').value == '') || (document.getElementById('DateOfBirth_rej').value < 0) || (document.getElementById('DateOfBirth_rej').value > 100))){
			msg += "\n- Client.csv: Please enter a rejection threshold for DateOfBirth (0 - 100).\n";
		}
		
		if ((isNaN(document.getElementById('Ethnicity_ack').value) || (document.getElementById('Ethnicity_ack').value == '') || (document.getElementById('Ethnicity_ack').value < 0) || (document.getElementById('Ethnicity_ack').value > 100))){
			msg += "\n- Client.csv: Please enter an acknowledgment threshold for Ethnicity (0 - 100).\n";
		}
		if ((isNaN(document.getElementById('Ethnicity_rej').value) ||(document.getElementById('Ethnicity_rej').value == '') || (document.getElementById('Ethnicity_rej').value < 0) || (document.getElementById('Ethnicity_rej').value > 100))){
			msg += "\n- Client.csv: Please enter a rejection threshold for Ethnicity (0 - 100).\n";
		}
		
		if ((isNaN(document.getElementById('Gender_ack').value) ||(document.getElementById('Gender_ack').value == '') || (document.getElementById('Gender_ack').value < 0) || (document.getElementById('Gender_ack').value > 100))){
			msg += "\n- Client.csv: Please enter an acknowledgment threshold for Gender (0 - 100).\n";
		}
		if ((isNaN(document.getElementById('Gender_rej').value) ||(document.getElementById('Gender_rej').value == '') || (document.getElementById('Gender_rej').value < 0) || (document.getElementById('Gender_rej').value > 100))){
			msg += "\n- Client.csv: Please enter a rejection threshold for Gender (0 - 100).\n";
		}		
		
		if ((isNaN(document.getElementById('LegalFirstName_ack').value) || (document.getElementById('LegalFirstName_ack').value == '') || (document.getElementById('LegalFirstName_ack').value < 0) || (document.getElementById('LegalFirstName_ack').value > 100))){
			msg += "\n- Client.csv: Please enter an acknowledgment threshold for LegalFirstName (0 - 100).\n";
		}
		if ((isNaN(document.getElementById('LegalFirstName_rej').value) || (document.getElementById('LegalFirstName_rej').value == '') || (document.getElementById('LegalFirstName_rej').value < 0) || (document.getElementById('LegalFirstName_rej').value > 100))){
			msg += "\n- Client.csv: Please enter a rejection threshold for LegalFirstName (0 - 100).\n";
		}

		if ((isNaN(document.getElementById('LegalLastName_ack').value) || (document.getElementById('LegalLastName_ack').value == '') || (document.getElementById('LegalLastName_ack').value < 0) || (document.getElementById('LegalLastName_ack').value > 100))){
			msg += "\n- Client.csv: Please enter an acknowledgment threshold for LegalLastName (0 - 100).\n";
		}
		if ((isNaN(document.getElementById('LegalLastName_rej').value) || (document.getElementById('LegalLastName_rej').value == '') || (document.getElementById('LegalLastName_rej').value < 0) || (document.getElementById('LegalLastName_rej').value > 100))){
			msg += "\n- Client.csv: Please enter a rejection threshold for LegalLastName (0 - 100).\n";
		}
		
		if ((isNaN(document.getElementById('PrimaryRace_ack').value) || (document.getElementById('PrimaryRace_ack').value == '') || (document.getElementById('PrimaryRace_ack').value < 0) || (document.getElementById('PrimaryRace_ack').value > 100))){
			msg += "\n- Client.csv: Please enter an acknowledgment threshold for PrimaryRace (0 - 100).\n";
		}
		if ((isNaN(document.getElementById('PrimaryRace_rej').value) || (document.getElementById('PrimaryRace_rej').value == '') || (document.getElementById('PrimaryRace_rej').value < 0) || (document.getElementById('PrimaryRace_rej').value > 100))){
			msg += "\n- Client.csv: Please enter a rejection threshold for PrimaryRace (0 - 100).\n";
		}

		if ((isNaN(document.getElementById('SocialSecurityNumber_ack').value) || (document.getElementById('SocialSecurityNumber_ack').value == '') || (document.getElementById('SocialSecurityNumber_ack').value < 0) || (document.getElementById('SocialSecurityNumber_ack').value > 100))){
			msg += "\n- Client.csv: Please enter an acknowledgment threshold for SocialSecurityNumber (0 - 100).\n";
		}
		if ((isNaN(document.getElementById('SocialSecurityNumber_rej').value) || (document.getElementById('SocialSecurityNumber_rej').value == '') || (document.getElementById('SocialSecurityNumber_rej').value < 0) || (document.getElementById('SocialSecurityNumber_rej').value > 100))){
			msg += "\n- Client.csv: Please enter a rejection threshold for SocialSecurityNumber (0 - 100).\n";
		}


		//------------------------------------------------------- CLIENTHISTORICAL.CSV ---------------------------------------------------------------------------------


		if ((isNaN(document.getElementById('IncomeLast30Days_ack').value) || (document.getElementById('IncomeLast30Days_ack').value == '') || (document.getElementById('IncomeLast30Days_ack').value < 0) || (document.getElementById('IncomeLast30Days_ack').value > 100))){
			msg += "\n- ClientHistorical.csv: Please enter an acknowledgment threshold for IncomeLast30Days (0 - 100).\n";
		}
		if ((isNaN(document.getElementById('IncomeLast30Days_rej').value) || (document.getElementById('IncomeLast30Days_rej').value == '') || (document.getElementById('IncomeLast30Days_rej').value < 0) || (document.getElementById('IncomeLast30Days_rej').value > 100))){
			msg += "\n- ClientHistorical.csv: Please enter a rejection threshold for IncomeLast30Days (0 - 100).\n";
		}

		if ((isNaN(document.getElementById('NonCashBenefitsLast30Days_ack').value) || (document.getElementById('NonCashBenefitsLast30Days_ack').value == '') || (document.getElementById('NonCashBenefitsLast30Days_ack').value < 0) || (document.getElementById('NonCashBenefitsLast30Days_ack').value > 100))){
			msg += "\n- ClientHistorical.csv: Please enter an acknowledgment threshold for NonCashBenefitsLast30Days (0 - 100).\n";
		}
		if ((isNaN(document.getElementById('NonCashBenefitsLast30Days_rej').value) || (document.getElementById('NonCashBenefitsLast30Days_rej').value == '') || (document.getElementById('NonCashBenefitsLast30Days_rej').value < 0) || (document.getElementById('NonCashBenefitsLast30Days_rej').value > 100))){
			msg += "\n- ClientHistorical.csv: Please enter a rejection threshold for NonCashBenefitsLast30Days (0 - 100).\n";
		}


		//------------------------------------------------------- PROGRAMPARTICIPATION.CSV ---------------------------------------------------------------------------------
		if ((isNaN(document.getElementById('Destination_ack').value) || (document.getElementById('Destination_ack').value == '') || (document.getElementById('Destination_ack').value < 0) || (document.getElementById('Destination_ack').value > 100))){
			msg += "\n- ProgramParticipation.csv: Please enter an acknowledgment threshold for Destination (0 - 100).\n";
		}
		if ((isNaN(document.getElementById('Destination_rej').value) || (document.getElementById('Destination_rej').value == '') || (document.getElementById('Destination_rej').value < 0) || (document.getElementById('Destination_rej').value > 100))){
			msg += "\n- ProgramParticipation.csv: Please enter a rejection threshold for Destination (0 - 100).\n";
		}
		
		if ((isNaN(document.getElementById('DisablingCondition_ack').value) || (document.getElementById('DisablingCondition_ack').value == '') || (document.getElementById('DisablingCondition_ack').value < 0) || (document.getElementById('DisablingCondition_ack').value > 100))){
			msg += "\n- ProgramParticipation.csv: Please enter an acknowledgment threshold for DisablingCondition (0 - 100).\n";
		}
		if ((isNaN(document.getElementById('DisablingCondition_rej').value) || (document.getElementById('DisablingCondition_rej').value == '') || (document.getElementById('DisablingCondition_rej').value < 0) || (document.getElementById('DisablingCondition_rej').value > 100))){
			msg += "\n- ProgramParticipation.csv: Please enter a rejection threshold for DisablingCondition (0 - 100).\n";
		}
		
		if ((isNaN(document.getElementById('EntryDate_ack').value) || (document.getElementById('EntryDate_ack').value == '') || (document.getElementById('EntryDate_ack').value < 0) || (document.getElementById('EntryDate_ack').value > 100))){
			msg += "\n- ProgramParticipation.csv: Please enter an acknowledgment threshold for EntryDate (0 - 100).\n";
		}
		if ((isNaN(document.getElementById('EntryDate_rej').value) || (document.getElementById('EntryDate_rej').value == '') || (document.getElementById('EntryDate_rej').value < 0) || (document.getElementById('EntryDate_rej').value > 100))){
			msg += "\n- ProgramParticipation.csv: Please enter a rejection threshold for EntryDate (0 - 100).\n";
		}
		
		if ((isNaN(document.getElementById('HouseholdIdentificationNumber_ack').value) || (document.getElementById('HouseholdIdentificationNumber_ack').value == '') || (document.getElementById('HouseholdIdentificationNumber_ack').value < 0) || (document.getElementById('HouseholdIdentificationNumber_ack').value > 100))){
			msg += "\n- ProgramParticipation.csv: Please enter an acknowledgment threshold for HouseholdIdentificationNumber (0 - 100).\n";
		}
		if ((isNaN(document.getElementById('HouseholdIdentificationNumber_rej').value) || (document.getElementById('HouseholdIdentificationNumber_rej').value == '') || (document.getElementById('HouseholdIdentificationNumber_rej').value < 0) || (document.getElementById('HouseholdIdentificationNumber_rej').value > 100))){
			msg += "\n- ProgramParticipation.csv: Please enter a rejection threshold for HouseholdIdentificationNumber (0 - 100).\n";
		}
		
		if ((isNaN(document.getElementById('HousingStatusAtEntry_ack').value) || (document.getElementById('HousingStatusAtEntry_ack').value == '') || (document.getElementById('HousingStatusAtEntry_ack').value < 0) || (document.getElementById('HousingStatusAtEntry_ack').value > 100))){
			msg += "\n- ProgramParticipation.csv: Please enter an acknowledgment threshold for HousingStatusAtEntry (0 - 100).\n";
		}
		if ((isNaN(document.getElementById('HousingStatusAtEntry_rej').value) || (document.getElementById('HousingStatusAtEntry_rej').value == '') || (document.getElementById('HousingStatusAtEntry_rej').value < 0) || (document.getElementById('HousingStatusAtEntry_rej').value > 100))){
			msg += "\n- ProgramParticipation.csv: Please enter a rejection threshold for HousingStatusAtEntry (0 - 100).\n";
		}

		//if ((isNaN(document.getElementById('HousingStatusAtExit_ack').value) || (document.getElementById('HousingStatusAtExit_ack').value == '') || (document.getElementById('HousingStatusAtExit_ack').value < 0) || (document.getElementById('HousingStatusAtExit_ack').value > 100))){
			//msg += "\n- ProgramParticipation.csv: Please enter an acknowledgment threshold for HousingStatusAtExit (0 - 100).\n";
		//}
		//if ((isNaN(document.getElementById('HousingStatusAtExit_rej').value) || (document.getElementById('HousingStatusAtExit_rej').value == '') || (document.getElementById('HousingStatusAtExit_rej').value < 0) || (document.getElementById('HousingStatusAtExit_rej').value > 100))){
			//msg += "\n- ProgramParticipation.csv: Please enter a rejection threshold for HousingStatusAtExit (0 - 100).\n";
		//}
		
		if ((isNaN(document.getElementById('LengthOfStayAtPriorResidence_ack').value) || (document.getElementById('LengthOfStayAtPriorResidence_ack').value == '') || (document.getElementById('LengthOfStayAtPriorResidence_ack').value < 0) || (document.getElementById('LengthOfStayAtPriorResidence_ack').value > 100))){
			msg += "\n- ProgramParticipation.csv: Please enter an acknowledgment threshold for LengthOfStayAtPriorResidence (0 - 100).\n";
		}
		if ((isNaN(document.getElementById('LengthOfStayAtPriorResidence_rej').value) || (document.getElementById('LengthOfStayAtPriorResidence_rej').value == '') || (document.getElementById('LengthOfStayAtPriorResidence_rej').value < 0) || (document.getElementById('LengthOfStayAtPriorResidence_rej').value > 100))){
			msg += "\n- ProgramParticipation.csv: Please enter a rejection threshold for LengthOfStayAtPriorResidence (0 - 100).\n";
		}

		if ((isNaN(document.getElementById('PriorResidence_ack').value) || (document.getElementById('PriorResidence_ack').value == '') || (document.getElementById('PriorResidence_ack').value < 0) || (document.getElementById('PriorResidence_ack').value > 100))){
			msg += "\n- ProgramParticipation.csv: Please enter an acknowledgment threshold for PriorResidence (0 - 100).\n";
		}
		if ((isNaN(document.getElementById('PriorResidence_rej').value) || (document.getElementById('PriorResidence_rej').value == '') || (document.getElementById('PriorResidence_rej').value < 0) || (document.getElementById('PriorResidence_rej').value > 100))){
			msg += "\n- ProgramParticipation.csv: Please enter a rejection threshold for PriorResidence (0 - 100).\n";
		}

		if ((isNaN(document.getElementById('VeteranStatus_ack').value) || (document.getElementById('VeteranStatus_ack').value == '') || (document.getElementById('VeteranStatus_ack').value < 0) || (document.getElementById('VeteranStatus_ack').value > 100))){
			msg += "\n- ProgramParticipation.csv: Please enter an acknowledgment threshold for VeteranStatus (0 - 100).\n";
		}
		if ((isNaN(document.getElementById('VeteranStatus_rej').value) || (document.getElementById('VeteranStatus_rej').value == '') || (document.getElementById('VeteranStatus_rej').value < 0) || (document.getElementById('VeteranStatus_rej').value > 100))){
			msg += "\n- ProgramParticipation.csv: Please enter a rejection threshold for VeteranStatus (0 - 100).\n";
		}

		if ((isNaN(document.getElementById('ZIPCode_ack').value) || (document.getElementById('ZIPCode_ack').value == '') || (document.getElementById('ZIPCode_ack').value < 0) || (document.getElementById('ZIPCode_ack').value > 100))){
			msg += "\n- ProgramParticipation.csv: Please enter an acknowledgment threshold for ZIPCode (0 - 100).\n";
		}
		if ((isNaN(document.getElementById('ZIPCode_rej').value) || (document.getElementById('ZIPCode_rej').value == '') || (document.getElementById('ZIPCode_rej').value < 0) || (document.getElementById('ZIPCode_rej').value > 100))){
			msg += "\n- ProgramParticipation.csv: Please enter a rejection threshold for ZIPCode (0 - 100).\n";
		}

	}

	if (msg == ""){
		var og_valtype = document.getElementById('og_valtype').value;

		if ((og_valtype == 1) && (document.getElementById('val_standard').checked==true)){
			var r=confirm("Warning! Changing this program validation type to 'Standard' will reset any custom validation thresholds to the default values. Do you wish to proceed?");
			if (r==true){
				return true;
			}
			else{
				return false;
			}
		}
		
		if ((og_valtype == 1) && (document.getElementById('val_custom').checked==true) && cust_updated==true){
			var r=confirm("Warning! Are you sure you wish to change the file validation thresholds for this program?");
			if (r==true){
				return true;
			}
			else{
				return false;
			}
		}

		if ((og_valtype == 0) && (document.getElementById('val_custom').checked==true)){
			var r=confirm("Warning! Are you sure you wish to change the file validation thresholds for this program?");
			if (r==true){
				return true;
			}
			else{
				return false;
			}
		}
	}

	if (msg != ""){
		alert(msg);
		return false;
	}

}

function disp_custom(){
if (document.getElementById('val_custom').checked){
	//alert("custom");
	document.getElementById('custom_val').style.display='inline';
}

if (document.getElementById('val_standard').checked){
	//alert("custom");
	document.getElementById('custom_val').style.display='none';
}

}

function expand_custom(){
	if (document.getElementById('og_valtype').value == 1){
		document.getElementById('custom_val').style.display='inline';
	}
}

function clear_end_date() {
	if (document.getElementById('p_end_date').value != ""){
		document.getElementById('p_end_date').value="";
	}
}
</script>

<body onload="expand_custom();">
<form name="editprog" action="updateprogram.php" method="post">
<input type="hidden" name="pid" value="<?echo $pid;?>">




<h1 align="center">Edit Program<!-- END: PAGE TITLE --></h1>
    

<CENTER><A HREF="manage_programs.php?s=0">Return to Manage Programs</A></CENTER>

<HR>


<br><br>

<table width=755 align="center">
<tr class="va-section-header" width="550">
<td colspan=2>Program Information</td>
</tr>
<tr>
<td width="500" colspan="2">
    Edit the fields below to update this program's information.
<br>
Note: All fields are required.
    <br><br>
<tr>
<td width="200"><label for='pname'>Program Name</label></td>
<td width="400"><input type="text" id="pname" name="pname" size="100%" maxlength="125" VALUE="<?echo $program_name;?>"></td>
</tr>

<tr>
<td width="200"><label for='grantee'>Grantee Name</label></td>
<td width="400">
<select name="grantee" id="grantee" style="width:100%">
<option value="000">Please select a grantee...</option>
<?
$sql = "select grant_name, grant_id, grantee, grant_number FROM tb_SSVF_grant ORDER BY grant_name";
$rs = $db->Execute($sql);

while (!$rs->EOF)
{
$grant_name = $rs->fields('grant_name');
$grant_id = $rs->fields('grant_id');
$grantee = $rs->fields('grantee');
$grant_number = $rs->fields('grant_number');

if ($grant_id == $p_grant_id) {
	echo "<option value='$grant_id' selected>$grant_name</option>";
}
else {
	echo "<option value='$grant_id'>$grant_name</option>";
}

$rs->MoveNext();
}
?>
</select>
</td>
</tr>


<tr>
<td width="200"><label for='p_start_date'>Program Start Date</label></td>
<td>
<input type="text" id="p_start_date" name="p_start_date" size="12" value="<? echo $p_start_date ?>"> 
<input type="button" value="Calendar" onclick="cal.select(document.forms.editprog.p_start_date,'anchor1','MM/dd/yyyy'); return false;" name="anchor1" id="anchor1" >
</td>
</tr>

<tr>
<td width="200"><label for='p_end_date'>Program End Date</label></td>
<td>
<input type="text" id="p_end_date" name="p_end_date" size="12" value="<? echo $p_end_date ?>"> 
<input type="button" value="Calendar" onclick="cal.select(document.forms.editprog.p_end_date,'anchor2','MM/dd/yyyy'); return false;" name="anchor2" id="anchor2" >

</td>
</tr>

<tr>
<? //once we have program validation type -> check and select which one they have ?>
<td width="200"><fieldset><legend>Validation Type</legend></td>
<td width="400">
<input type="radio" name="val_type" id="val_standard" value="0" onclick="return disp_custom();" <?if ($val_type==0){?> checked='checked' <?}?>><label for='val_standard'>Standard</label>
&nbsp; &nbsp; &nbsp; &nbsp;
<input type="radio" name="val_type" id="val_custom" value="1" onclick="return disp_custom();"  <?if ($val_type==1){?> checked='checked' <?}?>><label for='val_custom'>Custom</label></fieldset>
</td>
</tr>

<tr>
<td width="200"><label for='coc'>COC</label></td>
<td width="400"><input type="text" id="coc" name="coc" size="100%" maxlength="150" VALUE="<?echo $coc;?>"></td>
</tr>
</table>

<br><br>

<div id="custom_val" name="custom_val" style="display:none;">
<table width="50%" align="center" cellspacing='0' class='auto-style1' border=1>

<tr>
<td colspan="4" class="va-section-header">Custom Validation Thresholds</td>
</tr>

<?

//if program standard validation type - get default threshholds from DB

if ($val_type==0){
	$sqlT = "select * from FileFormat WHERE (util_rate_ack > 0 OR util_rate_rej > 0) and (field_name <> 'HousingStatusAtExit') order by format_name, field_name asc";
	$rsT = $db->Execute($sqlT);

	print (" <tr bgcolor='#CCCCCC'><th width='500px'>File Name</th><th>Field</th><th>ACK</th><th>REJ</th></tr>");
	while (!$rsT->EOF){
	
		$format_id=$rsT->fields('format_id');
		$format_name=$rsT->fields('format_name');
		$field_name=$rsT->fields('field_name');
		$util_rate_ack=$rsT->fields('util_rate_ack');
		$util_rate_rej=$rsT->fields('util_rate_rej');
	
		print("<tr align='center'><td bgcolor='#EEEEEE'><b>$format_name</b></td><td>$field_name</td>");
		print("<td><input name=" . $field_name . "_ack id=" . $field_name ."_ack size=3 maxlength=3 value='$util_rate_ack' type='text' style='text-align:center'></td>");
		print("<td><input name=" . $field_name . "_rej id=" . $field_name ."_rej size=3 maxlength=3 value='$util_rate_rej' type='text' style='text-align:center'></td>");
		print("</tr>");
	

	$rsT->MoveNext();
	}
}

//-------------------------------------REPLACE WITH CODE TO PULL CUSTOM THRESHOLDS-----------------------------------------------------------
if ($val_type==1){
	$sqlT = "select * from HMIS_Custom_Threshold WHERE (program_id=$pid) and (field_name <> 'HousingStatusAtExit') order by format_name, field_name asc";
	$rsT = $db->Execute($sqlT);

	print (" <tr bgcolor='#CCCCCC'><th width='500px'>File Name</th><th>Field</th><th>ACK</th><th>REJ</th></tr>");
	while (!$rsT->EOF){
		
		
		$format_name=$rsT->fields('format_name');
		$field_name=$rsT->fields('field_name');
		$util_rate_ack=$rsT->fields('util_rate_ack');
		$util_rate_rej=$rsT->fields('util_rate_rej');
	
		print("<tr align='center'><td bgcolor='#EEEEEE'><b>$format_name</b></td><td>$field_name</td>");
		print("<td><input name=" . $field_name . "_ack id=" . $field_name ."_ack size=3 maxlength=3 value='$util_rate_ack' type='text' style='text-align:center' onchange='return custom_updated();'></td>");
		print("<td><input name=" . $field_name . "_rej id=" . $field_name ."_rej size=3 maxlength=3 value='$util_rate_rej' type='text' style='text-align:center' onchange='return custom_updated();'></td>");
		print("</tr>");
	

	$rsT->MoveNext();
	}
}
?>

</table>
</div>

<TR><TD colspan=4 align=center>
<HR>

<? print ("<input type='hidden' id='og_valtype' name='og_valtype' value='" . $val_type . "'>");?>
<? print ("<input type='hidden' id='pid' name='pid' value='" . $program_id . "'>");?>
<INPUT TYPE=SUBMIT VALUE="Update Program" onclick="return check_form();"> <INPUT TYPE=RESET VALUE=Cancel onClick="document.location='manage_programs.php?s=0';">
<HR>
</TD></TR>
</TABLE>
<INPUT TYPE=hidden id="e_token" name="e_token" VALUE="<?php echo $_SESSION['e_token']; ?>">
</form>

</td>

</td>
</tr>
</tbody>
</table>
</body>

			
<?php

print_footer();
}
else{
	print_header();
	print '<hr><h1 align=center>Error!</h1><hr><br><h3 align=center>This program was not found.</h3>';
	print '<br><br><CENTER><A HREF="menu.php">Repository Home</A></CENTER>';
	print_footer();
}

} // end check uid

else {print "Invalid user";}

} // end check login

?>
